//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NtMagick.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_NTMAGITYPE                  129
#define IDR_MAGICK                      130
#define IDR_BITMAP                      131
#define ID_IMAGE_ROTATE_90              1000
#define ID_IMAGE_ROTATE_180             1001
#define ID_IMAGE_ROTATE_90CCW           1002
#define ID_IMAGE_FLIP_HORIZONTAL        1003
#define ID_IMAGE_FLIP_VERTICAL          1004
#define ID_FILE_CLEAR                   1100

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
