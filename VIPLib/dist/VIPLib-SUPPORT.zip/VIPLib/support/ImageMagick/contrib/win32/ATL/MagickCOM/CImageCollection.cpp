// CImageCollection
#include "CImageCollection.h"
