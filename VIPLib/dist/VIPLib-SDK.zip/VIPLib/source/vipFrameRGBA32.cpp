/** @file vipFrameRGBA32.cpp
 *
 * File containing methods for the 'vipFrameRGBA32' class.
 * The header for this class can be found in vipFrameRGBA32.h, check
 * that file for class description.
 *
 *
 *
 ****************************************************************************
 * VIPLib Framework
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib
 *
 *  maintained by MultiMedia Laboratory - DIT - University of Trento
 *
 ****************************************************************************/



#include "vipFrameRGBA32.h"

vipFrameRGBA32::vipFrameRGBA32()  : vipFrame()
 {
	height = 0;
	width = 0;
	data = NULL;
	autoFreeData = true;
 }

/**
 * @brief Create an image with the given dimensions, allocates empty data.
 * @param width Width of the image
 * @param height Height of the image
 */
vipFrameRGBA32::vipFrameRGBA32(unsigned int w, unsigned int h)
 {
	data = NULL;
	reAllocCanvas(w, h);
	autoFreeData = true;
 }



/**
 * @brief Create an image from another image, copying memory.
 */
vipFrameRGBA32::vipFrameRGBA32(vipFrameRGBA32& img)
 {
	data = NULL;
	reAllocCanvas(img.width, img.height);

	if ( width != 0 && height != 0 )
		memcpy(data, img.data, width * height * 4);

	autoFreeData = true;
 }




/**
 * @brief Create an image from another image, copying memory.
 */
vipFrameRGBA32::vipFrameRGBA32(vipFrameRGB24& img)
 {
	data = NULL;
	reAllocCanvas(img.width, img.height);

	*this << img;

	autoFreeData = true;
 }

/**
 * @brief Create an image from another image, copying memory.
 */
vipFrameRGBA32::vipFrameRGBA32(vipFrameRGB96& img)
 {
	data = NULL;
	reAllocCanvas(img.width, img.height);

	*this << img;

	autoFreeData = true;
 }


/**
 * @brief Destructor currenly clear pixel data (array).
 */
vipFrameRGBA32::~vipFrameRGBA32()
 {
	INFO("vipFrameRGBA32::~vipFrameRGBA32() [DESTRUCTOR]")

	if ( autoFreeData && data != NULL )
		delete [] data;
 }


VIPRESULT vipFrameRGBA32::reAllocCanvas(unsigned int w, unsigned int h)
 {
	if (data != NULL)
		delete [] data;

	height = h;
	width = w;
	data = NULL;

	if ( width == 0 || height == 0)
		return VIPRET_PARAM_ERR;

	data = new unsigned char[width * height * 4];

	return VIPRET_OK;
 }

VIPRESULT vipFrameRGBA32::setBlack()
 {
	if (width == 0 || height == 0 || data == NULL)
		return VIPRET_ILLEGAL_USE;

	memset(data, '\0', width * height * 4 );

	return VIPRET_OK;
 }

VIPRESULT vipFrameRGBA32::setWhite()
 {
	if (width == 0 || height == 0 || data == NULL)
		return VIPRET_ILLEGAL_USE;

	memset(data, 255, width * height  * 4 );

	return VIPRET_OK;
 }

VIPRESULT vipFrameRGBA32::extractBrightness(unsigned char* buffer, unsigned int* size)
 {
	if (width == 0 || height == 0 || data == NULL)
		return VIPRET_ILLEGAL_USE;

	if (buffer == NULL)
	 {
		 if ( size == NULL)
		 	return VIPRET_PARAM_ERR;

		 *size = width*height;
		 return VIPRET_OK;
	 }

	return VIPRET_NOT_IMPLEMENTED;
 }


/**
 * @brief Get pixel (x, y) value and store it to p.
 *
 * @param x x position of the pixel.
 * @param y y position of the pixel.
 * @param p address to store selected pixel's value.
 *
 * @note No check is made that x and y are in range.
 */
VIPRESULT vipFrameRGBA32::getPixel(unsigned int x, unsigned int y, unsigned char* p)
 {
	#ifdef _vipFrameRGBA32_SLOWMODE
		if ( x >= width || y >= height )
			throw "Invalid Coordinates in method vipFrameRGBA32::getPixel(unsigned int x, unsigned int y, PixelRGB& p)";
	#endif //_vipFrameRGBA32_SLOWMODE

	unsigned int offset = y * width + x;

	p[0] = data[offset];
	p[1] = data[offset + width*height];
	p[2] = data[offset + width*height*2];
	p[3] = data[offset + width*height*3];

	return VIPRET_OK;
 }

/**
 * @brief Set pixel (x, y) to the specified value.
 *
 * @param x x position of the pixel.
 * @param y y position of the pixel.
 * @param p new value for the selected coords.
 *
 * @note No check is made that x and y are in range.
 */
VIPRESULT vipFrameRGBA32::setPixel(unsigned int x, unsigned int y, unsigned char* p)
 {
	#ifdef _vipFrameRGBA32_SLOWMODE
		if ( x >= width || y >= height )
			throw "Invalid Coordinates in method vipFrameRGBA32::setPixel(unsigned int x, unsigned int y, PixelRGB p)";
	#endif //_vipFrameRGBA32_SLOWMODE

	data[y * width + x] = p[0];

	data[y * width + x + width*height] = p[1];
	data[y * width + x + width*height*2] = p[2];
	data[y * width + x + width*height*3] = p[3];

	return VIPRET_OK;
 }


/**
 * @brief Clear all pixel to the specified value.
 *
 * @param bg a PixelRGB to overwrite on all image.
 *
 * @return current instance address.
 */
vipFrameRGBA32& vipFrameRGBA32::clearWith(unsigned char* p)
 {
	if ( data == NULL || width == 0 || height == 0)
		throw "Image is empty.";


	memset(data, p[0], width * height );
	memset(data + width * height, p[1], width * height );
	memset(data + width * height * 2, p[2], width * height );
	memset(data + width * height * 3, p[3], width * height );

//CHECKBUGs

	return *this;
 }

/**
 * @brief Copies all pixel data from img.
 *        Throws an exception if images are of different size.
 *
 * @param img The image to copy the data from.
 *
 * @return current instance.
 */
vipFrameRGBA32& vipFrameRGBA32::operator = (vipFrameRGBA32& img)
 {
	/* check we're not trying to copy ourself */
	if (this == &img)
        	return *this;

	if (width != img.width || height != img.height)
		reAllocCanvas(img.width, img.height);

	if ( width == 0 || height == 0 )
		throw "Cannot do that with empty image (no size)";

	memcpy(data, img.data, width * height * 4);

	return *this;
 }


vipFrameRGBA32& vipFrameRGBA32::operator += (vipFrameRGBA32& img)
{
	INFO("vipFrameRGBA32& vipFrameRGBA32::operator += (vipFrameRGBA32& img)")

	if (width != img.width || height != img.height)
		throw "Difference in vipFrameYUV420 Dimensions";

    for(unsigned int i=0; i < width * height * 4; i++)
        data[i] += img.data[i];

    return *this;
}

vipFrameRGBA32& vipFrameRGBA32::operator -= (vipFrameRGBA32& img)
{
	INFO("vipFrameRGBA32& vipFrameRGBA32::operator += (vipFrameRGBA32& img)")

	if (width != img.width || height != img.height)
		throw "Difference in vipFrameYUV420 Dimensions";

    for(unsigned int i=0; i < width * height * 4; i++)
        data[i] -= img.data[i];

    return *this;
}



vipFrameRGBA32& vipFrameRGBA32::operator >> (vipFrameRGB24& img)
 {
	INFO("vipFrameRGBA32& vipFrameRGBA32::operator >> (vipFrameRGB24& img) [pushing data]")

	if ( width == 0 || height == 0 )
		throw "Cannot do that with empty image (no size)";

	if (width != img.width || height != img.height )
		img.reAllocCanvas(width, height);

	unsigned char* R = data;
	unsigned char* G = data + width*height;
	unsigned char* B = data + width*height*2;

	for (unsigned int i=0; i< width*height; i++)
	 {
		img.data[i][0] = *(R++);
		img.data[i][1] = *(G++);
		img.data[i][2] = *(B++);
	 }
//CHECKBUG

	return *this;
 }



vipFrameRGBA32& vipFrameRGBA32::operator >> (vipFrameRGB96& img)
 {
	INFO("vipFrameRGBA32& vipFrameRGBA32::operator >> (vipFrameRGB96& img) [pushing data]")

	if ( width == 0 || height == 0 )
		throw "Cannot do that with empty image (no size)";

	if (width != img.width || height != img.height )
		img.reAllocCanvas(width, height);

	unsigned char* R = data;
	unsigned char* G = data + width*height;
	unsigned char* B = data + width*height*2;

	for (unsigned int i=0; i< width*height; i++)
	 {
		img.data[i][0] = (int)*(R++);
		img.data[i][1] = (int)*(G++);
		img.data[i][2] = (int)*(B++);
	 }
//CHECKBUG

	return *this;
 }


void vipFrameRGBA32::operator << (const vipFrameRGB24& img)
{
	INFO("void vipFrameRGBA32::operator << (const vipFrameRGB24& img) [importing data]")

	if ( img.width == 0 || img.height == 0 )
		throw "Cannot do that with empty image (no size)";

	if (width != img.width || height != img.height)
		reAllocCanvas(img.width, img.height);

	memset(data + width * height * 3, '\0', width * height );

	unsigned char* R = data;
	unsigned char* G = data + width*height;
	unsigned char* B = data + width*height*2;

	for (unsigned int i=0; i< width*height; i++)
	 {
		*(R++) = img.data[i][0];
		*(G++) = img.data[i][1];
		*(B++) = img.data[i][2];
	 }

//CHECKBUG

 }

void vipFrameRGBA32::operator << (const vipFrameRGB96& img)
{
	INFO("void vipFrameRGBA32::operator << (const vipFrameRGB96& img) [importing data]")

	if ( img.width == 0 || img.height == 0 )
		throw "Cannot do that with empty image (no size)";

	if (width != img.width || height != img.height)
		reAllocCanvas(img.width, img.height);

	memset(data + width * height * 3, '\0', width * height );

	unsigned char* R = data;
	unsigned char* G = data + width*height;
	unsigned char* B = data + width*height*2;

	for (unsigned int i=0; i< width*height; i++)
	 {
		*(R++) = (unsigned char)img.data[i][0];
		*(G++) = (unsigned char)img.data[i][1];
		*(B++) = (unsigned char)img.data[i][2];
	 }

//CHECKBUG

 }







