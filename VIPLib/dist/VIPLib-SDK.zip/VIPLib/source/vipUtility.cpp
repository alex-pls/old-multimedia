/** @file vipUtility.cpp
 *
 * File containing methods for the 'vipUtility' class.
 * The header for this class can be found in vipUtility.h, check that file
 * for class description.
 *
 *
 *
 ****************************************************************************
 * VIPLib Framework
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib
 *
 *  maintained by MultiMedia Laboratory - DIT - University of Trento
 *
 ****************************************************************************/




#include "vipUtility.h"

#include <stdio.h>
#include "../include/ccvt/ccvt.h"



////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
#include <string.h>
char* vipUtility::getTypeNameFromClassTypeID(int classType_id)
 {
	char* ret = new char[32];

	switch( classType_id )
	 {
		case VIPCLASS_TYPE_FRAME	: strcpy(ret, "vipFrame");
		case VIPCLASS_TYPE_BUFFER	: strcpy(ret, "vipBuffer");
		case VIPCLASS_TYPE_INPUT	: strcpy(ret, "vipInput");
		case VIPCLASS_TYPE_OUTPUT	: strcpy(ret, "vipOutput");
		case VIPCLASS_TYPE_FILTER	: strcpy(ret, "vipFilter");
		case VIPCLASS_TYPE_CODEC	: strcpy(ret, "vipCodec");
		case VIPCLASS_TYPE_VISION	: strcpy(ret, "vipVision");
		default						: strcpy(ret, "UNKNOWN");
	 }
	return ret;
 }


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

/*
void rgb555_rgb(void* src, void* dst, int width,int height)
 {

	unsigned int* srcPtr = (unsigned int*)src;

	for (unsigned int i = 0; i < width*height; i++)
	 {
		*(dst++) = bitcopy_n(srcPtr >> (10 - 3), 3);
		*(dst++) = bitcopy_n(srcPtr >> (5 - 3), 3);
		*(dst++) = bitcopy_n(srcPtr << 3, 3);
	 }


 }


void vipUtility::conv_420p_rgb96(int width,int height,void* src,void* dst)
{
	static unsigned int oldSize = 0;
	static unsigned char* rgb;
//static ?

	unsigned int size = width * height;

	// reallocate memory if the sizes have changed
	if (oldSize < size) {
		delete [] rgb;
		rgb = new  unsigned char [size * 4];
	}

	// set up all the pointers
	unsigned char	*s = (unsigned char *)src;
	int		*d = (int *)dst;

	static unsigned int offset_U = size;
	static unsigned int offset_V = size + size / 4;

	unsigned char* 	Y = s;
	unsigned char*	U = s + offset_U;
	unsigned char*	V = s + offset_V;

	// convert away
	ccvt_420p_rgb32(width, height, Y, U, V, rgb);
	conv_rgb32_rgb96(width, height, rgb, d);
}
*/

void vipUtility::conv_420p_grey(int width,int height,void *src,void *dst)
{
	unsigned char	*s = (unsigned char *)src;
	int		*d = (int *)dst;

	unsigned int size = width * height;

	for (unsigned int i = 0; i < size; i++)
         *(d++) = *(s++);
}


void vipUtility::conv_bgr24_rgb96(void *src, unsigned char *dst, unsigned int width, unsigned int height)
{
//BUG
	unsigned char*  s = (unsigned char*)src ;
	unsigned char* d = dst + 2 ;

	for (unsigned int i = 0; i < width*height; i++, d+=5)
	 {
		*(d--) = *(s++);
		*(d--) = *(s++);
		*(d) = *(s++);
	 }

}

/*
void conv_rgb24_rgb96(int width, int height, void *src, unsigned char *d)
{
	unsigned char**	rows = (unsigned char**) src;
	unsigned char*	s;

	for (int j = 0; j < height; j++) {
		s = rows[j];

		for (int i = 0; i < width; i++) {
			*(d++) = *(s++);
			*(d++) = *(s++);
			*(d++) = *(s++);
		}
	}
}

	unsigned char* s = (unsigned char*)src;
	unsigned char* d = dst;

	for (unsigned int i = 0; i < width * height; i++) {
		*(d++) = *(s++);
		*(d++) = *(s++);
		*(d++) = *(s++);
	}
*/
void vipUtility::conv_rgb24_rgb96(void *src, unsigned char *dst, unsigned int width, unsigned int height)
{
	unsigned char**	rows = (unsigned char**) src;
	unsigned char*	s;
	unsigned char* d = dst;

	for (unsigned int j = 0; j < height; j++) {
		s = rows[j];

		for (unsigned int i = 0; i < width; i++) {
			*(d++) = *(s++);
			*(d++) = *(s++);
			*(d++) = *(s++);
		}
	}
}

void vipUtility::conv_rgb24_rgb96_(void *src, int *dst, unsigned int width, unsigned int height)
{
	unsigned char**	rows = (unsigned char**) src;
	unsigned char*	s;
	int* d = dst;

	for (unsigned int j = 0; j < height; j++) {
		s = rows[j];

		for (unsigned int i = 0; i < width; i++) {
			*(d++) = *(s++);
			*(d++) = *(s++);
			*(d++) = *(s++);
		}
	}
}

void vipUtility::conv_rgb32_rgb96(int width,int height,void *src,void *dst)
{
	unsigned char	*s = (unsigned char *)src;
	int		*d = (int *)dst;

	unsigned int size = width * height;

	for (unsigned int i = 0; i < size; i++, s++) {
		*(d++) = *(s++);
		*(d++) = *(s++);
		*(d++) = *(s++);
	}
}







/* Functions in ccvt_i386.S/ccvt_c.c */
/* 4:2:0 YUV interlaced to RGB 24bit */
/*
VIPRESULT vipUtility::conv_420i_rgb24( void* dataIn, vipFrameRGB24& img)
 {
	if ( &img == NULL || dataIn == NULL || img.width == 0 || img.height == 0 )
		return VIPRET_PARAM_ERR;

	ccvt_420i_rgb24(img.width, img.height, dataIn, (unsigned char*)img.data[0] );

	return VIPRET_OK;
 }
*/
/* Functions in ccvt_i386.S/ccvt_c.c */
/* RGB to 4:2:0 YUV planar     */
/*
VIPRESULT vipUtility::conv_rgb24_420p(vipFrameRGB24& img, void *dsty, void *dstu, void *dstv)
 {
	if ( &img == NULL || dsty == NULL || dstu == NULL ||  dstv == NULL || img.width == 0 || img.height == 0 )
		return VIPRET_PARAM_ERR;

	ccvt_rgb24_420p(img.width, img.height, (unsigned char*)img.data[0], dsty, dstu, dstv);

	return VIPRET_OK;
 }
*/


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*
European TV (PAL and SECAM coded) uses Y'U'V' components. Y' is similar to
perceived luminance, U' and V' carry the colour information and some
luminance information and are bipolar (they go negative as well as positive).
The symbols U and V here are not related to the U and V of CIE YUV (1960).

This coding is also used in some 525 line systems with PAL subcarriers,
particularly in parts of the Americas. The specification here is that of the
European Broadcasting Union (EBU). Y' has a bandwidth of 5 MHz in Europe,
5.5 MHz in UK. The U' and V' signals usually have up to 2.5 MHz bandwidth
in a component studio system, but can be as little as 600 kHz or less in a
VHS recorder. U' and V' always have the same bandwidth as each other. The
CRT gamma law is assumed to be 2.8, but camera correction laws are the same
as in all other systems (approximately 0.45). The system white point is D65,
the chromaticity coordinates are:

    R:      xr=0.64      yr=0.33
    G:      xg=0.29      yg=0.60
    B:      xb=0.15      yb=0.06
    White:  xn=0.312713  yn=0.329016

The conversion equations for linear signals are:-
*/
double cvm_rgb_yuv[] =	{
							0.431, 0.342, 0.178,
							0.222, 0.707, 0.071,
							0.020, 0.130, 0.939
						};
double cvm_yuv_rgb[] =	{
							 3.063, -1.393, -0.476,
							-0.969,  1.876,  0.042,
							 0.068, -0.229,  1.069
						};


/*
template<class T, class S>
VIPRESULT vipUtility::conv_rgb_yuv(T* out, S* in, unsigned int width, unsigned int height)
 {
	return conv_linear(out, in, cvm_yuv_rgb, width, height);
 }
*/

template<class T, class S>
VIPRESULT vipUtility::conv_yuv_rgb(T* out, S* in, unsigned int width, unsigned int height)
 {
	return conv_linear(out, in, cvm_rgb_yuv, width, height);
 }


////////////////////////////////////////////////////////////////////////////////
/*
The YIQ system is the color primary system adopted by National Television System Committee (NTSC) for color TV broadcasting. The YIQ color solid is made by a linear transformation of the RGB cube. Its purpose is to exploit certain characteristics of the human eye to maximize the utilization of a fixed bandwidth. The human visual system is more sensitive to changes in luminance than to changes in hue or saturation, and thus a wider bandwidth should be dedicated to luminance than to color information. Y is similar to perceived luminance, I and Q carry color information and some luminance information. The Y signal usually has 4.2 MHz bandwidth in a 525 line system. Originally, the I and Q had different bandwidths (1.5 and 0.6 MHz), but now they commonly have the same bandwidth of 1 MHz.

*/
double cvm_rgb_yiq[] =	{
							0.299,  0.587,  0.114,
							0.596, -0.275, -0.321,
							0.212, -0.523,  0.311
						};
double cvm_yiq_rgb[] =	{
							1,  0.956,  0.621,
							1, -0.272, -0.647,
							1, -1.105,  1.702
    						};


template<class T, class S>
VIPRESULT vipUtility::conv_rgb_yiq(T* out, S* in, unsigned int width, unsigned int height)
 {
	return conv_linear(out, in, cvm_rgb_yiq, width, height);
 }


template<class T, class S>
VIPRESULT vipUtility::conv_yiq_rgb(T* out, S* in, unsigned int width, unsigned int height)
 {
	return conv_linear(out, in, cvm_yiq_rgb, width, height);
 }
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*
SMPTE-C is the current colour standard for broadcasting in America, the old
NTSC standard for primaries is no longer in wide use because the primaries
of the system have gradually shifted towards those of the EBU
(see section 6.2). In all other respects, SMPTE-C is the same as NTSC.
The CRT gamma law is assumed to be 2.2. The white point is now D65, and
the chromaticities are:

    R:     xr=0.630     yr=0.340
    G:     xg=0.310     yg=0.595
    B:     xb=0.155     yb=0.070
    White: xn=0.312713  yn=0.329016

The conversion equations for linear signals are:
*/
double cvm_rgb_smpte_c[] =	{
								0.3935, 0.3653, 0.1916,
								0.2124, 0.7011, 0.0866,
								0.0187, 0.1119, 0.9582
						};
double cvm_smpte_c_rgb[] =	{
								 3.5058, -1.7397, -0.5440,
								-1.0690,  1.9778,  0.0352,
								 0.0563, -0.1970,  1.0501
    						};


template<class T, class S>
VIPRESULT vipUtility::conv_rgb_smpte_c(T* out, S* in, unsigned int width, unsigned int height)
 {
	return conv_linear(out, in, cvm_rgb_smpte_c, width, height);
 }


template<class T, class S>
VIPRESULT vipUtility::conv_smpte_c_rgb(T* out, S* in, unsigned int width, unsigned int height)
 {
	return conv_linear(out, in, cvm_smpte_c_rgb, width, height);
 }


////////////////////////////////////////////////////////////////////////////////


/*
RGB values in a particular set of primaries can be transformed to and from CIE XYZ via a 3x3 matrix transform. These transforms involve tristimulus values, that is a set of three linear-light components that conform to the CIE color-matching functions. CIE XYZ is a special set of tristimulus values. In XYZ, any color is represented as a set of positive values.

To transform from XYZ to RGB (with D65 white point), the matrix transform used is [3]:

   [ R ]   [  3.240479 -1.537150 -0.498535 ]   [ X ]
   [ G ] = [ -0.969256  1.875992  0.041556 ] * [ Y ]
   [ B ]   [  0.055648 -0.204043  1.057311 ]   [ Z ].

The range for valid R, G, B values is [0,1]. Note, this matrix has negative coefficients. Some XYZ color may be transformed to RGB values that are negative or greater than one. This means that not all visible colors can be produced using the RGB system.

The inverse transformation matrix is as follows:

   [ X ]   [  0.412453  0.357580  0.180423 ]   [ R ] **
   [ Y ] = [  0.212671  0.715160  0.072169 ] * [ G ]
   [ Z ]   [  0.019334  0.119193  0.950227 ]   [ B ].

*/
double cvm_rgb_xyz[] =	{
							0.412453, 0.357580, 0.180423,
							0.212671, 0.715160, 0.072169,
							0.019334, 0.119193, 0.950227
						};
double cvm_xyz_rgb[] =	{
							 3.240479, -1.537150, -0.498535,
							-0.969256,  1.875992,  0.041556,
							 0.055648, -0.204043,  1.057311
    						};

//BUG
template<class T, class S>
VIPRESULT vipUtility::conv_rgb_xyz(T* out, S* in, unsigned int width, unsigned int height)
 {
	return conv_linear(out, in, cvm_rgb_xyz, width, height);
 }


template<class T, class S>
VIPRESULT vipUtility::conv_xyz_rgb(T* out, S* in, unsigned int width, unsigned int height)
 {
	return conv_linear(out, in, cvm_xyz_rgb, width, height);
 }




////////////////////////////////////////////////////////////////////////////////
/*
[6.5] ITU.BT-709 HDTV studio production in Y'CbCr

This is a recent standard, defined only as an interim standard for HDTV
studio production. It was defined by the CCIR (now the ITU) in 1988, but is
not yet recommended for use in broadcasting. The primaries are the R and B
from the EBU, and a G which is midway between SMPTE-C and EBU. The CRT gamma
law is assumed to be 2.2. White is D65. The chromaticities are:
    R:      xr=0.64       yr=0.33
    G:      xg=0.30       yg=0.60
    B:      xb=0.15       yb=0.06
    White:  xn=0.312713   yn=0.329016

The conversion equations for linear signals are:
*/
double cvm_rgb_bt709[] =	{
							0.412, 0.358, 0.180,
							0.213, 0.715, 0.072,
							0.019, 0.119, 0.950
						};
double cvm_bt709_rgb[] =	{
							 3.241, -1.537, -0.499,
							-0.969,  1.876,  0.042,
							 0.056, -0.204,  1.057
   						};


template<class T, class S>
VIPRESULT vipUtility::conv_rgb_bt709(T* out, S* in, unsigned int width, unsigned int height)
 {
	return conv_linear(out, in, cvm_rgb_bt709, width, height);
 }


template<class T, class S>
VIPRESULT vipUtility::conv_bt709_rgb(T* out, S* in, unsigned int width, unsigned int height)
 {
	return conv_linear(out, in, cvm_bt709_rgb, width, height);
 }


////////////////////////////////////////////////////////////////////////////////
/*
[6.6] SMPTE-240M Y'PbPr

This one of the developments of NTSC component coding, in which the B primary
and white point were changed. The CRT gamma law is assumed to be 2.2. The
white point is D65, chromaticity coordinates are:
    R:      xr=0.67     yr=0.33
    G:      xg=0.21     yg=0.71
    B:      xb=0.15     yb=0.06
    White:  xn=0.312713 yn=0.329016

The conversion equations for linear signals are:
*/
double cvm_rgb_smpte240m[] =	{
							0.567, 0.190, 0.193,
							0.279, 0.643, 0.077,
							0.000, 0.073, 1.016
						};
double cvm_smpte240m_rgb[] =	{
							 2.042, -0.565, -0.345,
							-0.894,  1.815,  0.032,
							 0.064, -0.129,  0.912
						};


template<class T, class S>
VIPRESULT vipUtility::conv_rgb_smpte240m(T* out, S* in, unsigned int width, unsigned int height)
 {
	return conv_linear(out, in, cvm_rgb_smpte240m, width, height);
 }


template<class T, class S>
VIPRESULT vipUtility::conv_smpte240m_rgb(T* out, S* in, unsigned int width, unsigned int height)
 {
	return conv_linear(out, in, cvm_smpte240m_rgb, width, height);
 }




////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////


void yuv422to420p(unsigned char *map, unsigned char *cap_map, int width, int height)
{
	unsigned char *src, *dest, *src2, *dest2;
	int i, j;

	/* Create the Y plane */
	src=cap_map;
	dest=map;
	for (i=width*height; i; i--) {
		*dest++=*src;
		src+=2;
	}
	/* Create U and V planes */
	src=cap_map+1;
	src2=cap_map+width*2+1;
	dest=map+width*height;
	dest2=dest+(width*height)/4;
	for (i=height/2; i; i--) {
		for (j=width/2; j; j--) {
			*dest=((int)*src+(int)*src2)/2;
			src+=2;
			src2+=2;
			dest++;
			*dest2=((int)*src+(int)*src2)/2;
			src+=2;
			src2+=2;
			dest2++;
		}
		src+=width*2;
		src2+=width*2;
	}
}

// this is bgr !
void rgb24toyuv420p(unsigned char *map, unsigned char *cap_map, int width, int height)
{
	unsigned char *y, *u, *v;
	unsigned char *r, *g, *b;
	int i, loop;

	b=cap_map;
	g=b+1;
	r=g+1;
	y=map;
	u=y+width*height;
	v=u+(width*height)/4;
	memset(u, 0, width*height/4);
	memset(v, 0, width*height/4);

	for(loop=0; loop<height; loop++) {
		for(i=0; i<width; i+=2) {
			*y++=(9796**r+19235**g+3736**b)>>15;
			*u+=((-4784**r-9437**g+14221**b)>>17)+32;
			*v+=((20218**r-16941**g-3277**b)>>17)+32;
			r+=3;
			g+=3;
			b+=3;
			*y++=(9796**r+19235**g+3736**b)>>15;
			*u+=((-4784**r-9437**g+14221**b)>>17)+32;
			*v+=((20218**r-16941**g-3277**b)>>17)+32;
			r+=3;
			g+=3;
			b+=3;
			u++;
			v++;
		}

		if ((loop & 1) == 0)
		{
			u-=width/2;
			v-=width/2;
		}
	}
}


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////




/* Colour ConVerT: going from one colour space to another

   Format descriptions:
   420i = "4:2:0 interlaced"
           YYYY UU YYYY UU   even lines
           YYYY VV YYYY VV   odd lines
           U/V data is subsampled by 2 both in horizontal
           and vertical directions, and intermixed with the Y values.

   420p = "4:2:0 planar"
           YYYYYYYY      N lines
           UUUU          N/2 lines
           VVVV          N/2 lines
           U/V is again subsampled, but all the Ys, Us and Vs are placed
           together in separate buffers. The buffers may be placed in
           one piece of contiguous memory though, with Y buffer first,
           followed by U, followed by V.

   yuyv = "4:2:2 interlaced"
           YUYV YUYV YUYV ...   N lines
           The U/V data is subsampled by 2 in horizontal direction only.

   bgr24 = 3 bytes per pixel, in the order Blue Green Red (whoever came up
           with that idea...)
   rgb24 = 3 bytes per pixel, in the order Red Green Blue (which is sensible)
   rgb32 = 4 bytes per pixel, in the order Red Green Blue Alpha, with
           Alpha really being a filler byte (0)
   bgr32 = last but not least, 4 bytes per pixel, in the order Blue Green Red
           Alpha, Alpha again a filler byte (0)
 */

/* Functions in ccvt_i386.S/ccvt_c.c */

/* 4:2:0 YUV planar to RGB/BGR     */
//void ccvt_420p_rgb32(int width, int height, void *srcy, void *srcu, void *srcv, void *dst);
//void ccvt_420p_bgr32(int width, int height, void *srcy, void *srcu, void *srcv, void *dst);

/* RGB/BGR to 4:2:0 YUV interlaced */

/* RGB/BGR to 4:2:0 YUV planar     */
//void ccvt_rgb24_420p(int width, int height, void *src, void *dsty, void *dstu, void *dstv);
//void ccvt_bgr24_420p(int width, int height, void *src, void *dsty, void *dstu, void *dstv);

/* Go from 420i to other yuv formats */
//void ccvt_420i_420p(int width, int height, void *src, void *dsty, void *dstu, void *dstv);
//void ccvt_420i_yuyv(int width, int height, void *src, void *dst);



//void ccvt_420i_bgr24(int width, int height, void *src, void *dst);
//void ccvt_420i_bgr32(int width, int height, void *src, void *dst);























// SLEEPING ROUTINES, OS DEPENDENT


#if defined(sun)        || defined(__sun)       || defined(linux)       || defined(__linux)    \
 || defined(__CYGWIN__) || defined(__FreeBSD__) || defined(__OPENBSD__) || defined(__MACOSX__) \
 || defined(__APPLE__)  || defined(sgi)         || defined(__sgi)
// Unix (Linux,Solaris,BSD,Irix,...)

	#include <unistd.h>
	#include <time.h>


	// got problems using usleep(millisec), and this is great :P
	void vipUtility::vipSleep(long millisec)
	 {
		if (millisec == 0)
			return;

		double offset = clock() * 1000000 / CLOCKS_PER_SEC;

		while (offset + millisec*1000  >= clock() * 1000000 / CLOCKS_PER_SEC) ;
	 }


	/* returns time in micro-s*/
	double vipUtility::getTime_usec()
	 {
		clock_t clk;
		clk = clock();
		return clk * 1000000 / CLOCKS_PER_SEC;
	 }

#elif defined(_WIN32) || defined(__WIN32__)
// Windows

	#include <windows.h>
	#include <time.h>	/* for gettimeofday */

	void vipUtility::vipSleep(long millisec)
	 {
		Sleep(millisec);
	 }


	/* returns time in micro-s*/

//BUG
	double vipUtility::getTime_usec()
	 {
//		struct timeval  tv;
//		gettimeofday(&tv, 0);
		return -1;
	 }
/*
#else
// Unknown configuration : compile with minimal dependencies.


	void vipUtility::vipSleep(long millisec)
	 {
		;
	 }


//BUG
	double vipUtility::getTime_usec()
	 {
//		struct timeval  tv;
//		gettimeofday(&tv, 0);
		return -1;
	 }
*/
#endif




