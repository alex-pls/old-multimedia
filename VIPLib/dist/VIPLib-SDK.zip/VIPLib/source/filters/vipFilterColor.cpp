/** @file vipFilterColor.cpp
 *
 * File containing methods for the 'vipFilterColor' class.
 * The header for this class can be found in vipFilterColor.h, check
 * that file for class description.
 *
 *
 ****************************************************************************
 * VIPLib Framework
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib
 *
 *  maintained by MultiMedia Laboratory - DIT - University of Trento
 *
 ****************************************************************************/




 #include "vipFilterColor.h"


/**
 * @brief  Default constructor, initialize parameters and superclasses.
 * @param[in] initParams parameters for this module or NULL for defaults.
 */
vipFilterColor::vipFilterColor(vipFilterColorParameters* initParams) : vipFilter()
 {
	INFO("vipFilterColor::vipFilterColor(..* initParams) : vipFilter() [CONTRUCTOR]")

	setParameters(initParams);
	reset();

	setName("Colors Editing Filter");
	setDescription("Posterize, Nagative....");
	setVersion(1.0);

 }

/**
 * @brief Default destructor, free buffer.
 */
vipFilterColor::~vipFilterColor()
 {
	INFO("vipFilterColor::~vipFilterColor() [DESTRUCTOR]")

	if (myParams != NULL)
		delete myParams;//BUG
	myParams = NULL;

 }

/**
 * @brief  Set parameters for this filter.
 *
 * @param[in] initParams Instance of vipFilterColorParameters or NULL,
 *                       NULL argument make function to create a new
 *                       instance with default parameters.
 *
 * @return VIPRET_OK
 */
VIPRESULT vipFilterColor::setParameters (vipFilterColorParameters* initParams)
 {

	if ( initParams == NULL )
		myParams = new vipFilterColorParameters();
	else
		myParams = initParams;

	allocateBuffer(myParams->currentBuffer);

	return VIPRET_OK;
 }

/**
 * @brief  Get parameters for this filter.
 *
 * @return pointer to vipFilterColorParameters instance.
 */
VIPRESULT vipFilterColor::reset()
 {
	INFO("VIPRESULT vipFilterColor::reset() [SET DEFAULT PARAMETERS]")

	releaseBuffers();

	if (myParams != NULL)
	 {
		myParams->reset();
		allocateBuffer(myParams->currentBuffer);
	 }
	else
		setParameters(NULL);

	return VIPRET_OK;
 }


/**
 * @brief Process the frame with current settings and store in buffer.
 *
 * @param[in] img VIPLibb Cache Frame to be processed.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
 *
 * @note  Input operator (<<) call directly this function.
 * @see   operator << (vipFrameYUV420&)
 */
VIPRESULT vipFilterColor::importFrom(vipFrameYUV420& img)
 {
	DEBUGMSG("VIPRESULT vipFilterColor::importFrom(vipFrameYUV420& img) [reading data]", myParams->runMode)

	switch ( myParams->runMode )
	 {
	 case vipFilterColorParameters::DO_NOTHING:
			if ( !isBufferYUV() )
			 {
				useBufferYUV(img.width, img.height);
				*bufferYUV = img;
				return VIPRET_OK_DEPRECATED;
			 }
			else
			 {
				*bufferYUV = img;
				return VIPRET_OK;
			 }

	 case vipFilterColorParameters::CLAMP:
			return clamp(img, myParams->currBpp);

	 case vipFilterColorParameters::INVERT:
			return invert(img, myParams->currBpp);

	 case vipFilterColorParameters::EXTRACTBITPLANE:
			return extractBitPlane(img, myParams->currBits);

	 default:
		  return VIPRET_PARAM_ERR;
	 }
 }


/**
 * @brief Process the frame with current settings and store in buffer.
 *
 * @param[in] img VIPLibb Cache24 Frame to be processed.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
 *
 * @note  Input operator (<<) call directly this function.
 * @see   operator << (vipFrameRGB24&)
 */
VIPRESULT vipFilterColor::importFrom(vipFrameRGB24& img)
 {
	DEBUGMSG("VIPRESULT vipFilterColor::importFrom(vipFrameYUV420& img) [reading data]", myParams->runMode)

	switch ( myParams->runMode )
	 {
	 case vipFilterColorParameters::DO_NOTHING:
			if ( !isBufferRGB() )
			 {
				useBufferRGB(img.width, img.height);
				*bufferRGB = img;
				return VIPRET_OK_DEPRECATED;
			 }
			else
			 {
				*bufferRGB = img;

				return VIPRET_OK;
			 }

	 case vipFilterColorParameters::CLAMP:
			return clamp(img, myParams->currBpp);

	 case vipFilterColorParameters::INVERT:
			return invert(img, myParams->currBpp);

	 case vipFilterColorParameters::EXTRACTBITPLANE:
			return extractBitPlane(img, myParams->currBits);

	 default:
		  return VIPRET_PARAM_ERR;
	 }
 }

/**
 * @brief Process the frame with current settings and store in buffer.
 *
 * @param[in] img VIPLibb Grayscale Frame to be processed.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
 *
 * @note  Input operator (<<) call directly this function.
 * @see   operator << (vipFrameT&)
 */
VIPRESULT vipFilterColor::importFrom(vipFrameT<unsigned char>& img)
 {
	DEBUGMSG("VIPRESULT vipFilterColor::importFrom(vipFrameT<unsigned char>& img) [reading data]", myParams->runMode)

	switch ( myParams->runMode )
	 {
	 case vipFilterColorParameters::DO_NOTHING:
			if ( !isBufferTuC() )
			 {
				useBufferTuC(img.width, img.height, img.profile);
				*bufferTuC = img;
				return VIPRET_OK_DEPRECATED;
			 }
			else
			 {
				*bufferTuC = img;
				return VIPRET_OK;
			 }


	 case vipFilterColorParameters::CLAMP:
			return clamp(img, myParams->currBpp);

	 case vipFilterColorParameters::INVERT:
			return invert(img, myParams->currBpp);

	 case vipFilterColorParameters::EXTRACTBITPLANE:
			return extractBitPlane(img, myParams->currBits);

	 default:
		  return VIPRET_PARAM_ERR;
	 }
 }


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////



//taglia tutti i valori saturi e negativi
VIPRESULT vipFilterColor::clamp(vipFrameYUV420& img, unsigned int bpp)//=sizeof(int)*3
 {

	return VIPRET_NOT_IMPLEMENTED;
 }

//taglia tutti i valori saturi
VIPRESULT vipFilterColor::clamp(vipFrameRGB24& img, unsigned int bpp)
 {
//CHECKBUGS
	if ( bpp >= sizeof(unsigned char)*3 )
		return VIPRET_PARAM_ERR;

	useBufferRGB(img.width, img.height);

	for (unsigned int i=0; i < img.width * img.height; i++ )
	 {
		if ( img.data[i][0] > (unsigned char)( (1<<bpp)/3) )
			bufferRGB->data[i][0] = (unsigned char)( (1<<bpp)/3);
		else
			bufferRGB->data[i][0] = img.data[i][0];

		if ( img.data[i][1] > (unsigned char)( (1<<bpp)/3) )
			bufferRGB->data[i][1] = (unsigned char)( (1<<bpp)/3);
		else
			bufferRGB->data[i][1] = img.data[i][1];

		if ( img.data[i][1] > (unsigned char)( (1<<bpp)/3) )
			bufferRGB->data[i][1] = (unsigned char)( (1<<bpp)/3);
		else
			bufferRGB->data[i][2] = img.data[i][2];

	 }
	return VIPRET_OK;
 }

//taglia tutti i valori saturi e negativi
VIPRESULT vipFilterColor::clamp(vipFrameT<unsigned char>& img, unsigned int bpp)//=sizeof(int)*3
 {

	return VIPRET_NOT_IMPLEMENTED;
 }


VIPRESULT vipFilterColor::invert(vipFrameYUV420& img, unsigned int bpp)//=sizeof(int)*3
 {

	return VIPRET_NOT_IMPLEMENTED;
 }

VIPRESULT vipFilterColor::invert(vipFrameRGB24& img, unsigned int bpp)//=sizeof(int)*3
 {
//CHECKBUGS

	int maxVal = (1<<bpp)/3-1;

	useBufferRGB(img.width, img.height);

	for (unsigned int i=0; i < img.width * img.height; i++ )
	 {
		bufferRGB->data[i][0] = maxVal - img.data[i][0];
		bufferRGB->data[i][1] = maxVal - img.data[i][1];
		bufferRGB->data[i][2] = maxVal - img.data[i][2];
	 }

	return VIPRET_OK;
 }
VIPRESULT vipFilterColor::invert(vipFrameT<unsigned char>& img, unsigned int bpp)//=sizeof(int)*3
 {

	return VIPRET_NOT_IMPLEMENTED;
 }


VIPRESULT vipFilterColor::extractBitPlane(vipFrameRGB24& img, unsigned int bits)//=1
 {
//CHECKBUGS

	int mask = (1<<bits)/3-1;

	useBufferRGB(img.width, img.height);

	for (unsigned int i=0; i < img.width * img.height; i++ )
	 {
		bufferRGB->data[i][0] = (img.data[i][0] & mask) != 0;
		bufferRGB->data[i][1] = (img.data[i][1] & mask) != 0;
		bufferRGB->data[i][2] = (img.data[i][2] & mask) != 0;
	 }

	return VIPRET_OK;
 }


VIPRESULT vipFilterColor::extractBitPlane(vipFrameYUV420& img, unsigned int bits)//=1
 {
	return VIPRET_NOT_IMPLEMENTED;
 }

VIPRESULT vipFilterColor::extractBitPlane(vipFrameT<unsigned char>& img, unsigned int bits)//=1
 {
	return VIPRET_NOT_IMPLEMENTED;
 }























vipFilterColorParameters::vipFilterColorParameters(RUNMODE mode)
 {
	runMode = mode;
	reset();
 }

void vipFilterColorParameters::reset()
 {
	runMode = vipFilterColorParameters::DO_NOTHING;
	currBpp = sizeof(int);
	currBits = 1;
	currentBuffer = vipFilterParameters::NONE;
 }

int vipFilterColorParameters::saveToStreamXML(FILE *fp)
 {

	if ( fp == NULL )
		return VIPRET_PARAM_ERR;

	if( fprintf(fp, "<vipFilterColorParameters>\n") == EOF )
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <runmode value=\"%i\" />\n", (int)runMode) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <currBpp value=\"%u\" />\n", currBpp) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <currBits value=\"%u\" />\n", currBits) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <internalBufferType value=\"%u\" />\n", (int)currentBuffer) == EOF)
		return VIPRET_INTERNAL_ERR;

	if( fprintf(fp, "</vipFilterColorParameters>\n") == EOF )
		return VIPRET_INTERNAL_ERR;

	return VIPRET_OK;
 }


int vipFilterColorParameters::loadFromStreamXML(FILE *fp)
 {
	if ( fscanf(fp, "<vipFilterColorParameters>\n") == EOF )
		throw "error in XML file, unable to import data.";

	int runTmp = 0;
	if ( fscanf(fp, "  <runmode value=\"%i\" />\n", &runTmp) == EOF )
		throw "error in XML file, unable to import data.";
	else
		runMode = (RUNMODE)runTmp;

	if ( fscanf(fp, "  <currBpp value=\"%u\" />\n", &currBpp) == EOF )
		throw "error in XML file, unable to import data.";

	if ( fscanf(fp, "  <currBits value=\"%u\" />\n", &currBits) == EOF )
		throw "error in XML file, unable to import data.";

	int cB = (int)currentBuffer;
	if ( fscanf(fp, "  <internalBufferType value=\"%u\" />\n", &cB) == EOF )
		throw "error in XML file, unable to import data.";
	currentBuffer = (BUFFER_TYPE)cB;

	return VIPRET_OK;
 }




