/**
 *  @class   vipFilterColor
 *
 *  @brief
 *
 *
 *  @bug
 *  @warning
 *  @todo
 *
 *  @see     vipFilter
 *  @example ../../tests/test_vipFilterColor.cpp
 *
 *  @version 0.2
 *  @date    12/07/2005 - //2005
 *  @author  Alessandro Polo
 *
 *
 ****************************************************************************
 * VIPLib Framework
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib
 *
 *  maintained by MultiMedia Laboratory - DIT - University of Trento
 *
 ****************************************************************************/



#ifndef __VIPLIB_VIPFILTERCOLOR_H__
 #define __VIPLIB_VIPFILTERCOLOR_H__

 #include "../vipDefs.h"
 #include "../vipFilter.h"

 #include "../vipFrameYUV420.h"
 #include "../vipFrameRGB24.h"
 #include "../vipFrameT.h"


class vipFilterColorParameters : public vipFilterParameters
{
	public:

		enum RUNMODE{ DO_NOTHING, SOLARIZE, POSTERIZE, CLAMP, INVERT, EXTRACTBITPLANE };

	protected:

		RUNMODE runMode;

		unsigned int currBpp;
		unsigned int currBits;

		friend class vipFilterColor;


	public:

		vipFilterColorParameters(RUNMODE mode = vipFilterColorParameters::DO_NOTHING);
		~vipFilterColorParameters() {}

		void reset();

		void setRunMode(RUNMODE mode) { runMode = mode; };
		RUNMODE getRunMode() { return runMode; };

		void setWorkingBpp(unsigned int value) { currBpp = value; };
		unsigned int getWorkingBpp() { return currBpp; };

		void setBitPlaneBits(unsigned int value) { currBits = value; };
		unsigned int getBitPlaneBits() { return currBits; };


		VIPRESULT saveToStreamXML(FILE *fp);
		VIPRESULT loadFromStreamXML(FILE *fp);

};


class vipFilterColor :	public vipFilter
 {

 protected:

		/**
		 * @brief  Current parameters.
		 */
		vipFilterColorParameters* myParams;

 public:


		/**
		 * @brief  Default constructor, initialize parameters and superclasses.
		 * @param[in] initParams parameters for this module or NULL for defaults.
		 */
		vipFilterColor( vipFilterColorParameters* initParams = NULL );

		/**
		 * @brief Default destructor, free buffer.
		 */
		~vipFilterColor();


		float getFrameRate()  const { return 0; };

		/**
		 * @brief  Set parameters for this filter.
		 *
		 * @param[in] initParams Instance of vipFilterColorParameters or NULL,
		 *                       NULL argument make function to create a new
		 *                       instance with default parameters.
		 *
		 * @return VIPRET_OK
		 */
		VIPRESULT setParameters(vipFilterColorParameters* initParams);

		/**
		 * @brief  Get parameters for this filter.
		 *
		 * @return pointer to vipFilterColorParameters instance.
		 */
		vipFilterColorParameters& getParameters() { return *myParams; };


		/**
		 * @brief  Set parameters for this filter.
		 *
		 * @param[in] initParams Instance of vipFilterColorParameters or NULL,
		 *                       NULL argument make function to create a new
		 *                       instance with default parameters.
		 *
		 * @return VIPRET_OK
		 */
		VIPRESULT setFilterParameters (vipFilterParameters* initParams)
		 {
			if (initParams == NULL)
				return setParameters(NULL);
			else
				return setParameters(static_cast<vipFilterColorParameters*>(initParams));
		 };



		/**
		 * @brief  Get parameters for this filter.
		 *
		 * @return pointer to vipFilterColorParameters instance.
		 */
		vipFilterParameters* getFilterParameters ()
		 {
			if (myParams == NULL)
				return NULL;
			else
				return static_cast<vipFilterParameters*>(myParams);
		 };


		/**
		 * @brief  Reset buffers and parameters.
		 *
		 * @return VIPRET_OK
		 */
		VIPRESULT reset();



		VIPRESULT clamp(vipFrameRGB24& img, unsigned int bpp);
		VIPRESULT clamp(vipFrameYUV420& img, unsigned int bpp);//=sizeof(int)*3
		VIPRESULT clamp(vipFrameT<unsigned char>& img, unsigned int bpp);

		VIPRESULT invert(vipFrameRGB24& img, unsigned int bpp);//=sizeof(int)*3
		VIPRESULT invert(vipFrameYUV420& img, unsigned int bpp);//=sizeof(int)*3
		VIPRESULT invert(vipFrameT<unsigned char>& img, unsigned int bpp);//=sizeof(int)*3

		VIPRESULT extractBitPlane(vipFrameRGB24& img, unsigned int bits = 1);
		VIPRESULT extractBitPlane(vipFrameYUV420& img, unsigned int bits = 1);
		VIPRESULT extractBitPlane(vipFrameT<unsigned char>& img, unsigned int bits = 1);



		/**
		 * @brief Process the frame with current settings and store in buffer.
		 *
		 * @param[in] img VIPLibb Cache Frame to be processed.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
		 *
		 * @note  Input operator (<<) call directly this function.
		 * @see   operator << (vipFrameYUV420&)
		 */
		VIPRESULT importFrom(vipFrameYUV420& img);

		/**
		 * @brief Process the frame with current settings and store in buffer.
		 *
		 * @param[in] img VIPLibb Cache24 Frame to be processed.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
		 *
		 * @note  Input operator (<<) call directly this function.
		 * @see   operator << (vipFrameRGB24&)
		 */
		VIPRESULT importFrom(vipFrameRGB24& img);

		/**
		 * @brief Process the frame with current settings and store in buffer.
		 *
		 * @param[in] img VIPLibb Grayscale Frame to be processed.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
		 *
		 * @note  Input operator (<<) call directly this function.
		 * @see   operator << (vipFrameT&)
		 */
		VIPRESULT importFrom(vipFrameT<unsigned char>& img);



};



#endif //__VIPLIB_VIPFILTERCOLOR_H__


