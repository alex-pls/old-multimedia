/**
 *  @class   vipWindowGTK
 *
 *  @brief   Class for displaying VIPLibb frames on a Linux Desktop Env.
 *
 *           May be used to display video, setFrameRate is a simple sleep
 *           call after image drawing.
 *
 *  @bug
 *  @warning Require GTK Library (included in most distribution)
 *  @todo    extend a GtkWidget instead of using one (gtk_drawing_area)
 *  @note
 *
 *  @see     vipOutput
 *  @example ../../tests/test_vipWindowGTK.cpp
 *  @example ../../tests/app_vipLinuxMOVPlayerGTK.cpp
 *  @example ../../tests/app_vipLinuxMPEGPlayerGTK.cpp
 *
 *  @version 0.9.8
 *  @date    22/09/2005
 *  @author  Alessandro Polo
 *
 *
 ****************************************************************************
 * VIPLib Framework
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib
 *
 *  maintained by MultiMedia Laboratory - DIT - University of Trento
 *
 ****************************************************************************/


/*
Patch for some systems
	ln -s /usr/include/gtk-x.x/gtk gtk
	ln -s /usr/include/gtk-x.x/gdk gdk
*/

/* EXAMPLE GTK
	#include <gtk/gtk.h>

		int main( int   argc, char *argv[] ) {
			GtkWidget *window;
			gtk_init (&argc, &argv);
			window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
			gtk_widget_show  (window);
			gtk_main ();
			return 0;
		}

	You can compile the above program with gcc using:
		gcc base.c -o base `pkg-config --cflags --libs gtk+-2.0`
*/



#ifndef __VIPLIB_VIPWINDOWGTK_H__
 #define __VIPLIB_VIPWINDOWGTK_H__

 #include "../vipDefs.h"
 #include "../vipOutput.h"

 #include "../vipFrameYUV420.h"
 #include "../vipFrameRGB24.h"
 #include "../vipFrameT.h"

 #include <gtk/gtk.h>


/**
 * @brief  Deafult window's width.
 */
#define VIPWGTK_DEF_WIDTH	320
/**
 * @brief  Deafult window's height.
 */
#define VIPWGTK_DEF_HEIGHT	240


class vipWindowGTK :  public vipOutput
 {

	protected:

		/**
		 * @brief  Canvas' handle (created by this class).
		 */
		GtkWidget* image;

		/**
		 * @brief  Window's handle (passed or created)
		 */
		GtkWidget* window;

		/**
		 * @brief  Current Dithering setting:
		 *         0 => GDK_RGB_DITHER_NONE (default)
		 *         1 => GDK_RGB_DITHER_NORMAL
		 *         2 => GDK_RGB_DITHER_MAX
		 *
		 */
		GdkRgbDither currDith;

		/**
		 * @brief  Canvas' width.
		 */
		unsigned int width;
		/**
		 * @brief  Canvas' height.
		 */
		unsigned int height;

		/**
		 * @brief  Milliseconds to wait after frame (re)drawing.
		 */
		long v_sleeptime;

		/**
		 * @brief  Initialize canvas.
		 * @return VIPRET_OK
		 */
		int init();


	public:


		/**
		 * @brief  Default constructor initializes variables and canvas.
		 *
		 * @param[in]  mainWindow Main window's handle, if not NULL, it will be created.
		 */
		vipWindowGTK(GtkWidget* mainWindow = NULL);

		/**
		 * @brief  Default constructor initializes variables.
		 *
		 * @param width Canvas' width.
		 * @param height Canvas' height.
		 *
		 * @param[in]  mainWindow Main window's handle, if not NULL, it will be created.
		 */
		vipWindowGTK(unsigned int width, unsigned int height, GtkWidget *mainWindow = NULL);

		/**
		 * @brief  Default destructor, wait for pending events and flush.
		 */
		~vipWindowGTK();

		/**
		 * @brief  Currently not used.
		 * @return VIPRET_NOT_IMPLEMENTED
		 */
		VIPRESULT run() { return VIPRET_NOT_IMPLEMENTED; };

		/**
		 * @brief  Show canvas and if selected also main window.
		 *
		 * @param[in] doShowWindow if true (default) show also main window,
		 *                         else show only canvas.
		 *
		 * @return VIPRET_OK
		 */
		VIPRESULT show(bool doShowWindow = true);

		/**
		 * @brief  Hide canvas and if selected also main window.
		 *
		 * @param[in] doHideWindow if true (default) hide also main window,
		 *                         else hide only canvas.
		 *
		 * @return VIPRET_OK
		 */
		VIPRESULT hide(bool doHideWindow = true);

		/**
		 * @brief  Dump canvas' address.
		 *
		 * @return Canvas' handle (where data is displayed)
		 */
		GtkWidget* dump_canvas() { return image; };

		/**
		 * @brief  Dump (main) window's address.
		 *
		 * @return (main) window's handle (was passed at constructor or created by this class)
		 */
		GtkWidget* dump_window() { return window; };

		/**
		 * @brief  Set display dithering mode.
		 *
		 * @param[in] value can be [0,1,2] -> (NONE, NORMAL, MAX)
		 *
		 * @see    currDith
		 */
		void setDithering(int value = 0);

		/**
		 * @brief  Get current display dithering value.
		 *
		 * @return current dithering mode [0,1,2] -> (NONE, NORMAL, MAX)
		 *
		 * @see    currDith
		 */
		int getDithering() { return currDith; };

		/**
		 * @brief  Set display frame rate (elaboration time is not subtracted).
		 *
		 * @param[in] frames per second (default is 0, no sleep)
		 *
		 * @return VIPRET_PARAM_ERR if fps is lower than 0, VIPRET_OK else.
		 */
		VIPRESULT setFrameRate(float fps = 0);

		/**
		 * @brief  Get current canvas' width.
		 *
		 * @return width in pixel.
		 */
		unsigned int getWidth() const { return width; };

		/**
		 * @brief  Get current canvas' height.
		 *
		 * @return height in pixel.
		 */
		unsigned int getHeight() const { return height; };

		/**
		 * @brief  Set current canvas' height.
		 *
		 * @return height in pixel.
		 */
		VIPRESULT setHeight(unsigned int value);

		/**
		 * @brief  Set current canvas' width.
		 *
		 * @return width in pixel.
		 */
		VIPRESULT setWidth(unsigned int value);


		/**
		 * @brief  Display frame, conversion to vipFrameRGB24 and data-copy routine.
		 *
		 * @param[in] img VIPLibb Cache Frame to be displayed.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
		 *
		 * @note   Input operator (<<) call directly this function.
		 * @see    operator << (vipFrameYUV420&)
		 */
		VIPRESULT importFrom(vipFrameYUV420& img);

		/**
		 * @brief  Display frame, data-copy routine. (optimized)
		 *
		 * @param[in] img VIPLibb Cache24 Frame to be displayed.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
		 *
		 * @note   Input operator (<<) call directly this function.
		 * @see    operator << (vipFrameRGB24&)
		 */
		VIPRESULT importFrom(vipFrameRGB24& img);

		/**
		 * @brief  Display frame, conversion to vipFrameRGB24
		 *         and single channel data-copy routine.
		 *
		 * @param[in] img VIPLibb Grey Frame to be displayed.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
		 *
		 * @note   Input operator (<<) call directly this function.
		 * @see    operator << (vipFrameT&)
		 */
		VIPRESULT importFrom(vipFrameT<unsigned char>& img);

};

#endif //__VIPLIB_VIPWINDOWGTK_H__
