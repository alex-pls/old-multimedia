/** @file vipWindowGTK.cpp
 *
 * File containing methods for the 'vipWindowGTK' class.
 * The header for this class can be found in vipWindowGTK.h, check that file
 * for class description.
 *
 *
 *
 ****************************************************************************
 * VIPLib Framework
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib
 *
 *  maintained by MultiMedia Laboratory - DIT - University of Trento
 *
 ****************************************************************************/


#include "vipWindowGTK.h"
#include "../vipUtility.h"


////////////////////////////////////////////// CALL BACK FUNCT.
// may be implemented by user
void destroy (GtkWidget *widget, gpointer data) {
	//printf("destroy\n");
 }
void expose (GtkWidget *widget, gpointer data) {
	//printf("expose\n");
 }
//
//////////////////////////////////////////////////////////////


/**
 * @brief  Default constructor initializes variables and canvas.
 *
 * @param[in]  mainWindow Main window's handle, if not NULL, it will be created.
 */
vipWindowGTK::vipWindowGTK(GtkWidget *mainWindow) : vipOutput()
 {
	INFO("vipWindowGTK::vipWindowGTK() : vipOutput() [CONTRUCTOR]")

	image = NULL;
	window = mainWindow;
	height = VIPWGTK_DEF_HEIGHT;
	width = VIPWGTK_DEF_WIDTH;
	v_sleeptime = 0;
	setDithering();
	init();
 }

/**
 * @brief  Default constructor initializes variables.
 *
 * @param width Canvas' width.
 * @param height Canvas' height.
 *
 * @param[in]  mainWindow Main window's handle, if not NULL, it will be created.
 */
vipWindowGTK::vipWindowGTK(unsigned int w, unsigned int h, GtkWidget *mainWindow) : vipOutput()
 {
	INFO("vipWindowGTK::vipWindowGTK() : vipOutput() [CONTRUCTOR]")

	image = NULL;
	window = mainWindow;
	height = h;
	width = w;
	v_sleeptime = 0;
	setDithering();
	init();
 }

/**
 * @brief  Default destructor, wait for pending events and flush.
 */
vipWindowGTK::~vipWindowGTK()
 {
	while ( gtk_events_pending() )
		gtk_main_iteration();

    gdk_flush();
//	gtk_main_quit();
 }

/**
 * @brief  Initialize canvas, create window if necessary.
 * @return VIPRET_OK
 */
int vipWindowGTK::init()
 {
	gtk_init(NULL,NULL);
//	gdk_rgb_init(); not needed?
	gtk_widget_set_default_colormap(gdk_rgb_get_cmap());
	gtk_widget_set_default_visual(gdk_rgb_get_visual());

	if (window == NULL)
	 {
		window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
		gtk_window_set_title(GTK_WINDOW (window), "vipWindowGTK 1.0");
		gtk_signal_connect(GTK_OBJECT (window), "destroy_event", GTK_SIGNAL_FUNC (destroy), NULL);
	 }

	image = gtk_drawing_area_new();
	gtk_signal_connect (GTK_OBJECT (image), "expose_event",  GTK_SIGNAL_FUNC (expose), NULL);

	gtk_container_add(GTK_CONTAINER(window),image);
	gtk_drawing_area_size(GTK_DRAWING_AREA(image),width,height);
	gtk_widget_set_usize(GTK_WIDGET(image),width,height);

	//pthread_create(&vue, NULL, (void * (*)(void *))gtk_main, NULL);
	gdk_flush();
	while (gtk_events_pending())
		gtk_main_iteration();
	gdk_flush();

	return VIPRET_OK;
 }


/**
 * @brief  Set current canvas' height.
 *
 * @return height in pixel.
 */
VIPRESULT vipWindowGTK::setHeight(unsigned int value)
 {
	if (image == NULL)

		return VIPRET_ILLEGAL_USE;

	height = value;
	gtk_drawing_area_size(GTK_DRAWING_AREA(image),width,height);
	gtk_widget_set_usize(GTK_WIDGET(image),width,height);

	return VIPRET_OK;
 }

/**
 * @brief  Set current canvas' width.
 *
 * @return width in pixel.
 */
VIPRESULT vipWindowGTK::setWidth(unsigned int value)
 {
	if (image == NULL)
		return VIPRET_ILLEGAL_USE;

	width = value;
	gtk_drawing_area_size(GTK_DRAWING_AREA(image),width,height);
	gtk_widget_set_usize(GTK_WIDGET(image),width,height);

	return VIPRET_OK;
 }




/**
 * @brief  Set display frame rate (elaboration time is not subtracted).
 *
 * @param[in] frames per second (default is 0, no sleep)
 *
 * @return VIPRET_PARAM_ERR if fps is lower than 0, VIPRET_OK else.
 */
VIPRESULT vipWindowGTK::setFrameRate(float fps)
 {
	if (fps < 0.)
		return VIPRET_PARAM_ERR;

	if ( fps == 0 )
		v_sleeptime = 0;
	else
		v_sleeptime = (long)( (float)1000 / fps ); // milliseconds

	return VIPRET_OK;
 }

/**
 * @brief  Show canvas and if selected also main window.
 *
 * @param[in] doShowWindow if true (default) show also main window,
 *                         else show only canvas.
 *
 * @return VIPRET_OK
 */
VIPRESULT vipWindowGTK::show(bool doShowWindow)
 {
	gtk_widget_show(image);

	if (doShowWindow)

		gtk_widget_show(window);

	return VIPRET_OK;
 }

/**
 * @brief  Hide canvas and if selected also main window.
 *
 * @param[in] doHideWindow if true (default) hide also main window,
 *                         else hide only canvas.
 *
 * @return VIPRET_OK
 */
VIPRESULT vipWindowGTK::hide(bool doHideWindow)
 {
	gtk_widget_hide(image);

	if (doHideWindow)
		gtk_widget_hide(window);

	return VIPRET_OK;
 }

/**
 * @brief  Set display dithering.
 *
 * @param[in] value can be [0,1,2] -> (NONE, NORMAL, MAX)
 *
 * @see    currDith
 */
void vipWindowGTK::setDithering(int value)
 {
	switch (value)
	 {
		case 1:
			currDith = GDK_RGB_DITHER_NORMAL;
			break;
		case 2:
			currDith = GDK_RGB_DITHER_MAX;
			break;
		default:
			currDith = GDK_RGB_DITHER_NONE;
	 }
 }


/**
 * @brief  Display frame, conversion to vipFrameRGB24 and data-copy routine.
 *
 * @param[in] img VIPLibb Cache Frame to be displayed.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
 *
 * @note   Input operator (<<) call directly this function.
 * @see    operator << (vipFrameYUV420&)
 */
VIPRESULT vipWindowGTK::importFrom(vipFrameYUV420& img)
 {
	INFO("int vipWindowGTK::importFrom(vipFrameYUV420& img) [reading data]")

	if (image == NULL)
		return VIPRET_INTERNAL_ERR;

	vipFrameRGB24 tmp(img.width, img.height);

	img >> tmp;

	importFrom(tmp);

	return VIPRET_OK_DEPRECATED;
 }


/**
 * @brief  Display frame, data-copy routine. (optimized)
 *
 * @param[in] img VIPLibb Cache24 Frame to be displayed.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
 *
 * @note   Input operator (<<) call directly this function.
 * @see    operator << (vipFrameRGB24&)
 */
VIPRESULT vipWindowGTK::importFrom(vipFrameRGB24& img)
 {
	INFO("int vipWindowGTK::importFrom(vipFrameRGB24& img) [reading data]")

	if (image == NULL)
		return VIPRET_INTERNAL_ERR;

    gdk_draw_rgb_image(	image->window,
						image->style->fg_gc[image->state],
						0,0,
						img.width,img.height,
						currDith,
						(guchar*)img.data[0],
						img.width*3
					  );

	return VIPRET_OK;
 }


/**
 * @brief  Display frame, conversion to vipFrameRGB24
 *         and single channel data-copy routine.
 *
 * @param[in] img VIPLibb Grey Frame to be displayed.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
 *
 * @note   Input operator (<<) call directly this function.
 * @see    operator << (vipFrameT&)
 */
VIPRESULT vipWindowGTK::importFrom(vipFrameT<unsigned char>& img)
 {
	INFO("int vipWindowGTK::importFrom(vipFrameT& img) [reading data]")

	if (image == NULL)
		return VIPRET_INTERNAL_ERR;

	return VIPRET_NOT_IMPLEMENTED;
 }





