/** @file vipWindow32.cpp
 *
 * File containing methods for the 'vipWindow32' class.
 * The header for this class can be found in vipWindow32.h, check that file
 * for class description.
 *
 *
 *
 ****************************************************************************
 * VIPLib Framework
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib
 *
 *  maintained by MultiMedia Laboratory - DIT - University of Trento
 *
 ****************************************************************************/



#include "vipWindow32.h"


/**
 * @brief  Default constructor initializes variables; if present, set parent
 *         instance and create window.
 *
 * @param[in] hInstance Main window (parent) instance handle, required before
 *                      calling createWindow()
 */
vipWindow32::vipWindow32(HINSTANCE hInstance) : vipOutput()
 {
	INFO("vipWindow32::vipWindow32(HINSTANCE hInstance) : vipOutput() [CONTRUCTOR]")

	parentHistance = hInstance;
	myHandle = 0;
	width = 0;
	height = 0;

	if (parentHistance)
		createWindow(VIPW32_DEF_WIDTH, VIPW32_DEF_HEIGHT);
 }

/**
 * @brief  Default destructor, release canvas.
 */
vipWindow32::~vipWindow32()
 {
	INFO("vipWindow32::~vipWindow32() : [DESTRUCTOR]")

	ReleaseDC(myHandle, hDisplay);
 }

/**
 * @brief  Initialize canvas, parent instance must be valid.
 *
 * @param[in] width window's width in pixel
 * @param[in] height window's height in pixel
 *
 * @return VIPRET_ILLEGAL_USE if app handle is not valid,
 *         VIPRET_INTERNAL_ERR if window cannot be created,
 *         VIPRET_OK else.
 *
 * @note   use setParentHistance() to update application's handle.
 */
VIPRESULT vipWindow32::createWindow(unsigned int w, unsigned int h)
 {
	if (parentHistance == 0)
		return VIPRET_ILLEGAL_USE;

	width = w;
	height = h;

    // Create the main window.  The WS_CLIPCHILDREN style is required.
	myHandle = CreateWindow(VIPW32_DEF_CLSNAME, VIPW32_DEF_TITLE,
							WS_OVERLAPPEDWINDOW | WS_CAPTION | WS_CLIPCHILDREN,
							CW_USEDEFAULT, CW_USEDEFAULT,
							width, height,
							0, 0, parentHistance, 0);


	if (myHandle == 0)
		return VIPRET_INTERNAL_ERR;

	GetClientRect(myHandle, &myRect);

	hDisplay = GetDC(myHandle);

	InvalidateRect(myHandle, NULL, FALSE);

	return VIPRET_OK;
 }

/**
 * @brief  Show the window, state is customizable
 *
 * @param[in] default is SW_SHOW, argument is passed to ShowWindow() API.
 *
 * @return VIPRET_ILLEGAL_USE if window handle is not valid, VIPRET_OK else.
 */
VIPRESULT vipWindow32::show(int nCmdShow)
 {
	if (myHandle == 0)
		return VIPRET_ILLEGAL_USE;

	ShowWindow(myHandle, nCmdShow);
	UpdateWindow(myHandle);

	return VIPRET_OK;
 }

/**
 * @brief  Hide the window.
 *
 * @return VIPRET_ILLEGAL_USE if window handle is not valid, VIPRET_OK else.
 */
VIPRESULT vipWindow32::hide()
 {
	if (myHandle == 0)
		return VIPRET_ILLEGAL_USE;

	ShowWindow(myHandle, SW_HIDE);
	UpdateWindow(myHandle);

	return VIPRET_OK;
 }


/**
 * @brief  Display some text.
 *
 * @return VIPRET_ILLEGAL_USE if app handle is not valid, VIPRET_OK else.
 */
VIPRESULT vipWindow32::welcomeText()
{
	if (myHandle == 0)
		return VIPRET_ILLEGAL_USE;

	PAINTSTRUCT ps;
	HDC hdc = BeginPaint(myHandle, &ps);
	EndPaint(myHandle, &ps);

	char buf[2048];
	int x=50;
	int y=60;
	SetTextColor(hdc,RGB(rand()%255,rand()%255,rand()%255));
	int len=sprintf(buf,"VIPLibb is Ready!");
	TextOut(hdc,x,y,buf,len);

	return VIPRET_OK;
 }



/**
 * @brief  Set current canvas' height.
 *
 * @return height in pixel.
 */
VIPRESULT vipWindow32::setHeight(unsigned int value)
 {
	height = value;
	SetWindowPos(myHandle, NULL, 0, 0, width, height, SWP_NOACTIVATE | SWP_NOMOVE);

	return VIPRET_OK;
 }

/**
 * @brief  Set current canvas' width.
 *
 * @return width in pixel.
 */
VIPRESULT vipWindow32::setWidth(unsigned int value)
 {
	width = value;
	SetWindowPos(myHandle, NULL, 0, 0, width, height, SWP_NOACTIVATE | SWP_NOMOVE);

	return VIPRET_OK;
 }


/**
 * @brief Display frame, single pixel routine.
 *
 * @param[in] img VIPLibb Cache Frame to be displayed.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
 *
 * @note  Input operator (<<) call directly this function.
 * @see   operator << (vipFrameYUV420&)
 */
VIPRESULT vipWindow32::importFrom(vipFrameYUV420& img)
 {
	INFO("int vipWindow32::importFrom(vipFrameYUV420& img) [reading data]")

	return VIPRET_NOT_IMPLEMENTED;
 }


/**
 * @brief Display frame, single pixel routine.
 *
 * @param[in] img VIPLibb Cache24 Frame to be displayed.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
 *
 * @note  Input operator (<<) call directly this function.
 * @see   operator << (vipFrameRGB24&)
 */
VIPRESULT vipWindow32::importFrom(vipFrameRGB24& img)
 {
	INFO("int vipWindow32::importFrom(vipFrameRGB24& img) [reading data]")

	if (&img == NULL)
		return VIPRET_PARAM_ERR;

	for (int y=0; y<(int)img.height; y++ )

		for (int x=0; x<(int)img.width; x++ )

			SetPixel(hDisplay, x, y, RGB(img.data[y*img.width+x][0],img.data[y*img.width+x][1],img.data[y*img.width+x][2]));

	return VIPRET_OK;
 }


/**
 * @brief Display frame, conversion to vipFrameRGB24 and single pixel routine.
 *
 * @param[in] img VIPLibb Grey Frame to be displayed.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
 *
 * @note  Input operator (<<) call directly this function.
 * @see   operator << (vipFrameT&)
 */
VIPRESULT vipWindow32::importFrom(vipFrameT<unsigned char>& img)
 {
	INFO("int vipWindow32::importFrom(vipFrameT<unsigned char>& img) [reading data]")

	return VIPRET_NOT_IMPLEMENTED;
 }



