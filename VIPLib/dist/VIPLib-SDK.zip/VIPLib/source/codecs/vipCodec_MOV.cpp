/** @file vipCodec_MOV.cpp
 *
 * File containing methods for the 'vipCodec_MOV' class.
 * The header for this class can be found in vipCodec_MOV.h, check
 * that file for class description.
 *
 *
 ****************************************************************************
 * VIPLib Framework 1.1
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib/
 *
 ****************************************************************************/





#include "vipCodec_MOV.h"
#include "../vipUtility.h"

//extern "C" {
//	#include "../../support/quicktime4linux/quicktime.h"
//  }



/**
 * @brief  Default constructor, initialize parameters and superclasses.
 * @param[in] initParams parameters for this module or NULL for defaults.
 */
vipCodec_MOV::vipCodec_MOV(char *filename, int stream) : vipCodec()
 {
	DEBUGMSG("vipCodec_MOV::vipCodec_MOV(char *filename, FileFormat format) [CONTRUCTOR] ", *filename)

	buff = NULL;
	file = NULL;
	setParameters(NULL);
	reset();

 	load( filename, stream );

 }

/**
 * @brief  Initialize parameters and load given mpeg movie.
 *
 * @param[in] filename a valid MPEG1-2 movie
 * @param[in] stream video stream to load (default is first: 0)
 *
 */
vipCodec_MOV::vipCodec_MOV( vipCodec_MOVParameters* initParams ) : vipCodec()
 {
	DEBUGMSG("vipCodec_MOV::vipCodec_MOV(vipCodec_MOVParameters* initParams) [CONTRUCTOR] ", *filename)

	buff = NULL;
	file = NULL;
	setParameters(initParams);

	reset();
 }

/**
 * @brief  Reset filename and movie related settings.
 *
 * @return VIPRET_OK
 */
VIPRESULT vipCodec_MOV::reset()
 {
	INFO("VIPRESULT vipCodec_MOV::reset() [SET DEFAULT PARAMETERS]")

	setName("MOV Coder");
	setDescription("Read or write video stream.");
	setVersion(1.0);

	if (file != NULL)
	 {
		quicktime_close(file);
		file = NULL;
	 }

	if (buff != NULL)
	 {
		// free the memory for each of the rows
		for (unsigned int i = 0; i < height; i++)
			delete [] buff[i];

		// free the rest of the memory
		delete [] buff;
	 }

	width  = 0;
	height = 0;
	lenghtFrames = 0;
	outFrameRate = 0;

	if (myParams != NULL)
		myParams->reset();

	streamEOF = true;

	return VIPRET_OK;
 }


bool vipCodec_MOV::EoF()	// buggy
 {
	if (file == NULL)

		return true;

	if ( myParams->frameIndex >= lenghtFrames)
		return true;

	return false;
 }


/**
 * @brief  Set parameters for (de)coding.
 *
 * @param[in] initParams Instance of vipCodec_MOVParameters or NULL,
 *                       NULL argument make function to create a new
 *                       instance with default parameters.
 *
 * @return VIPRET_OK
 */
VIPRESULT vipCodec_MOV::setParameters (vipCodec_MOVParameters* initParams)
 {

	if ( initParams == NULL )
		myParams = new vipCodec_MOVParameters();
	else
		myParams = initParams;

	return VIPRET_OK;
 }

/**
 * @brief Default destructor, close file and free buffer.
 */
vipCodec_MOV::~vipCodec_MOV()
 {
	if (file != NULL)
		quicktime_close(file);

	if (buff != NULL)
	 {
		// free the memory for each of the rows
		for (unsigned int i = 0; i < height; i++)
			delete [] buff[i];

		// free the rest of the memory
		delete [] buff;
	 }
 }

/**
 * @brief Load current frame data into image (parameter), increments
 *        frame index.
 *
 * @param[out] img VIPLibb Cache Frame to store data.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note  Ouput operator (>>) call directly this function.
 * @see   operator >> (vipFrameYUV420&)
 */
VIPRESULT vipCodec_MOV::extractTo(vipFrameYUV420& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_MOV::extractTo(vipFrameYUV420& img) [pushing data]", doBuffering)

	if (file == NULL)
		return VIPRET_ILLEGAL_USE;

	return VIPRET_NOT_IMPLEMENTED;

 }

/**
 * @brief Load current frame data into image (parameter), increments
 *        frame index.
 *
 * @param[out] img VIPLibb Cache24 Frame to store data.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note  Ouput operator (>>) call directly this function.
 * @see   operator >> (vipFrameRGB24&)
 */
VIPRESULT vipCodec_MOV::extractTo(vipFrameRGB24& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_MOV::extractTo(vipFrameRGB24& img) [pushing data]", doBuffering)

	if (file == NULL)
		return VIPRET_ILLEGAL_USE;

	if (width != img.width || height != img.height)
		img.reAllocCanvas(width, height);

	// read the frame to a temporary buffer
	quicktime_decode_video(file, (unsigned char**)img.data, 0);

//	vipUtility::conv_rgb24_rgb96(buff, (unsigned char*)img.data[0], width, height);

//BUG why not memcpy( (unsigned char*)img.data[0], buff, width * height * 3);

	myParams->frameIndex++;

	if(myParams->frameIndex > lenghtFrames)
		streamEOF = true;

	return VIPRET_OK;
 }

/**
 * @brief Load current frame data into image (parameter), increments
 *        frame index.
 *
 * @param[out] img Greyscale VIPLibb Frame to store data.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note  Ouput operator (>>) call directly this function.
 * @see   operator >> (vipFrameT&)
 */
VIPRESULT vipCodec_MOV::extractTo(vipFrameT<unsigned char>& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_MOV::extractTo(vipFrameT& img) [pushing data]", doBuffering)

	if (file == NULL)
		return VIPRET_ILLEGAL_USE;

	return VIPRET_NOT_IMPLEMENTED;
 }


/**
 * @brief Encode given image to stream, increments frame index.
 *
 * @param[in] img VIPLibb Cache Frame to be encoded.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note  Input operator (<<) call directly this function.
 * @see   operator << (vipFrameYUV420&)
 */
VIPRESULT vipCodec_MOV::importFrom(vipFrameYUV420& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_MOV::importFrom(vipFrameYUV420& img) [reading data]", doBuffering)

	if (file == NULL)
		return VIPRET_ILLEGAL_USE;

	return VIPRET_NOT_IMPLEMENTED;

 }

/**
 * @brief Encode given image to stream, increments frame index.
 *
 * @param[in] img VIPLibb Cache Frame to be encoded.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note  Input operator (<<) call directly this function.
 * @see   operator << (vipFrameRGB24&)
 */
VIPRESULT vipCodec_MOV::importFrom(vipFrameRGB24& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_MOV::importFrom(vipFrameRGB24& img) [reading data]", doBuffering)

	if (file == NULL)
		return VIPRET_ILLEGAL_USE;

	PixelRGB24* rgb_ptr = img.data;

	unsigned char *buff_ptr = buff[0];

	for(unsigned int y_cnt=0 ; y_cnt < img.height ; y_cnt++)
	 {
		buff_ptr = buff[y_cnt];

		for(unsigned int x_cnt=0 ; x_cnt < img.width ; x_cnt++, rgb_ptr++)
		 {
			*(buff_ptr++) = (unsigned char)((*rgb_ptr)[0]);
			*(buff_ptr++) = (unsigned char)((*rgb_ptr)[1]);
			*(buff_ptr++) = (unsigned char)((*rgb_ptr)[2]);
		 }
	 }

	myParams->frameIndex++;
	lenghtFrames++;

	//Encode the frame and write to file
	if ( quicktime_encode_video(file, buff, 0) )
		return VIPRET_OK;
	else
		return VIPRET_INTERNAL_ERR;

 }

/**
 * @brief Encode given image to stream, increments frame index.
 *
 * @param[in] img VIPLibb Cache Frame to be encoded.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note  Input operator (<<) call directly this function.
 * @see   operator << (vipFrameT&)
 */
VIPRESULT vipCodec_MOV::importFrom(vipFrameT<unsigned char>& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_MOV::importFrom(vipFrameYUV420& img) [reading data]", doBuffering)

	return VIPRET_NOT_IMPLEMENTED;

 }



/**
 * @brief  Load movie from current filename, use SetFileName() or
 *         load(char*, int).
 *
 * @return VIPRET_ILLEGAL_USE if file is not correctly loaded, VIPRET_OK else.
 */
VIPRESULT vipCodec_MOV::load()
 {
	INFO("VIPRESULT vipCodec_MOV::load() [loading data to buffer]")

	// check the files signature is valid
	if (!quicktime_check_sig(myParams->fileName))
		return VIPRET_ILLEGAL_USE;
//		throw "incompatible quicktime file";

	// open the QT file
	file = quicktime_open(myParams->fileName,1,0); //read access only!
	if (file == NULL)
		return VIPRET_ILLEGAL_USE;
//		throw "error opening quicktime file";



	// check that it is a video QT file, with one track
	if (quicktime_video_tracks(file) != 1)
		throw "QT file does not only have one video track";
//        if (quicktime_audio_tracks(file) != 0)
//                throw "QT file has audio tracks";

//BUG CHECK STREAM RANGE


	width  = quicktime_video_width(file, myParams->stream);
	height = quicktime_video_height(file, myParams->stream);

	lenghtFrames = quicktime_video_length(file, myParams->stream);
	myParams->frameIndex = 0;
	streamEOF = false;

        //Check Depth: Only RGB allowed, RGBA not supported
        //Could be, but requires extra processing in this file
	if(quicktime_video_depth(file, 0) != 24)
		return VIPRET_ILLEGAL_USE;
//		throw "Depth not 24 ie not RGBRGBRGB encoded QT";

//	comp_type = quicktime_video_compressor(file, 0);
	if (!quicktime_supported_video(file, 0))
		return VIPRET_ILLEGAL_USE;

//		throw "QT data cannot be decoded";

	// allocate memory for rgb rows
	buff = new (unsigned char*)[height];
	for (unsigned int i = 0; i < height ; i++)
		buff[i] = new (unsigned char)[width*3];

	return VIPRET_OK;
}

/**
 * @brief  Load a BMP format image into current buffer (vipFrameRGB).
 *
 * @param[in] filename a valid MPEG1-2 movie filename
 * @param[in] stream video stream to load (default is first: 0)
 *
 * @return VIPRET_ILLEGAL_USE if file is not correctly loaded, VIPRET_OK else.
 */
VIPRESULT vipCodec_MOV::load(char *filename, int stream)
 {
	DEBUGMSG("VIPRESULT vipCodec_MOV::load(char *filename, FileFormat format) [loading data to buffer]", filename)

 	myParams->setFileName(filename);
 	myParams->setStream(stream);

	return load();
 }


/**
 * @brief  Create a new movie, writing to passed filename, call save()
 *         after importing all frames.
 *
 * @param[in] filename a valid MPEG1-2 movie filename
 * @param[in] w movie's width
 * @param[in] h movie's height
 * @param[in] frame_rate movie's fps
 * @param[in] quality jpeg compression quality value [10, 100], default 80;
 *
 * @return VIPRET_INTERNAL_ERR if cannot open file for writing or any other
 *         error occurs, VIPRET_OK else.

 */
VIPRESULT vipCodec_MOV::newVideo(char* filename, unsigned int w, unsigned int h, float frame_rate, int quality)
 {
	if (file != NULL)
		reset();

	//open the a file for the quicktime movie
	file = quicktime_open(filename,0,1);

	if (file == NULL)
		return VIPRET_INTERNAL_ERR; // throw "error opening file to write quicktime to";

	width = w;
	height = h;
	outFrameRate = frame_rate;
	streamEOF = true;

	//Set video parameters - Using Interlaced Even Motion JPEG A compression
	quicktime_set_video(file, 1, width, height, outFrameRate, "mjpa");

	//Set the JPEG quality factor 1=low 75=normal 90=high 100=best
	quicktime_set_jpeg(file, quality, 0);

	//Check compression scheme is supported
	if( !quicktime_supported_video(file, 0) )
		return VIPRET_INTERNAL_ERR; // throw "QT Compression scheme not supported" ;

	//Check colour model is supported - using RGB888
	if( !quicktime_writes_cmodel(file, 9, 0) )
		return VIPRET_INTERNAL_ERR; // throw "QT Color Model not supported" ;

	//Set colourmodel to RGB888 format
	quicktime_set_cmodel(file, 9);

	// allocate memory for rgb rows
	buff = new (unsigned char*)[height];
	for (unsigned int i = 0; i < height ; i++)
		buff[i] = new (unsigned char)[width*3];

	return VIPRET_OK;
 }


/**
 * @brief  Save new movie to file, must be called at the end of writing,
 *         use newVideo(..) to create an empty video.
 *
 * @return VIPRET_ILLEGAL_USE if file is not correctly loaded, VIPRET_OK else.
 *
 * @see    newVideo(char*, unsigned int, unsigned int, float, int)
 */
VIPRESULT vipCodec_MOV::save()
 {
	INFO("VIPRESULT vipCodec_MOV::save() [saving buffered data]")

	if ( file == NULL)
		return VIPRET_ILLEGAL_USE;

	quicktime_close(file);

	file = NULL;

	reset();

	return VIPRET_OK;
 }




/**
 * @brief  Move frame index to start (first frame)
 *
 * @return VIPRET_OK if everything is fine, VIPRET_ILLEGAL_USE is stream
 *		   hasn't been loaded.
 */
VIPRESULT vipCodec_MOV::goToStart()
 {
	if ( file == NULL)
		return VIPRET_ILLEGAL_USE;

	return quicktime_seek_start(file);
 }

/**
 * @brief  Move frame index to end (last frame)
 *
 * @return VIPRET_OK if everything is fine, VIPRET_ILLEGAL_USE is stream
 *		   hasn't been loaded.
 */
VIPRESULT vipCodec_MOV::goToEnd()
 {
	if ( file == NULL)
		return VIPRET_ILLEGAL_USE;

	return quicktime_seek_end(file);
 }



/**
 * @brief  Read current frame index (position in the video timeline).
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return current frame index, -1 if stream has not been loaded.
 *
 */
long vipCodec_MOV::getAudioFrameIndex(int stream)
 {
	if ( hasAudio() && stream == -1  )
		return quicktime_audio_position(file, myParams->stream);

	if ( !hasAudio() ||  stream < 0 || stream >= getVideoStreamCount())
		return -1;

    return quicktime_audio_position(file, stream);
 }

/**
 * @brief  Read current sample index (position in the audio timeline).
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return current frame index, -1 if stream has not been loaded.
 */
long vipCodec_MOV::getVideoFrameIndex(int stream)
 {
	if ( hasVideo() && stream == -1  )
		return quicktime_video_position(file, myParams->stream);

	if ( !hasVideo() ||  stream < 0 || stream >= getVideoStreamCount())
		return -1;

    return quicktime_video_position(file, stream);
 }

/**
 * @brief  Seek to point in stream (position in the video timeline).
 *
 * @param[in] index position to set, number of frame offset [0, framesCount[
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if index or
 *		   stream are not valid, VIPRET_ILLEGAL_USE if stream hasn't been loaded.
 */
VIPRESULT vipCodec_MOV::setFrameIndex(long index, int stream)
 {
	if ( file == NULL)
		return VIPRET_ILLEGAL_USE;

    myParams->frameIndex = index;

	if ( stream == -1  )
		return quicktime_video_position(file, myParams->stream);

	if ( stream < 0 || stream >= getVideoStreamCount())
		return -VIPRET_PARAM_ERR;

    return quicktime_set_video_position(file, index, stream) ;
 }


/**
 * @brief read current image's depth.
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return movie's depth.
 */
int vipCodec_MOV::getVideoDepth(int stream)
 {
	if ( hasVideo() && stream == -1  )
		return quicktime_video_depth(file, myParams->stream);

	if ( !hasVideo() ||  stream < 0 || stream >= getVideoStreamCount())
		return VIPRET_ILLEGAL_USE;

	return quicktime_video_depth(file, stream);
 }

/**
 * @brief get movie's video compressor name.
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return pointer to a NULL terminated string..
 */
char* vipCodec_MOV::getVideoCompressor(int stream)
 {
	if ( hasVideo() && stream == -1  )
		return quicktime_video_compressor(file, myParams->stream);

	if ( !hasVideo() ||  stream < 0 || stream >= getVideoStreamCount())
		return NULL;

	return quicktime_video_compressor(file, stream);
 }

/**
 * @brief get movie's audio compressor name.
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return pointer to a NULL terminated string.
 */
char* vipCodec_MOV::getAudioCompressor(int stream)
 {
	if ( hasVideo() && stream == -1  )
		return quicktime_audio_compressor(file, myParams->stream);

	if ( !hasVideo() ||  stream < 0 || stream >= getAudioStreamCount())
		return NULL;

	return quicktime_audio_compressor(file, stream);
 }


/**
 * @brief get movie's video frame rate.
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return number of frame per second.
 */
float vipCodec_MOV::getVideoFrameRate(int stream)
 {
	if ( hasVideo() && stream == -1  )
		return quicktime_frame_rate(file, myParams->stream);

	if ( file == NULL || stream < 0 || stream >= getVideoStreamCount() )
		return -1;

	return quicktime_frame_rate(file, stream);
 }



/**
 * @brief check if loaded movie has a video stream.
 *
 * @return true if there is at least one video stream, false else.
 */
bool vipCodec_MOV::hasVideo()
 {
	if ( file == NULL)
		return false;

	if ( quicktime_has_video(file) )
		return true;
	else
		return false;
 }

/**
 * @brief get movie's audio streams count.
 *
 * @return number of audio streams.
 */
bool vipCodec_MOV::hasAudio()
 {
	if ( file == NULL)
		return false;

	if ( quicktime_has_audio(file) )
		return true;
	else
		return false;
 }

/**
 * @brief get movie's video streams count.
 *
 * @return number of video streams.
 */
int vipCodec_MOV::getVideoStreamCount()
 {
	if ( file == NULL)
		return -1;

	return quicktime_video_tracks(file);
 }

/**
 * @brief get movie's audio streams count.
 *
 * @return number of audio streams.
 */
int vipCodec_MOV::getAudioStreamCount()
 {
	if ( file == NULL)
		return -1;

	return quicktime_audio_tracks(file);
 }

/**
 * @brief get movie's audio sample count for selected stream.
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return number of sample.
 */
long vipCodec_MOV::getAudioStreamLength(int stream)
 {
	if ( hasAudio() && stream == -1  )
		return quicktime_audio_length(file, myParams->stream);

	if ( !hasAudio() || stream < 0 || stream >= getAudioStreamCount() )
		return -1;

	return quicktime_audio_length(file, stream);
 }

/**
 * @brief get movie's video frame count.
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return number of frames in the stream.
 */
long vipCodec_MOV::getVideoStreamLength(int stream)
 {
	if ( hasAudio() && stream == -1  )
		return quicktime_video_length(file, myParams->stream);

	if ( !hasVideo() || stream < 0 || stream >= getVideoStreamCount() )
		return -1;

	return quicktime_video_length(file, stream);
 }

/**
 * @brief get movie's audio sample rate for selected stream.
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return number of sample per second.
 */
long vipCodec_MOV::getAudioSampleRate(int stream)
 {
	if ( hasAudio() && stream == -1  )
		return quicktime_sample_rate(file, myParams->stream);

	if ( !hasAudio() || stream < 0 || stream >= getAudioStreamCount() )
		return -1;

	return quicktime_sample_rate(file, stream);
 }

/**
 * @brief get movie's audio channel count for selected stream.
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return number of audio channels.
 */
int vipCodec_MOV::getAudioChannels(int stream)
 {
	if ( hasAudio() && stream == -1  )
		return quicktime_track_channels(file, myParams->stream);

	if ( !hasAudio() || stream < 0 || stream >= getAudioStreamCount() )
		return -1;

	return quicktime_track_channels(file, stream);
 }









/**
 * @brief set movie's name.
 *
 * @param[in] string pointer to a NULL terminated string
 *
 * @return VIPRET_OK if everything is fine, VIPRET_ILLEGAL_USE if movie
 *		   hasn't been loaded.
 */
VIPRESULT vipCodec_MOV::setName(char *string)
 {
	if (file == NULL)
		return VIPRET_ILLEGAL_USE;

	quicktime_set_name(file, string);

	return VIPRET_OK;
 }

/**
 * @brief set movie's informations.
 *
 * @param[in] string pointer to a NULL terminated string
 *
 * @return VIPRET_OK if everything is fine, VIPRET_ILLEGAL_USE if movie
 *		   hasn't been loaded.
 */
VIPRESULT vipCodec_MOV::setInfo(char *string)
 {
	if (file == NULL)
		return VIPRET_ILLEGAL_USE;

	quicktime_set_info(file, string);

	return VIPRET_OK;
 }

/**
 * @brief set movie's copyright.
 *
 * @param[in] string pointer to a NULL terminated string
 *
 * @return VIPRET_OK if everything is fine, VIPRET_ILLEGAL_USE if movie
 *		   hasn't been loaded.
 */
VIPRESULT vipCodec_MOV::setCopyRight(char *string)
 {
	if (file == NULL)
		return VIPRET_ILLEGAL_USE;

	quicktime_set_copyright(file, string);

	return VIPRET_OK;
 }

/**
 * @brief get movie's name.
 *
 * @return pointer to a NULL terminated string.
 */
char* vipCodec_MOV::getName()
 {
	if (file == NULL)
		return NULL;

	return quicktime_get_name(file);
 }

/**
 * @brief get movie's informations.
 *
 * @return pointer to a NULL terminated string.
 */
char* vipCodec_MOV::getInfo()
 {
	if (file == NULL)
		return NULL;

	return quicktime_get_info(file);
 }

/**
 * @brief get movie's copyright.
 *
 * @return pointer to a NULL terminated string.
 */
char* vipCodec_MOV::getCopyRight()
 {
	if (file == NULL)
		return NULL;

	return quicktime_get_copyright(file);
 }















vipCodec_MOVParameters::vipCodec_MOVParameters()
 {
	reset();
 }

vipCodec_MOVParameters::vipCodec_MOVParameters(const char* filename, int stream, long frameIndex)
 {
	reset();
	setFileName(filename);
	setStream(stream);
	setFrameIndex(frameIndex);
 }

void vipCodec_MOVParameters::reset()
 {
	strcpy(fileName, (const char*)"input.mov\0");
	frameIndex = 0;
 }


void vipCodec_MOVParameters::setFileName(const char *filename)
 {
	strncpy(fileName, filename, 64);
 }

void vipCodec_MOVParameters::setFrameIndex(long index)
 {
	frameIndex = index;
 }

void vipCodec_MOVParameters::setStream(int s)
 {
	stream = s;
 }


int vipCodec_MOVParameters::saveToStreamXML(FILE *fp)
 {
	if ( fp == NULL )
		return VIPRET_PARAM_ERR;

	if( fprintf(fp, "<vipCodec_MOVParameters>\n") == EOF )
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <filename value=\"%s\" />\n", fileName) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <stream value=\"%d\" />\n", stream) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <frameIndex value=\"%ld\" />\n", frameIndex) == EOF)
		return VIPRET_INTERNAL_ERR;

	if( fprintf(fp, "</vipCodec_MOVParameters>\n") == EOF )
		return VIPRET_INTERNAL_ERR;

	return VIPRET_OK;
 }


int vipCodec_MOVParameters::loadFromStreamXML(FILE *fp)
 {
	if ( fscanf(fp, "<vipCodec_MOVParameters>\n") == EOF )
		throw "error in XML file, unable to import data.";

	if ( fscanf(fp, "  <filename value=\"%s\" />\n", fileName) == EOF )
		throw "error in XML file, unable to import data.";

	if ( fscanf(fp, "  <stream value=\"%d\" />\n", &stream) == EOF )
		throw "error in XML file, unable to import data.";

	if ( fscanf(fp, "  <frameIndex value=\"%ld\" />\n", &frameIndex) == EOF )
		throw "error in XML file, unable to import data.";


	return VIPRET_OK;
 }




