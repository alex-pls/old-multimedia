/**
 *  @class   vipCodec_MPEG
 *
 *  @brief   This module interfaces VIPLibb standard format with libmpeg3
 *           library, it's able to decode following formats:
 *
 *            - MPEG-2 video
 *            - MPEG-1 video
 *            	[- mp3 audio]
 *            	[- mp2 audio]
 *            	[- ac3 audio]
 *            - MPEG-2 transport streams
 *            - MPEG-2 program streams
 *            - MPEG-1 program streams
 *            - IFO files
 *
 *           libmpeg3 library requires libpthread
 *
 *
 *  @warning Linux Only; require libmpeg3 library
 *
 *  @todo    more tests, audio support, raw data access
 *
 *  @see     vipCodec
 *  @see     libmpeg3
 *
 *  @example test_vipCodec_MPEG.cpp
 *  @example test_vipLinuxMPEGPlayer.cpp
 *  @example test_vipLinuxMPEGPlayerGTK.cpp
 *
 *  @version 0.7
 *  @date    12/09/2005
 *  @author  Alessandro Polo
 *
 *
 ****************************************************************************
 * VIPLib Framework 1.1
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib/
 *
 ****************************************************************************/



#ifndef __VIPLIB_VETCODEC_MPEG_H__
 #define __VIPLIB_VETCODEC_MPEG_H__

 #include "../vipDefs.h"
 #include "../vipCodec.h"

 #include "../vipFrameYUV420.h"
 #include "../vipFrameRGB24.h"
 #include "../vipFrameT.h"

 #include "../../support/libmpeg3/libmpeg3.h"


 #define VIPRET_CODER_FILEOUT_ERR	1010     /*  */
 #define VIPRET_CODER_SIZE_ERR		1011     /*  */
 #define VIPRET_CODER_WRITE_ERR		1012     /*  */
 #define VIPRET_CODER_PALETTE_ERR	1013     /*  */






class vipCodec_MPEGParameters : public vipCodecParameters
{
	protected:

		char fileName[64];
		long frameIndex;
		int stream;

		friend class vipCodec_MPEG;


	public:

		/**
		 * @brief  Default constructor, call reset().
		 */
		vipCodec_MPEGParameters();

		/**
		 * @brief Full constructor, call reset() and set parameters.
		 *
		 * @param[in] filename pointer to NULL terminated string [max 128].
		 * @param[in] stream movie's stream to load (default=0, first stream)
		 * @param[in] frameIndex stream position (default=0, first frame)
		 *
		 */
		vipCodec_MPEGParameters(const char* filename, int stream = 0, long frameIndex = 0);

		/**
		 * @brief  Default destructor.
		 */
		~vipCodec_MPEGParameters()  {  }

		/**
		 * @brief  Reset all parameters: filename, current stream, frame index.
		 */
		void reset();

		/**
		 * @brief  set current stream (it's not applied really, but must call
		 *         load(stream) of vipCodec_MOV class).
		 *
		 * @param[in] stream movie's stream to load (default=0, first stream)
		 */
		void setStream(int stream = 0);

		/**
		 * @brief  set current stream (it's not applied really, but must call
		 *         load(filename, stream) of vipCodec_MOV class).
		 *
		 * @param[in] stream movie's filename to load (NULL Terminated string, max 128)
		 */
		void setFileName(const char *filename);

		/**
		 * @brief  set current frame index (it's not applied really, but must call
		 *         setFrameIndex(index) of vipCodec_MOV class).
		 *
		 * @param[in] frameIndex stream position (default=0, first frame)
		 */
		void setFrameIndex(long index = 0);


		/**
		 * @brief  Serialize class to XML format.
		 *         Class' tag is <vipCodec_MOVParameters>
		 *
		 * @param[in] fp output stream's pointer
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
		 */
		VIPRESULT saveToStreamXML(FILE *fp);

		/**
		 * @brief  Deserialize class from XML format.
		 *         Class' tag must be <vipCodec_MOVParameters>
		 *
		 * @param[in] fp input stream's pointer
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
		 */
		VIPRESULT loadFromStreamXML(FILE *fp);

};






class vipCodec_MPEG :  public vipCodec
 {
	public:


	protected:

		/**
		 * @brief  Current parameters.
		 */
		vipCodec_MPEGParameters* myParams;

		/**
		 * @brief  MPEG file handle.
		 */
		mpeg3_t* file;

		/**
		 * @brief  decoded data buffer.
		 */
		unsigned char**	buff;		///< Buffer for decoded data

		/**
		 * @brief  decoded YUV Y data buffer.
		 */
		char *Y;
		/**
		 * @brief  decoded YUV U data buffer.
		 */
		char *U;
		/**
		 * @brief  decoded YUV V data buffer.
		 */
		char *V;

		/**
		 * @brief  movie's width.
		 */
		unsigned int width;

		/**
		 * @brief  movie's height.
		 */
		unsigned int height;


	public:


		/**
		 * @brief  Default constructor, initialize parameters and superclasses.
		 * @param[in] initParams parameters for this module or NULL for defaults.
		 */
		vipCodec_MPEG(vipCodec_MPEGParameters* initParams = NULL);

		/**
		 * @brief   Initialize parameters and load given quicktime movie.
		 *
		 * @param[in] filename a valid MOV movie filename
		 * @param[in] stream video stream to load (default is first: 0)
		 *
		 */
		vipCodec_MPEG(char* filename, int stream = 0);

		/**
		 * @brief Default destructor, close file and free buffer.
		 */
		~vipCodec_MPEG();


		/**
		 * @brief  MPEG encoding is not implemented in libmpeg3.
		 *
		 * @return VIPRET_NOT_IMPLEMENTED.
		 */
		VIPRESULT save() { return VIPRET_NOT_IMPLEMENTED; };
		VIPRESULT save(char *filename, int stream = 0) { return VIPRET_NOT_IMPLEMENTED; };


		/**
		 * @brief  Load movie from current filename, use SetFileName() or
		 *         load(char*, int).
		 *
		 * @return VIPRET_ILLEGAL_USE if file is not correctly loaded, VIPRET_OK else.
		 */
		VIPRESULT load();


		/**
		 * @brief  Load a BMP format image into current buffer (vipFrameRGB).
		 *
		 * @param[in] filename a valid MPEG1-2 movie filename
		 * @param[in] stream video stream to load (default is first: 0)
		 *
		 * @return VIPRET_ILLEGAL_USE if file is not correctly loaded, VIPRET_OK else.
		 */
		VIPRESULT load(char *filename, int stream = 0);


		/**
		 * @brief  Set parameters for (de)coding.
		 *
		 * @param[in] initParams Instance of vipCodec_MPEGParameters or NULL,
		 *                       NULL argument make function to create a new
		 *                       instance with default parameters.
		 *
		 * @return VIPRET_OK
		 */
		VIPRESULT setParameters(vipCodec_MPEGParameters* initParams);

		/**
		 * @brief  Get parameters for (de)coding.
		 *
		 * @return pointer to vipCodec_MPEGParameters instance.
		 */
		vipCodec_MPEGParameters& getParameters() { return *myParams; };



		VIPRESULT setFilterParameters (vipFilterParameters* initParams) { return setParameters(static_cast<vipCodec_MPEGParameters*>(initParams)); };
		vipFilterParameters* getFilterParameters () { return static_cast<vipFilterParameters*>(myParams); };


		/**
		 * @brief  Reset filename and movie related settings.
		 *
		 * @return VIPRET_OK
		 */
		VIPRESULT reset();

		/**
		 * @brief  Get the state of current data source.
		 *
		 * @return true is there are no more frames to load, false else.
		 */

		bool EoF();
//BUG
		/**
		 * @brief  Test for end of file.
		 *
		 * @return true if frame index is last frame, false else.
		 */
		bool eof(int stream = -1) const;

// FRAME BROWSING FUNCTIONS

		/**
		 * @brief  Seek to point in stream (position in the video timeline).
		 *
		 * @param[in] index position to set, number of frame offset [0, framesCount[
		 * @param[in] stream select stream index.
		 *                   default is -1: current active stream.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if index or
		 *		   stream are not valid, VIPRET_ILLEGAL_USE if stream hasn't been loaded.
		 */
		VIPRESULT setFrameIndex(long index, int stream = -1);


		/**
		 * @brief  Move frame index to previous frame
		 *
		 * @param[in] stream select stream index.
		 *                   default is -1: current active stream.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_ILLEGAL_USE is stream
		 *		   hasn't been loaded.
		 */
		VIPRESULT goToPreviousFrame(int stream = -1);

		/**
		 * @brief  Move video frame index to end (last frame)
		 *
		 * @param[in] stream select stream index.
		 *                   default is -1: current active stream.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_ILLEGAL_USE is stream
		 *		   hasn't been loaded.
		 */
		VIPRESULT goToVideoEnd(int stream = -1);

		/**
		 * @brief  Move audio sample index to end (last frame)
		 *
		 * @param[in] stream select stream index.
		 *                   default is -1: current active stream.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_ILLEGAL_USE is stream
		 *		   hasn't been loaded.
		 */
		VIPRESULT goToAudioEnd(int stream = -1);


/* Give the seconds time in the last packet read */
		double getLastPacketTime();

		/**
		 * @brief  Read current frame index (position in the video timeline).
		 *
		 * @param[in] stream select stream index.
		 *                   default is -1: current active stream.
		 *
		 * @return current frame index, -1 if stream has not been loaded.
		 *
		 */
//long getAudioFrameIndex(int stream = -1);
		/**
		 * @brief  Read current sample index (position in the audio timeline).
		 *
		 * @param[in] stream select stream index.
		 *                   default is -1: current active stream.
		 *
		 * @return current frame index, -1 if stream has not been loaded.
		 */
//long getVideoFrameIndex(int stream = -1);


// VIDEO INFO FUNCTIONS

		/**
		 * @brief read current image's width.
		 *
		 * @return Width in pixel.
		 */
		unsigned int getWidth() const { return width; };

		/**
		 * @brief read current image's height.
		 *
		 * @return Height in pixel.
		 */
		unsigned int getHeight() const { return height; };


		/**
		 * @brief read color model for selected stream.
		 *
		 * @param[in] stream select stream index.
		 *                   default is -1: current active stream.
		 *
		 * @return Color Model.
		 */
		int getColorModel(int stream = -1);


		/**
		 * @brief check if loaded movie has a video stream.
		 *
		 * @return true if there is at least one video stream, false else.
		 */
		bool hasVideo(int stream = -1);

		/**
		 * @brief get movie's video streams count.
		 *
		 * @return number of video streams.
		 */
		int getVideoStreamCount();

		/**
		 * @brief get movie's video frame rate.
		 *
		 * @param[in] stream select stream index.
		 *                   default is -1: current active stream.
		 *
		 * @return number of frame per second.
		 */
		float getVideoFrameRate(int stream = -1);

		/**
		 * @brief get movie's video frame count.
		 *
		 * @param[in] stream select stream index.
		 *                   default is -1: current active stream.
		 *
		 * @return number of frames in the stream.
		 */
		long getVideoStreamLength(int stream = -1);



// AUDIO INFO FUNCTIONS

		/**
		 * @brief get movie's audio streams count.
		 *
		 * @return number of audio streams.
		 */
		bool hasAudio(int stream = -1);

		/**
		 * @brief get movie's audio streams count.
		 *
		 * @return number of audio streams.
		 */
		int getAudioStreamCount();

		/**
		 * @brief get movie's audio channel count for selected stream.
		 *
		 * @param[in] stream select stream index.
		 *                   default is -1: current active stream.
		 *
		 * @return number of audio channels.
		 */
		int getAudioChannels(int stream = -1);

		/**
		 * @brief get movie's audio sample rate for selected stream.
		 *
		 * @param[in] stream select stream index.
		 *                   default is -1: current active stream.
		 *
		 * @return number of sample per second.
		 */
		float getAudioSampleRate(int stream = -1);

		/**
		 * @brief get movie's audio sample count for selected stream.
		 *
		 * @param[in] stream select stream index.
		 *                   default is -1: current active stream.
		 *
		 * @return number of sample.
		 */
		long getAudioStreamLength(int stream = -1);


		/**
		 * @brief  Set current canvas' height.
		 *
		 * @return height in pixel.
		 */
		VIPRESULT setHeight(unsigned int value)
		 {
			height = value;
			return VIPRET_OK;
		 };

		/**
		 * @brief  Set current canvas' width.
		 *
		 * @return width in pixel.
		 */
		VIPRESULT setWidth(unsigned int value)
		 {
			width = value;
			return VIPRET_OK;
		 };



		static int getMPEG3_Version_major();
		static int getMPEG3_Version_minor();
		static int getMPEG3_Version_release();





		/**
		 * @brief Load current frame data into image (parameter), increments
		 *        frame index.
		 *
		 * @param[out] img VIPLibb Cache Frame to store data.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
		 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
		 *
		 * @note  Ouput operator (>>) call directly this function.
		 * @see   operator >> (vipFrameYUV420&)
		 */
		VIPRESULT extractTo(vipFrameYUV420& img);

		/**
		 * @brief Load current frame data into image (parameter), increments
		 *        frame index.
		 *
		 * @param[out] img VIPLibb Cache24 Frame to store data.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
		 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
		 *
		 * @note  Ouput operator (>>) call directly this function.
		 * @see   operator >> (vipFrameRGB24&)
		 */
		VIPRESULT extractTo(vipFrameRGB24& img);


		/**
		 * @brief Load current frame data into image (parameter), increments
		 *        frame index.
		 *
		 * @param[out] img Greyscale VIPLibb Frame to store data.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
		 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
		 *
		 * @note  Ouput operator (>>) call directly this function.
		 * @see   operator >> (vipFrameT&)
		 */
		VIPRESULT extractTo(vipFrameT<unsigned char>& img);



		/**
		 * @brief  Load movie from current filename, use SetFileName() or
		 *         load(char*, int).
		 *
		 * @return VIPRET_ILLEGAL_USE if file is not correctly loaded, VIPRET_OK else.
		 */
		VIPRESULT importFrom(vipFrameYUV420& img);

		/**
		 * @brief  Load movie from current filename, use SetFileName() or
		 *         load(char*, int).
		 *
		 * @return VIPRET_ILLEGAL_USE if file is not correctly loaded, VIPRET_OK else.
		 */
		VIPRESULT importFrom(vipFrameRGB24& img);

		/**
		 * @brief  Load movie from current filename, use SetFileName() or
		 *         load(char*, int).
		 *
		 * @return VIPRET_ILLEGAL_USE if file is not correctly loaded, VIPRET_OK else.
		 */
		VIPRESULT importFrom(vipFrameT<unsigned char>& img);






		/**
		 * @brief Input operator, import standard VIPLibb frame formats,
		 *        current implementation calls directly importFrom() method.
		 *
		 * @param[in] img VIPLibb Cache Frame to be processed (encoded for example)
		 *
		 * @see   importFrom(vipFrameYUV420&)
		 */
//		void operator << (vipFrameYUV420& img) { vipOutput::operator << (img); }
//		void operator << (vipFrameRGB24& img) { vipOutput::operator << (img); }
//		void operator << (vipFrameT<unsigned char>& img) { vipOutput::operator << (img); }

		/**
		 * @brief Ouput operator, export to standard VIPLibb frame formats,
		 *        current implementation calls directly extractTo() method
		 *        and if framerate isn't zero waits untill clock is syncronized,
		 *        if elaboration time is greater than sleeptime, no delay is applied.
		 *
		 * @param[out] img VIPLibb Cache Frame to store data.
		 *
		 * @return Address of current instance.
		 *
		 * @see   importFrom(vipFrameYUV420&)
		 * @see   vipsleep()
		 * @see   setElaborationStart()
		 * @see   getElaborationTime()
		 */
//		vipInput& operator >> (vipFrameYUV420& img) { vipInput::operator >> (img); return *this; }
//		vipInput& operator >> (vipFrameRGB24& img) { vipInput::operator >> (img); return *this; }
//		vipInput& operator >> (vipFrameT<unsigned char>& img) { vipInput::operator >>( img); return *this; }


		bool isEncodingAvailable() { return false; };
		bool isDecodingAvailable() { return true; };


};






#endif //__VIPLIB_VETCODEC_MPEG_H__
