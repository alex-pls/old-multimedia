/** @file vipCodec_RAW.cpp
 *
 * File containing methods for the 'vipCodec_RAW' class.
 * The header for this class can be found in vipCodec_RAW.h, check that file
 * for class description.
 *
 *
 *
 ****************************************************************************
 * VIPLibb Framework 1.02
 *  Copyright (C) Alessandro Polo 2005
 *  http://mmlab.science.unitn.it/projects/VIPLib/
 *
 ****************************************************************************/



#include "vipCodec_RAW.h"
#include "../vipUtility.h"
#include "../../support/ccvt/ccvt.h"
#include <math.h>
//#include <string.h>
#include <string>



//////////////////////////////////////////////////////////////////


vipCodec_RAW::vipCodec_RAW( vipCodec_RAWParameters* initParams ) : vipCodec()
 {
	DEBUGMSG("vipCodec_RAW::vipCodec_RAW(vipCodec_RAWParameters* initParams) [CONTRUCTOR] ", *filename)

//printf("DEBUG:::::::vipCodec_RAW costrutt. initparam\n");

	myParams = NULL;

	f = NULL;
	reset();
	setParameters(initParams);

 }



/**
 * @brief  Initialize parameters and load image/video stream from file.
 *         vipFrameRGB constructor.
 *
 * @param[in] filename Input BMP filename.
 * @param[in] format BMP Encoding Format, default auto-selection.
 */
vipCodec_RAW::vipCodec_RAW(char *filename, int stream) : vipCodec()
 {
	DEBUGMSG("vipCodec_RAW::vipCodec_RAW(char *filename, FileFormat format) [CONTRUCTOR] ", *filename)

//printf("DEBUG:::::::vipCodec_RAW costrutt. *filename\n");


	f = NULL;

	reset();
	setParameters(NULL);
 	load(filename, stream);

 }



VIPRESULT vipCodec_RAW::reset()
 {
	INFO("int vipCodec_RAW::reset() [SET DEFAULT PARAMETERS]")

//printf("DEBUG:::::::vipCodec_RAW reset\n");


	width  = 0;      //dimension of Y plane(not necessary ...)
	height = 0;
	UVwidth = 0;
	UVheight = 0;

	range_S = 0;
	average_S = 0;

	close();

	f = NULL;

	if (myParams != NULL)
		myParams->reset();//reset the param file..



	/*if (pData != NULL){

		delete pData;
		pData = NULL;

		}*/


	setName("vipCoder_RAW");
	setDescription("Reads YUV 4:2:0");
	setVersion(1.0);

	return VIPRET_OK;
 }


vipCodec_RAW::~vipCodec_RAW()
 {
//printf("DEBUG:::::::vipCodec_RAW distrutt.\n");


	if (myParams != NULL)
		delete myParams;


	/*if (pData != NULL){
		delete pData;
		pData = NULL;
		}*/

 }


bool vipCodec_RAW::EoF(){

	if ( myParams->frameIndex >= NumberFrame)

		return true;

	else

		return false;
	}



VIPRESULT vipCodec_RAW::setParameters (vipCodec_RAWParameters* initParams)
 {
//printf("DEBUG:::::::vipCodec_RAW setparameters. initparam\n");


	if ( initParams == NULL )

		myParams = new vipCodec_RAWParameters();

	else

		myParams = initParams;


	return VIPRET_OK;
 }


/**
 * @brief  Load an image/video into current buffer ().
 *
 * @param[in] filename Input
 * @
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 */
VIPRESULT vipCodec_RAW::load(char *filename, int stream)
 {
	DEBUGMSG("int vipCodec_RAW::load(char *filename, FileFormat format) [loading data to buffer.]", filename)

//printf("DEBUG:::::::vipCodec_RAW load *filename\n");


 	myParams->setFileName(filename);
 	myParams->setStream(stream);

	load();

	return VIPRET_OK;
 }

VIPRESULT vipCodec_RAW::load()
 {
	DEBUGMSG("int vipCodec_RAW::load() [loading data to buffer..]",filename)

//printf("DEBUG:::::::vipCodec_RAW load\n");

	//register some info from myParams

	width = myParams->Ywidth;
	height = myParams->Yheight;


	//open file pointed by myParams

	f = fopen(myParams->fileName,"rb");
	//printf("formato %s\n",myParams->Video_Format);
	//some dditional calculation..
	//set the UV planes dimensions and the pixel/frame value..

	if(strncmp(myParams->Video_Format,"Y",10) == 0){	//only Y plane

				UVwidth = 0;
				UVheight = 0;
				NumberPixel = width * height;

	}

	else

		if(strncmp(myParams->Video_Format,"YUV_4:2:0",10) == 0){	//full YUV downsampled

				UVwidth = width/2;
				UVheight = height/2;
				NumberPixel = width * height * 3/2;


	}

	else

		if(strncmp(myParams->Video_Format,"YUV_4:4:4",10)==0){	//full YUV

				UVwidth = width;
				UVheight = height;
				NumberPixel = width * height * 3;

				}
	else
		return VIPRET_PARAM_ERR;


	//calculating the dimension of the video in frame..

	fseek(f,0,SEEK_END);
	long DataLenght = ftell(f);

	//total number of frame
	NumberFrame = (unsigned int) DataLenght / NumberPixel;
	//printf("numberframe %d\n",NumberFrame);

	//allocating space for memorize 1 frame for now..

	if (!pData)
	{
		if ((pData = new unsigned char [NumberPixel]) == NULL)
		{
			printf("pdata problem..\n");
			return VIPRET_PARAM_ERR;
		}
	}

	pData = new unsigned char [NumberPixel];


	return VIPRET_OK;
	}


unsigned char vipCodec_RAW::ReadFrame(unsigned int Frame)
{
	DEBUGMSG("unsigned char vipCodec_RAW::ReadFrame(unsigned int Frame) [reading frame..]", Frame)

//printf("DEBUG:::::::vipCodec_RAW readframe frame.\n");


	if (Frame >= NumberFrame)
		{
		printf("Error reading frame..\nframe %d,numbframe %d\n",Frame,NumberFrame);
		return VIPRET_INTERNAL_ERR;
		}

	//if we are not open for reading, then open for reading.

	if (f == NULL){//?????? so work...
		fopen(myParams->fileName,"rb");
		printf("\n (ReadFrame)I/O error..\n");
		//printf("myparam %s\n",myParams->fileName);

		return VIPRET_ILLEGAL_USE ;
	}

	//int bo = sizeof(&pData);
	//printf("\n%d \n",bo);
	//printf("\n%d\n",sizeof(unsigned char));


	myParams->frameIndex = Frame;      //FrameNumber


	//move the pointer to the right position

	fseek(f,Frame * NumberPixel, SEEK_SET);


	//read the data of a single frame..

	int num = fread(pData, 1 , NumberPixel, f);





	return VIPRET_OK;
}



VIPRESULT vipCodec_RAW::newVideo(const char *filename)
 {
	DEBUGMSG("int vipCodec_RAW::newVideo(const char *filename) [opening file for writing..]", filename)

//printf("DEBUG:::::::vipCodec_RAW newvideo *filename\n");


	if ( f != NULL)
		return VIPRET_ILLEGAL_USE;

 	myParams->setFileName(filename);
	myParams->setFrameIndex(0);
	myParams->setStream(0);//tanto per..

	f = fopen(filename, "wb");   //crea un nuovo file e sovrascrive il precedente..

	//mode binary append...
	f = fopen(filename, "ab");	//occhio che non cancella il file se c'e gia..

	if ( f == NULL)
		return VIPRET_INTERNAL_ERR;

	return VIPRET_OK;

 }


VIPRESULT vipCodec_RAW::close()
 {
	DEBUGMSG("int vipCodec_RAW::close() [closing class structure]", filename)

//printf("DEBUG:::::::vipCodec_RAW close\n");


	if ( f == NULL)
		return VIPRET_ILLEGAL_USE;

	fclose(f);


	return VIPRET_OK;
 }





/**
 * @brief  Load data into passed image, move current index to next frame.
 *
 * @param[out] img VIPLibb Cache Frame to store data.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note   Ouput operator (>>) call directly this function.
 * @see    operator >> (vipFrameCache&)
 * @see    AutoInput
 */
VIPRESULT vipCodec_RAW::extractTo(vipFrameYUV420& img)
 {
	DEBUGMSG("int vipCodec_RAW::extractTo(vipFrameYUV420& img) [pushing data]", doBuffering)

//printf("DEBUG:::::::vipCodec_RAW extract\n");

	//controll about the type of capture and the dimension of the structure..

	if (width != img.width || height != img.height)
		{
		delete[] img.data;
		//create a matrix of unsigned char
		  img.data = new unsigned char [NumberPixel];
		}
	img.width = width;
	img.height = height;


//now read the frame passed from frameIndex, in myParam, into a temp array, pData
//readframe cares about onlyY capture or full YUV planes..

	ReadFrame(myParams->frameIndex);
	//for(int i = 0; i < NumberPixel; i++)
	img.data = pData;


	//move forward the frame indexer, in myParams...

	myParams->frameIndex++;

	return VIPRET_OK;
 }



/**
 * @brief  Load data into passed image, move current index to next frame.
 *
 * @param[out] img VIPLibb Cache24 Frame to store data.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note   Ouput operator (>>) call directly this function.
 * @see    operator >> (vipFrameCache24&)
 * @see    AutoInput
 */
VIPRESULT vipCodec_RAW::extractTo(vipFrameRGB24& img)
 {
	DEBUGMSG("int vipCodec_RAW::extractTo(vipFrameRGB24& img) [pushing data]", doBuffering)

//printf("DEBUG:::::::vipCodec_RAW extract\n");
		if (width != img.width || height != img.height)
		{
		delete[] img.data;
		//create a matrix of PixelRGB, each PixelRGB is an array of unsigned char[3]
		  img.data = new PixelRGB24 [width * height];
		}
	img.width = width;
	img.height = height;


//now read the frame passed from frameIndex, in myParam, into a temp array, pData
//readframe cares about onlyY capture or full YUV planes..

	ReadFrame(myParams->frameIndex);
	//printf("myparam..%s\n",myParams->fileName);

	//chrominance upsampling..
	unsigned char* upsampled_data;

	upsampled_data = UV_upsampling(pData,width,height);
	conv_PlanarYUVtoPixelRGB(upsampled_data, (unsigned char*)img.data[0], width, height);
	//conv_PixelRGBtoPlanarYUV((unsigned char*) img.data[0], buffer, width, height);

	//FILE*  fi;
	//fi=fopen("YUV444.yuv","wb");
	//fwrite(upsampled_data,1,width*height*3,fi);

	//move forward the frame indexer, in myParams...

	myParams->frameIndex++;

	//free buffered resources..
	delete upsampled_data;

	return VIPRET_OK;
 }



/**
 * @brief  Load data into passed image, move current index to next frame.
 *
 * @param[out] img Color VIPLibb Frame to store data.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note   Ouput operator (>>) call directly this function.
 * @see    operator >> (vipFrameRGB&)
 * @see    AutoInput
 */
VIPRESULT vipCodec_RAW::extractTo(vipFrameT<unsigned char>& img)
 {
	DEBUGMSG("int vipCodec_RAW::extractTo(vipFrameRGB& img) [pushing data]", doBuffering)

//printf("DEBUG:::::::vipCodec_RAW extract\n");

	return VIPRET_NOT_IMPLEMENTED;
 }



/**
 * @brief  Load data into passed image, move current index to next frame.
 *
 * @param[out] img Greyscale VIPLibb Frame to store data.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note   Ouput operator (>>) call directly this function.
 * @see    operator >> (vipFrameGrey&)
 * @see    AutoInput
 */

 /*int vipCodec_RAW::extractTo(vipFrameGrey& img)
 {
	DEBUGMSG("int vipCodec_RAW::extractTo(vipFrameGrey& img) [pushing data]", doBuffering)

printf("DEBUG:::::::vipCodec_RAW extract\n");

	return VIPRET_NOT_IMPLEMENTED;
 }*/




/**
 * @brief  Add given image to current stream.
 *
 * @param[in] img VIPLibb Cache Frame to be processed (encoded for example)
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note   Input operator (<<) call directly this function.
 * @see    operator << (vipFrameCache&)
 */
VIPRESULT vipCodec_RAW::importFrom(vipFrameYUV420& img)
 {
	DEBUGMSG("int vipCodec_RAW::importFrom(vipFrameYUV420& img) [reading data]", doBuffering)

//printf("DEBUG:::::::vipCodec_RAW import\n");

//control for stream dimensions..

	if ( f == NULL)
		{
		printf("I/O file error..\n");
		return VIPRET_ILLEGAL_USE;
		}


	if(myParams->Ywidth == -1 || myParams->Ywidth == -1){

		myParams->setYheight(img.getHeight());
		myParams->setYwidth(img.getWidth());


	}


	//depending on the case (full YUV capture or not..),
	//we procede by copying the data into the file structure.

	if(strcmp(myParams->Video_Format,"Y") == 0)
		fwrite(img.data, 1, img.height * img.width, f);
	else
		if(strcmp(myParams->Video_Format,"YUV_4:2:0") == 0)
			fwrite(img.data, 1, img.height * img.width * 3/2, f);
		else
			if(strcmp(myParams->Video_Format,"YUV_4:4:4") == 0)
			fwrite(img.data, sizeof(unsigned char), img.height * img.width * 3, f);


	//move forward the frame indexer, in myParams..
	myParams->frameIndex++;

	return VIPRET_OK;
 }



/**
 * @brief  Add given image to current stream.
 *
 * @param[in] img VIPLibb RGB24 Frame to be processed (encoded for example)
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note   Input operator (<<) call directly this function.
 * @see    operator << (vipFrameRGB24&)
 */
VIPRESULT vipCodec_RAW::importFrom(vipFrameRGB24& img)
 {
	DEBUGMSG("int vipCodec_RAW::importFrom(vipFrameRGB24& img) [reading data]", doBuffering)

//printf("\n\n******************DEBUG:::::::vipCodec_RAW import******************\n\n");

	if ( f == NULL)
		{
		printf("I/O file error..\n");
		return VIPRET_ILLEGAL_USE;
		}


	unsigned char* buffer=new unsigned char[img.width*img.height*3];

	if(myParams->Ywidth == -1 || myParams->Ywidth == -1)
	{
		myParams->setYheight(img.getHeight());
		myParams->setYwidth(img.getWidth());
	}


	conv_PixelRGBtoPlanarYUV((unsigned char*) img.data[0], buffer, img.width, img.height);

	fwrite(buffer, 1, img.height * img.width * 3, f);

	//move forward the frame indexer, in myParams..
	myParams->frameIndex++;
	delete buffer;

	return VIPRET_OK;
 }





/**
 * @brief  Add given image to current stream.
 *
 * @param[in] img Color VIPLibb Frame to be processed (encoded for example)
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note   Input operator (<<) call directly this function.
 * @see    operator << (vipFrameRGB&)
 */
VIPRESULT vipCodec_RAW::importFrom(vipFrameT<unsigned char>& img)
 {
	DEBUGMSG("int vipCodec_RAW::importFrom(vipFrameRGB& img) [reading data]", doBuffering)

//printf("DEBUG:::::::vipCodec_RAW import\n");


	return VIPRET_NOT_IMPLEMENTED;

 }




/**
 * @brief  Add given image to current stream.
 *
 * @param[in] img Greyscale VIPLibb Frame to be processed (encoded for example)
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note   Input operator (<<) call directly this function.
 * @see    operator << (vipFrameGrey&)
 */

 /*int vipCodec_RAW::importFrom(vipFrameGrey& img)
 {
	DEBUGMSG("int vipCodec_RAW::importFrom(vipFrameCache& img) [reading data]", doBuffering)

printf("DEBUG:::::::vipCodec_RAW import\n");


	return VIPRET_OK;

 }*/






























vipCodec_RAWParameters::vipCodec_RAWParameters()
 {
//printf("DEBUG:::::::vipCodec_RAWparameters costrutt.\n");

	reset();

 }

vipCodec_RAWParameters::vipCodec_RAWParameters(const char* filename, int stream, long frameIndex)
 {
//printf("DEBUG:::::::vipCodec_RAWparameters setparameters *filename.\n");

	reset();
	setFileName(filename);
	setStream(stream);
	setFrameIndex(frameIndex);
 }

void vipCodec_RAWParameters::reset()
 {
//printf("DEBUG:::::::vipCodec_RAWparameters reset\n");

	strcpy(fileName,"not_assigned");
	Fps=-1;
	frameIndex = 0;
	stream = -1;
	Ywidth = -1;
	Yheight = -1;
	strcpy(Video_Format,"not_assigned");	//default not assigned
 }


void vipCodec_RAWParameters::setYwidth(int width)
 {
    Ywidth = width;
 }

void vipCodec_RAWParameters::setYheight(int height)
 {
    Yheight = height;
 }


void vipCodec_RAWParameters::setVideoFormat(const char* format)
 {
    strcpy ( Video_Format,format );

 }




void vipCodec_RAWParameters::setFileName(const char *filename)
 {
	strcpy ( fileName, filename );
 }



void vipCodec_RAWParameters::setFrameIndex(long index)
 {
	frameIndex = index;
 }



void vipCodec_RAWParameters::setStream(int s)
 {
	stream = s;
 }

 void vipCodec_RAWParameters::setFps(int fps)
 {
	Fps = fps;
 }



/**
 * @brief  Serialize class to XML format.
 *         Class' tag is <vipCodec_MOVParameters>
 *
 * @param[in] fp output stream's pointer
 *
 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
 */
VIPRESULT vipCodec_RAWParameters::saveToStreamXML(FILE *fp)
 {


	if ( fp == NULL )
		return VIPRET_PARAM_ERR;

	if( fprintf(fp, "<vipCodec_RAWParameters>\n") == EOF )
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <filename value=\" %s \" />\n", fileName) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <stream value=\" %d \" />\n", stream) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <frameIndex value=\" %ld \" />\n", frameIndex) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <video format=\" %s \" />\n", Video_Format) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <width value=\" %d \" />\n", Ywidth) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <height value=\" %d \" />\n", Yheight) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <frame rate value=\" %d \" />\n", Fps) == EOF)
		return VIPRET_INTERNAL_ERR;

	if( fprintf(fp, "</vipCodec_RAWParameters>\n") == EOF )
		return VIPRET_INTERNAL_ERR;

	return VIPRET_OK;
 }




/**
 * @brief  Deserialize class from XML format.
 *         Class' tag must be <vipCodec_RAWParameters>
 *
 * @param[in] fp input stream's pointer
 *
 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR else.
 */
VIPRESULT vipCodec_RAWParameters::loadFromStreamXML(FILE *fp)
 {
	char line[64];

	fgets(line,64,fp);
	if(strcmp(line,"<vipCodec_RAWParameters>\n") != 0)
		throw( "error in XML file, unable to import data.");

	fgets(line,64,fp);
	if (sscanf(line,"  <filename value=\"%s\" />\n",fileName) == EOF)
		throw ("error in XML file, unable to import data.");
	//else
	//	printf("filename read %s\n",fileName);

	fgets(line,64,fp);
	if ( sscanf(line, "  <stream value=\"%d\" />\n", &stream) == EOF )
		throw ("error in XML file, unable to import data.");
	//else
	//	printf("stream value loaded= %d\n", stream);

	fgets(line,64,fp);
	if ( sscanf(line, "  <frameIndex value=\"%ld\" />\n", &frameIndex) == EOF )
		throw ("error in XML file, unable to import data.");
	//else
	//	printf("frameindex value loaded= %ld\n", frameIndex);

	fgets(line,64,fp);
	if ( sscanf(line, "  <video format=\"%s\" />\n", Video_Format) == EOF)
		throw ("error in XML file, unable to import data.");
	//else
	//	printf("video format= %s\n",Video_Format);

	fgets(line,64,fp);
	if ( sscanf(line, "  <width value=\"%d\" />\n", &Ywidth) == EOF)
		throw ("error in XML file, unable to import data.");
	//else
	//	printf("width loaded= %d\n",Ywidth);

	fgets(line,64,fp);
	if ( sscanf(line, "  <height value=\"%d\" />\n", &Yheight) == EOF)
		throw ("error in XML file, unable to import data.");
	//else
	//	printf("height loaded= %d\n",Yheight);

	fgets(line,64,fp);
	if ( sscanf(line, "  <frame rate value=\"%d\" />\n", &Fps) == EOF)
		throw ("error in XML file, unable to import data.");


/*char* line;
	fpos_t init_position;
	//memorize the init_position in file..
	int i = fgetpos(fp,&init_position);

	//go to the end of file to see how long it is..
	fseek(fp,1,SEEK_END);
	int end_position = ftell(fp);
	printf("end_position %d",end_position);
	int file_lenght = end_position - init_position;

	//allocate a char buffer..
	line = new char [file_lenght];
	printf("file lungo %d\n", file_lenght);

	//reset the file pointer to the init_position..
	fsetpos(fp,&init_position);

	//read tha fiel content..
	fread(line,sizeof(char),file_lenght,fp);
	printf("file letto %s\n",line);


	//retrieve info from file and store in local variables..
*/
	/*if ( fscanf(fp, "<vipCodec_RAWParameters>\n") == EOF )
		throw( "error in XML file, unable to import data.");



	if ( fscanf(fp, "  <filename value=\"%s\" />\n", fileName) == EOF )
		throw( "error in XML file, unable to import data.");
	else
		printf("filename loaded= %s\n",fileName);


	if ( fscanf(fp, "  <stream value=\"%d\" />\n", &stream) == EOF )
		throw ("error in XML file, unable to import data.");
	else
		printf("stream value loaded= %d\n", stream);


	if ( fscanf(fp, "  <frameIndex value=\"%ld\" />\n", &frameIndex) == EOF )
		throw ("error in XML file, unable to import data.");
	else
		printf("frameindex value loaded= %ld\n", frameIndex);


	if ( fscanf(fp, "  <video format=\"%s\" />\n", Video_Format) == EOF)
		throw ("error in XML file, unable to import data.");
	else
		printf("video format= %s\n",Video_Format);


	if ( fscanf(fp, "  <width value=\"%d\" />\n", &Ywidth) == EOF)
		throw ("error in XML file, unable to import data.");
	else
		printf("width loaded= %d\n",Ywidth);


	if ( fscanf(fp, "  <height value=\"%d\" />\n", &Yheight) == EOF)
		throw ("error in XML file, unable to import data.");
	else
		printf("height loaded= %d\n",Yheight);*/








	return VIPRET_OK;
 }














































// temporaneamente, da spostare in vipUtility o classi affini :







/**
* @brief  Make the interpolation of crominance component
*
* @param[in] in structure in YUV420 color space
* @param[out] out structure in YUV444 color space
* @return pointer to the upsampled structure..
*/
unsigned char* vipCodec_RAW::UV_upsampling(unsigned char* in, int width, int height)
{
 unsigned char* U = in+width*height;
 unsigned char* V = in+width*height*5/4;

 unsigned char* out_U = new unsigned char[width * height];
 unsigned char* out_V = new unsigned char[width * height];

 unsigned char** column_U = new unsigned char*[width];
 unsigned char** column_V = new unsigned char*[width];

 unsigned char* out_Us = new unsigned char[height * width/2];
 unsigned char* out_Vs = new unsigned char[height * width/2];

 unsigned char** column_Us = new unsigned char*[width/2];
 unsigned char** column_Vs = new unsigned char*[width/2];

 unsigned char* bufferY = new unsigned char[width*height];
 unsigned char* bufferU = new unsigned char[width*height];
 unsigned char* bufferV = new unsigned char[width*height];

 unsigned char* out = new unsigned char[width * height * 3];



 //making upsampling by interpolation of row first and
 //in second time by interpolation of column
 //from 420-->"422" and from "422"-->444 accordin MSDN formula..

 //begin with 420-->422
 //NB::::the first 2 row and last 3 are handled later...

 for (int row = 2; row < height - 3; row++)//row index
  for(int col = 0; col < width/2; col++)
  {
   if((row % 2) == 0)//line even
   {
	out_Us[row * width/2 + col] = U[row/2 * width/2 +col];
	out_Vs[row * width/2 + col] = V[row/2 * width/2 +col];
   }
   else			//line odd
   {
	int sup = row/2; //integer part
	int sup1 = sup - 1;

	out_Us[row*width/2 + col] = (9*(U[sup*width/2+col]+U[(sup+1)*width/2+col])-
	 (U[sup1*width/2+col]+U[(sup+2)*width/2+col])+8)>>4;

	out_Vs[row*width/2 + col] = (9*(V[sup*width/2+col]+V[(sup+1)*width/2+col])-
	 (V[sup1*width/2+col]+V[(sup+2)*width/2+col])+8)>>4;
   }
  }



  //first 2 row + 3 last rows
  for(int col3 = 0; col3 < width/2; col3++)
  {
   //row 0
   out_Us[col3] = U[col3];
   out_Vs[col3] = V[col3];

   //row 1
   out_Us[width/2 + col3] = (9*(U[col3] + U[width/2 + col3])-
	(U[col3] + U[width + col3]) + 8)>>4;

   out_Vs[width/2 + col3] = (9*(V[col3] + V[width/2 + col3])-
	(V[col3] + V[width + col3]) + 8)>>4;

   //row height-3
   out_Us[(height-3)*(width/2) +col3] = (9*(U[(height/2 - 2)*(width/2) +col3] + U[(height/2 - 1)*(width/2) +col3])-
	(U[(height/2 - 3)*(width/2) +col3] + U[(height/2 - 1)*(width/2) +col3]) +8)>>4;

   out_Vs[(height-3)*(width/2) +col3] = (9*(V[(height/2 - 2)*(width/2) +col3] + V[(height/2 - 1)*(width/2) +col3])-
	(V[(height/2 - 3)*(width/2) +col3] + V[(height/2 - 1)*(width/2) +col3]) +8)>>4;

   //row height-2
   out_Us[(height-2)*(width/2) +col3] = U[(height/2 - 1)*(width/2) +col3];
   out_Vs[(height-2)*(width/2) +col3] = V[(height/2 - 1)*(width/2) +col3];

   //row height-1
   out_Us[(height-1)*(width/2) +col3] = (9*(U[(height/2 - 1)*(width/2) +col3] + U[(height/2 - 1)*(width/2) +col3])-
	(U[(height/2 - 2)*(width/2) +col3] + U[(height/2 - 1)*(width/2) +col3]) +8)>>4;

   out_Vs[(height-1)*(width/2) +col3] = (9*(V[(height/2 - 1)*(width/2) +col3] + V[(height/2 - 1)*(width/2) +col3])-
	(V[(height/2 - 2)*(width/2) +col3] + V[(height/2 - 1)*(width/2) +col3]) +8)>>4;
  }


  //now procede throw the convertion "422" --> 444

  //memory allocation for column array..
  for(int col1 = 0; col1 < width; col1++)
  {
   if(col1 < width/2)
   {
	column_U[col1] = new unsigned char[height];
	column_V[col1] = new unsigned char[height];

	column_Us[col1] = new unsigned char[height];
	column_Vs[col1] = new unsigned char[height];
   }
   else
   {
	column_U[col1] = new unsigned char[height];
	column_V[col1] = new unsigned char[height];
   }
  }


  //calculation of column array in out_Us,out_Vs..
  for(int col2 = 0; col2 < width/2; col2++)
  {
   for(int row1 = 0; row1 < height; row1++)
   {
	column_Us[col2][row1] = out_Us[col2 + row1*width/2];
	column_Vs[col2][row1] = out_Vs[col2 + row1*width/2];
   }
  }

  //now procede with the upper algorithm, modified to interpolate the columns..

  for(int col4 = 2; col4 < width - 3; col4++)//the last 3 column are handled later...
  {
   for(int row2 = 0; row2 < height; row2++)
   {
	if((col4 % 2) == 0)
	{
	 column_U[col4][row2] = column_Us[col4 /2][row2];
	 column_V[col4][row2] = column_Vs[col4 /2][row2];
	}
	else
	{
	 int sup2 = col4 / 2;   //integer part...
	 int sup3 = sup2 - 1;

	 column_U[col4][row2] = (9* (column_Us[sup2][row2] + column_Us[sup2+1][row2]) -
	  (column_Us[sup3][row2] + column_Us[sup2+2][row2]) +8)>>4;

	 column_V[col4][row2] = (9* (column_Vs[sup2][row2] + column_Vs[sup2+1][row2]) -
	  (column_Vs[sup3][row2] + column_Vs[sup2+2][row2]) +8)>>4;
	}
   }
  }

  //setting value for the first 2 and last 3 column..
  for(int row4 = 0; row4 < height; row4++)
  {
   //column 0
   column_U[0][row4] = column_Us[0][row4];
   column_V[0][row4] = column_Vs[0][row4];

   //column 1
   column_U[1][row4] = (9* (column_Us[0][row4] + column_Us[1][row4]) -
	(column_Us[0][row4] + column_Us[2][row4]) +8)>>4;

   column_V[1][row4] = (9* (column_Vs[0][row4] + column_Vs[1][row4]) -
	(column_Vs[0][row4] + column_Vs[2][row4]) +8)>>4;

   //column width-3
   column_U[width-3][row4] = (9*(column_Us[width/2 -2][row4] + column_Us[width/2 -1][row4])-
	(column_Us[width/2 -3][row4] + column_Us[width/2 -1][row4])+8)>>4;

   column_V[width-3][row4] = (9*(column_Vs[width/2 -2][row4] + column_Vs[width/2 -1][row4])-
	(column_Vs[width/2 -3][row4] + column_Vs[width/2 -1][row4])+8)>>4;

   //column width-2
   column_U[width-2][row4] = column_Us[width/2 -1][row4];
   column_V[width-2][row4] = column_Vs[width/2 -1][row4];

   //column width-1
   column_U[width-1][row4] = (9*(column_Us[width/2 -1][row4] + column_Us[width/2 -1][row4])-
	(column_Us[width/2 -2][row4] + column_Us[width/2 -1][row4])+8)>>4;
   column_V[width-1][row4] = (9*(column_Vs[width/2-2][row4] + column_Vs[width/2-1][row4])-
	(column_Vs[width/2 -2][row4] + column_Vs[width/2 -1][row4])+8)>>4;
  }


  //now we procede by copying the new interpolated data into the new structure...
  int cont2=0;
  int cont3=-1;

  for (int cont = 0;cont < width * height; cont++,cont2++)
  {
   if (cont%width == 0)
   {
	cont2=0;
	cont3++;
   }
   bufferY[cont] = in[cont];//pData
   bufferU[cont] = column_U[cont2][cont3];
   bufferV[cont] = column_V[cont2][cont3];
  }

  //copy all new data in new out structure..(YUV444)
  for(int cont1 = 0; cont1 < width * height; cont1++)
  {
   out[cont1] = bufferY[cont1];
   out[width*height+cont1] = bufferU[cont1];
   out[2*width*height+cont1] = bufferV[cont1];
  }

  //freeing the resources...


  for(int col5 = 0; col5 <width; col5++)
  {
   if(col5 < width/2)
   {
	delete[] column_U[col5];
	delete[] column_V[col5];
	delete[] column_Us[col5];
	delete[] column_Vs[col5];
   }
   else
   {
	delete[] column_U[col5];
	delete[] column_V[col5];
   }
  }

  delete[] out_U; delete[] out_V;
  delete[] out_Us; delete[] out_Vs;
  delete[] bufferY; delete[] bufferU; delete[] bufferV;
  delete column_U; delete column_V; delete column_Us;delete column_Vs;

  return out;

}




/**
* @brief  Make the color space conversion
*
* @param[YUV_Planar_ptr] in structure in YUV444 color space
* @param[RGB_Packed_Ptr] out structure in RGB888 color space
* @return VIPRET_OK,....
*/
VIPRESULT vipCodec_RAW::conv_PlanarYUVtoPixelRGB(unsigned char* YUV_Planar_ptr, unsigned char* RGB_Packed_Ptr, unsigned int width, unsigned int height)
{
 // microsoft formula

 unsigned char* rgb = RGB_Packed_Ptr;
 unsigned char* y = YUV_Planar_ptr;
 unsigned char* u = YUV_Planar_ptr+width*height;
 unsigned char* v = YUV_Planar_ptr+width*height*2;
 double r,g,b;

 for (unsigned int i=0; i < width*height*3; i+=3, y++, u++, v++)
 {
  r = (double)( (298*(*y-16)                + 409*(*v-128) + 128) >> 8);
  g = (double)( (298*(*y-16) - 100*(*u-128) - 208*(*v-128) + 128) >> 8);
  b = (double)( (298*(*y-16) + 516*(*u-128)                + 128) >> 8);


  //clipping of the value in the range 0-255

  if(r<0)r=0;
  if(r>255)r=255;
  if(g<0)g=0;
  if(g>255)g=255;
  if(b<0) b=0;
  if(b>255) b=255;

  rgb[i] = (unsigned char)r;
  rgb[i+1] = (unsigned char)g;
  rgb[i+2] = (unsigned char)b;
 }


 return VIPRET_OK;

}


/**
* @brief  Make the color space conversion
*
* @param[RGB_Packed_Ptr] in structure in RGB888 color space
* @param[YUV_Planar_ptr] out structure in YUV444 color space
* @
* @return VIPRET_OK,....
*/
VIPRESULT vipCodec_RAW::conv_PixelRGBtoPlanarYUV(unsigned char* RGB_Packet_ptr, unsigned char* YUV_Planar_ptr, unsigned int width, unsigned int height)
{
 // microsoft formula

 unsigned char* rgb = RGB_Packet_ptr;
 unsigned char* y = YUV_Planar_ptr;
 unsigned char* u = YUV_Planar_ptr+width*height;
 unsigned char* v = YUV_Planar_ptr+width*height*2;
 double Y,U,V;

 for (unsigned int i=0; i < width*height*3; i+=3, y++, u++, v++)
 {
  Y = (double)( ( ( 66*rgb[i] + 129*rgb[i+1] + 25*rgb[i+2] + 128 ) >> 8) + 16  );
  U = (double)( ( ( -38*rgb[i] - 74*rgb[i+1] + 112*rgb[i+2] + 128 ) >> 8) + 128 );
  V = (double)( ( ( 112*rgb[i] - 94*rgb[i+1] - 18*rgb[i+2] + 128 ) >> 8) + 128 );

  //printf("RGB %d %d %d",(int)rgb[i],(int)rgb[i+1],(int)rgb[i+2]);getchar();
  //clipping of the value in the range 0-255
  if(Y<0)	 Y=0;
  if(Y>255)Y=255;
  if(U<0)U=0;
  if(U>255)U=255;
  if(V<0)V=0;
  if(V>255)V=255;


  *y = (unsigned char)Y;
  *u = (unsigned char)U;
  *v = (unsigned char)V;
 }
 return VIPRET_OK;

}





/**
* @brief  Make the color space conversion
*
* @param[RGB_Packed_Ptr] in structure in RGB888 color space
* @param[HSV_Packet_ptr] out structure in HSVpacket color space
* @
* @return VIPRET_OK,....
*/
VIPRESULT vipCodec_RAW::conv_PixelRGBtoPixelHSV(unsigned char* RGB_Packet_ptr, float* HSV_Packet_ptr, unsigned int width, unsigned int height)
{
 int* rgb=new int[3];
 int tmp;
 double temp=0;
 float S_min = 0;   //need to calculate the saturation range inthe frame
 float S_max = 0;
 float H,S,V;

 double R,G,B;
 double min, max, delta;

 for(int i = 0; i < width * height * 3; i+=3)
 {


  rgb[0] = (int)RGB_Packet_ptr[i];     //red
  rgb[1] = (int)RGB_Packet_ptr[i+1];	 //green
  rgb[2] = (int)RGB_Packet_ptr[i+2];//blue

  R = rgb[0];
  G = rgb[1];
  B = rgb[2];

  //calculation of min & max in rgb
  for(int j = 0; j < 2; j++)

   if(rgb[j] >= rgb[j+1])
   {
	tmp = rgb[j];
	rgb[j] = rgb[j+1];
	rgb[j+1] = tmp;
   }

   max = (double)rgb[2];

   if(rgb[0] >= rgb[1])

	min = (double)rgb[1];

   else
	min = (double)rgb[0];

   V = max;
   delta = max - min;

   // Calculate saturation: saturation is 0 if r, g and b are all 0
   if (V == 0.0)

	S = 0.0;

   else
	S = delta / V;

   if (S==0.0)
	H = 0.0;    // should be Achromatic: When s = 0, h is undefined but..
   else       // Chromatic
	if (R == V)  // between yellow and magenta [degrees]

	 H=60.0*(G-B)/delta;

	else

	 if (G == V)  // between cyan and yellow

	  H = 120.0+60.0*(B-R)/delta;

	 else // between magenta and cyan

	  H = 240.0+60.0*(R-G)/delta;

	 //if ((int)H < 0) H = H+360.0;
	 if((int)H<0) H +=360.0;
	 if((int)H>=360) H-=360.0;

	 HSV_Packet_ptr[i] = H;
	 HSV_Packet_ptr[i+1] = S;
	 HSV_Packet_ptr[i+2] = V/255;


	 if(S < S_min) S_min = S;
	 if(S > S_max) S_max = S;
	 temp+=S;  //to compute average S in the frame, used as threshold for shadow&highlight detection

 }
 range_S = S_max - S_min;
 average_S = temp/(width*height);


 return VIPRET_OK;
}



/**
* @brief  Make the color space conversion
*
* @param[YUV_Planar_ptr] in structure in HSVpacket color space
* @param[RGB_Packed_Ptr] out structure in RGB888 color space
* @return VIPRET_OK,....
*/
VIPRESULT vipCodec_RAW::conv_PixelHSVtoPixelRGB(float* HSV_Pixel_ptr, unsigned char* RGB_Packet_ptr, unsigned int width, unsigned int height)
{

 unsigned char* rgb = RGB_Packet_ptr;
 int j;
 float f, p, q, t,R,G,B;
 float H,S,V;

 for(int i = 0; i < (width*height*3); i+=3)
 {
  H = HSV_Pixel_ptr[i];
  S = HSV_Pixel_ptr[i+1];
  V = HSV_Pixel_ptr[i+2];

  //printf("%d ",i);getchar();

  if( S == 0 ) {
   // achromatic (grey)
   R =  V;
   G =  V;
   B =  V;
   //printf("HSV %f %f %f, RGB %d %d %d",H,S,V,(int)RGB_Packed_ptr[i],(int)RGB_Packed_ptr[i+1],(int)RGB_Packed_ptr[i+2]);getchar();
   //printf("achromatic\n");

   goto label;
  }

  H /= 60;			// sector 0 to 5
  j = floor( H );
  f = H - j;			// factorial part of h
  p = V * ( 1 - S );
  q = V * ( 1 - S * f );
  t = V * ( 1 - S * ( 1 - f ) );

  switch( j ) {
  case 0:
   R = V;
   G = t;
   B = p;
   //printf("case1\n");
   break;

  case 1:
   R = q;
   G = V;
   B = p;
   //printf("case2\n");
   break;

  case 2:
   R = p;
   G = V;
   B = t;
   //printf("case3\n");
   break;

  case 3:
   R = p;
   G = q;
   B = V;
   //printf("case4\n");
   break;

  case 4:
   R = t;
   G = p;
   B = V;
   //printf("case5\n");
   break;

  default:		// case 5:
   R = V;
   G = p;
   B = q;
   //printf("case6\n");


  }
  //printf("%d %d",width, height);
  //printf("HSV %f %f %f ", H*60,S,V);
  //printf("RGB %f %f %f" , R*255, G*255, B*255);getchar();
label:
  rgb[i]= (unsigned char)(R*255);
  rgb[i+1]= (unsigned char)(G*255);
  rgb[i+2]= (unsigned char)(B*255);
  //printf("RGB %d %d %d" , (int)rgb[i], (int)rgb[i+1], (int)rgb[i+2]);getchar();


 }

 return VIPRET_OK;
}


/**
* @brief  Make the color space conversion
*
* @param[YUV_Planar_ptr] in structure in YUV444 color space
* @param[HSV_Packet_Ptr] out structure in HSV color space
* @return VIPRET_OK,....
*/
VIPRESULT vipCodec_RAW::conv_PlanarYUVtoPixelHSV(unsigned char* YUV_Planar_ptr, float* HSV_Packet_ptr, unsigned int width, unsigned int height)
{
 unsigned char* y = YUV_Planar_ptr;
 unsigned char* u = YUV_Planar_ptr+width*height;
 unsigned char* v = YUV_Planar_ptr+width*height*2;

 int* rgb = new int[3];
 float min, max, delta;
 double R,G,B;
 float H,S,V;

 int tmp;
 float temp=0;
 float S_min = 0;   //need to calculate the saturation range in the frame
 float S_max = 0;

 //calculation of RGB values from YUV
 for (unsigned int i=0; i < width*height*3; i+=3, y++, u++, v++)
 {
  R = (double)( (298*(*y-16)                + 409*(*v-128) + 128) >> 8);
  G = (double)( (298*(*y-16) - 100*(*u-128) - 208*(*v-128) + 128) >> 8);
  B = (double)( (298*(*y-16) + 516*(*u-128)                + 128) >> 8);


  //clipping of the value in the range 0-255

  if(R<0)R=0;
  if(R>255)R=255;
  if(G<0)G=0;
  if(G>255)G=255;
  if(B<0) B=0;
  if(B>255) B=255;

  rgb[0] = (int)R;
  rgb[1] = (int)G;
  rgb[2] = (int)B;


  //calculation from RGB to HSV

  //calculation of min & max in rgb
  for(int j = 0; j < 2; j++)

   if(rgb[j] >= rgb[j+1])
   {
	tmp = rgb[j];
	rgb[j] = rgb[j+1];
	rgb[j+1] = tmp;
   }

   max = (double)rgb[2];

   if(rgb[0] >= rgb[1])

	min = (double)rgb[1];

   else
	min = (double)rgb[0];

   V = max;
   delta = max - min;

   // Calculate saturation: saturation is 0 if r, g and b are all 0
   if (V == 0.0)

	S = 0.0;

   else
	S = delta / V;

   if (S==0.0)
	H = 0.0;    // should be Achromatic: When s = 0, h is undefined but..
   else       // Chromatic
	if (R == V)  // between yellow and magenta [degrees]

	 H=60.0*(G-B)/delta;

	else

	 if (G == V)  // between cyan and yellow

	  H = 120.0+60.0*(B-R)/delta;

	 else // between magenta and cyan

	  H = 240.0+60.0*(R-G)/delta;

   if((int)H<0) H +=360.0;
   if((int)H>=360) H-=360.0;

   //memorize value in out buffer..
   HSV_Packet_ptr[i] = H;
   HSV_Packet_ptr[i+1] = S;
   HSV_Packet_ptr[i+2] = V/255;

   //computing average value and variation range for the saturation..
   //used as threshold for shadow&highlight detection

   if(S < S_min) S_min = S;
   if(S > S_max) S_max = S;
   temp+=S;

 }

 range_S = S_max - S_min;
 average_S = temp / (width*height);


 return VIPRET_OK;
}










