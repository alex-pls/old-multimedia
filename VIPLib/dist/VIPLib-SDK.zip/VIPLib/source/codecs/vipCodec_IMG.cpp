/** @file vipCodec_IMG.cpp
 *
 * File containing methods for the 'vipCodec_IMG' class.
 * The header for this class can be found in vipCodec_IMG.h, check
 * that file for class description.
 *
 *
 ****************************************************************************
 * VIPLib Framework 1.1
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib/
 *
 ****************************************************************************/





#include "vipCodec_IMG.h"


#include <string.h>	// memcpy
#include <stdlib.h> // itoa()


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


#include <sys/types.h>


#include <magick/api.h>


void* vipCodec_IMG::im_load(char *filename, unsigned int &w, unsigned int &h, char* prog_path)
 {
	Image *image ;
	ExceptionInfo exception;

	ImageInfo *image_info;

	/*
	Initialize the image info structure and read an image.
	*/
	InitializeMagick(prog_path); // Should really pass argv[0] (only req'd under windows)
	GetExceptionInfo(&exception);
	image_info=CloneImageInfo((ImageInfo *) NULL);

	sprintf(image_info->filename,"%s", filename);
	image=ReadImage(image_info,&exception);

	if (image == (Image *) NULL)
		return NULL ;

	w = image->columns ;
	h = image->rows ;

//printf("%d\n", w);
//printf("%d\n", h);

	// Tidy up
	DestroyImageInfo(image_info);
	DestroyExceptionInfo(&exception);

	return (void*)image ;
 }

void vipCodec_IMG::im_get_data(void *img, int *rgb)
{
    unsigned int cnt ;
    PixelPacket *pp ;
    int *optr ;
    PixelPacket *iptr ;
    unsigned int sz ;
    Image *image ;

    image = (Image*)img ;

    pp =  GetImagePixels( image, 0, 0, image->columns, image->rows) ;

    sz = image->columns*image->rows ;

    for(cnt=0,iptr=pp, optr=rgb ; cnt<sz ; cnt++, iptr++){
        *(optr++) = iptr->red >> 8 ;
        *(optr++) = iptr->green >> 8 ;// should be 16
        *(optr++) = iptr->blue >> 8 ;
    }
}
void vipCodec_IMG::im_get_data(void *img, unsigned char *rgb)
{
    unsigned int cnt ;
    PixelPacket *pp ;
    unsigned char *optr ;
    PixelPacket *iptr ;
    unsigned int sz ;
    Image *image ;

    image = (Image*)img ;

    pp =  GetImagePixels( image, 0, 0, image->columns, image->rows) ;

    sz = image->columns*image->rows ;

    for(cnt=0,iptr=pp, optr=rgb ; cnt<sz ; cnt++, iptr++){
        *(optr++) = (unsigned char)( iptr->red >> 8 );
        *(optr++) = (unsigned char)( iptr->green >> 8 );
        *(optr++) = (unsigned char)( iptr->blue >> 8 );
    }
}


void vipCodec_IMG::im_get_data_grey(void *img, int *d)
{
    unsigned int cnt ;
    PixelPacket *pp ;
    int *optr ;
    PixelPacket *iptr ;
    unsigned int sz ;
    Image *image ;

    image = (Image*)img ;

    pp =  GetImagePixels( image, 0, 0, image->columns, image->rows) ;

    sz = image->columns*image->rows ;

    for(cnt=0,iptr=pp, optr=d ; cnt<sz ; cnt++, iptr++, optr++){
        *optr = iptr->red >> 8 ;
        *optr += iptr->green >> 8 ;
        *optr += iptr->blue >> 8 ;
        *optr /= 3 ;
    }
}

void vipCodec_IMG::im_free(void *img)
{
    Image *image ;

    image = (Image*)img ;

    DestroyImage(image);

}




vipCodec_IMG::vipCodec_IMG(char *filename) : vipCodec()
/**
 * Allocates an array of size taken from file for storage of red, green and
 * blue data and fills it with data taken from file.
 * Sets the parameters Width and Height to the inputs width and height.
 *
 * @param filename The name of the image file.
 * @param FileFormat The format of the image file.
 */
 {
	DEBUGMSG("vipCodec_IMG::vipCodec_IMG(char *filename, FileFormat format) [CONTRUCTOR] ", *filename)

	myParams = NULL;
	reset();
	setParameters(NULL);

 	load( filename );

	strcpy(myParams->fileNameBase, filename);
 }

vipCodec_IMG::vipCodec_IMG( vipCodec_IMGParameters* initParams ) : vipCodec()
 {
	DEBUGMSG("vipCodec_IMG::vipCodec_IMG(vipCodec_IMGParameters* initParams) [CONTRUCTOR] ", *filename)

	myParams = NULL;
	reset();
	setParameters(initParams);
 }

VIPRESULT vipCodec_IMG::reset()
 {
	INFO("VIPRESULT vipCodec_IMG::reset() [SET DEFAULT PARAMETERS]")

	setName("Bitmap Coder");
	setDescription("Read or write images to bitmap format.");
	setVersion(1.0);

	if (myParams != NULL)
	 {
		myParams->reset();
		strcpy(fileNameBuffer, myParams->fileNameBase);
	 }

	return VIPRET_OK;
 }


VIPRESULT vipCodec_IMG::setParameters (vipCodec_IMGParameters* initParams)
 {

	if ( initParams == NULL )
		myParams = new vipCodec_IMGParameters();
	else
		myParams = initParams;

	return VIPRET_OK;
 }

bool vipCodec_IMG::EoF()	// buggy
 {
	 return false;
 }


VIPRESULT vipCodec_IMG::extractTo(vipFrameYUV420& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_IMG::extractTo(vipFrameYUV420& img) [pushing data]", doBuffering)

	return VIPRET_NOT_IMPLEMENTED;

 }

VIPRESULT vipCodec_IMG::extractTo(vipFrameRGB24& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_IMG::extractTo(vipFrameRGB24& img) [pushing data]", doBuffering)

	int ret = VIPRET_OK;

	if ( myParams->autoOuput && !myParams->doBuffering )
	 {
		doFileNameCurrent();


		ret = load(img, fileNameBuffer);

		if ( myParams->fileNameProgression )
			myParams->fileNameIndex++;

		return ret;
	 }

	if ( myParams->autoInput )
	 {
		doFileNameCurrent();

		ret = load(fileNameBuffer);

		if ( myParams->fileNameProgression )
			myParams->fileNameIndex++;
	 }


//	vipFrameRGB::operator >> (img);

	return ret;
 }


VIPRESULT vipCodec_IMG::extractTo(vipFrameT<unsigned char>& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_IMG::extractTo(vipFrameT& img) [pushing data]", doBuffering)

	return VIPRET_NOT_IMPLEMENTED;

 }



VIPRESULT vipCodec_IMG::importFrom(vipFrameYUV420& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_IMG::importFrom(vipFrameYUV420& img) [reading data]", doBuffering)

	return VIPRET_NOT_IMPLEMENTED;

 }


VIPRESULT vipCodec_IMG::importFrom(vipFrameRGB24& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_IMG::importFrom(vipFrameRGB24& img) [reading data]", doBuffering)

	int ret = VIPRET_OK;

	if ( myParams->autoOuput && !myParams->doBuffering )
	 {
		doFileNameCurrent();

		ret = save(img, fileNameBuffer);

		if ( myParams->fileNameProgression )
			myParams->fileNameIndex++;

		return ret;
	 }

//	vipFrameRGB::operator << (img);

	if ( myParams->autoOuput )
	 {
		doFileNameCurrent();

		ret = save(fileNameBuffer);

		if ( myParams->fileNameProgression )
			myParams->fileNameIndex++;
	 }

	return ret;
 }

VIPRESULT vipCodec_IMG::importFrom(vipFrameT<unsigned char>& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_IMG::importFrom(vipFrameYUV420& img) [reading data]", doBuffering)

	return VIPRET_NOT_IMPLEMENTED;

 }

void vipCodec_IMG::setFileName(const char *filename)
 {
	strncpy(myParams->fileNameBase, filename, 64);
	strcpy(fileNameBuffer, myParams->fileNameBase);
 }


void vipCodec_IMG::doFileNameCurrent()
 {

	sprintf( fileNameIndexBuffer, "%d", myParams->fileNameIndex );

	strcpy( fileNameBuffer, myParams->fileNameBase );

	if ( myParams->fileNameIndex != -1 )
		strcat( fileNameBuffer, fileNameIndexBuffer );

	strcat( fileNameBuffer, (const char*)".bmp" );

	DEBUGMSG("void vipCodec_IMG::doFileNameCurrent()", fileNameBuffer);

 }


void vipCodec_IMG::getFileNameCurrent(char* filename)
 {
	doFileNameCurrent();
	strcpy( filename, fileNameBuffer );
 }



VIPRESULT vipCodec_IMG::save()
 {
	INFO("VIPRESULT vipCodec_IMG::save() [saving buffered data]")

	int ret = VIPRET_OK;


	doFileNameCurrent();
//	ret = save(tmp, fileNameBuffer);
	return VIPRET_NOT_IMPLEMENTED;

	return ret;
}

VIPRESULT vipCodec_IMG::saveImage(char *filename)
 {
	DEBUGMSG("VIPRESULT vipCodec_IMG::save(char *filename, FileFormat format) [saving buffered data]", filename)

	return VIPRET_NOT_IMPLEMENTED;

 }


VIPRESULT vipCodec_IMG::load()
 {
	INFO("VIPRESULT vipCodec_IMG::load() [loading data to buffer]")

	int ret = VIPRET_OK;

	vipFrameYUV420 tmp;
	tmp.autoFreeData = false;// tmp used as a struct..

	doFileNameCurrent();
	ret = load(tmp, fileNameBuffer);



	return ret;
}


VIPRESULT vipCodec_IMG::loadImage(char *filename)
 {
	DEBUGMSG("VIPRESULT vipCodec_IMG::load(char *filename, FileFormat format) [loading data to buffer]", filename)

	int ret = VIPRET_OK;
	vipFrameYUV420 tmp;
	tmp.autoFreeData = false;// tmp used as a struct.. UMH=????????=??????????????????????

	ret = load(tmp, filename);


	return ret;
 }



//STATIC


VIPRESULT vipCodec_IMG::load(vipFrameYUV420& source, const char *filename)
 {
	DEBUGMSG("VIPRESULT vipCodec_IMG::load(vipFrameYUV420& source, char *filename, ..) [loading file data to frame]", filename)

	return VIPRET_NOT_IMPLEMENTED;

 }

VIPRESULT vipCodec_IMG::load(vipFrameRGB24& source, const char *filename)
 {
	DEBUGMSG("VIPRESULT vipCodec_IMG::load(vipFrameRGB24& source, char *filename, ..) [loading file data to frame]", filename)

	int ret = VIPRET_OK;
	void* img = NULL;
	bool ok;

	unsigned int w, h;

    if ( (img=im_load((char *)filename, w, h, NULL) ) == NULL )

    	ok = false ;

    else
	 {
		if ( w*h == 0 )

			return VIPRET_PARAM_ERR;

		else if (w*h != source.width*source.height)
		 {
			if (source.data != NULL)
				delete source.data;
			source.data = new PixelRGB24[w*h];
		 }
		source.width = w;
		source.height = h;
	    im_get_data(img, (unsigned char*)source.data[0]) ;
	 }

	return ret;
 }



VIPRESULT vipCodec_IMG::load(vipFrameT<unsigned char>& source, const char *filename)
 {
	DEBUGMSG("VIPRESULT vipCodec_IMG::load(vipFrameT& source, char *filename, ..) [loading file data to frame]", filename)

	if ( source.getWidth() != 0 || source.getHeight() != 0 )
		return VIPRET_PARAM_ERR;

	int ret = VIPRET_OK;


	return VIPRET_NOT_IMPLEMENTED;
 }


VIPRESULT vipCodec_IMG::save(vipFrameYUV420& source, const char *filename)
 {
	DEBUGMSG("VIPRESULT vipCodec_IMG::save(vipFrameYUV420& source, char *filename, FileFormat format) [saving frame to file]", filename)
/*
	if ( source.width == 0 || source.height == 0 || source.data == NULL )
		return VIPRET_PARAM_ERR;

	int ret = VIPRET_OK;


	ImageInfo *image_info;
	image_info=CloneImageInfo((ImageInfo *) NULL);

	ExceptionInfo exception;

	GetExceptionInfo(&exception);


	Image* myI = ConstituteImage(source.width,source.height, "RGB", IntegerPixel, source.data[0], &exception);

    pp =  GetImagePixels( &myI, 0, 0, source.width,source.height) ;

    sz = source.width,source.height ;

    for(cnt=0,iptr=pp, optr=source.data[0] ; cnt<sz ; cnt++, iptr++){
        iptr->red = *(optr++);
        iptr->green = *(optr++);
        iptr->blue = *(optr++);
    }

	sprintf(image_info->filename,"%s", filename);

	WriteImage(image_info, myI);

	DestroyImageInfo(image_info);
	DestroyExceptionInfo(&exception);
	return ret;
*/

	return VIPRET_NOT_IMPLEMENTED;

}

VIPRESULT vipCodec_IMG::save(vipFrameRGB24& source, const char *filename)
 {
	DEBUGMSG("VIPRESULT vipCodec_IMG::save(vipFrameRGB24& source, char *filename, FileFormat format) [saving frame to file]", filename)

	if ( source.getWidth() == 0 || source.getHeight() == 0 )
		return VIPRET_PARAM_ERR;

	int ret = VIPRET_OK;

	ImageInfo *image_info;
	image_info=CloneImageInfo((ImageInfo *) NULL);

	ExceptionInfo exception;

	GetExceptionInfo(&exception);


	Image* myI = ConstituteImage(source.width,source.height, "RGB", CharPixel, source.data[0], &exception);
/*
    pp =  GetImagePixels( &myI, 0, 0, source.width,source.height) ;

    sz = source.width,source.height ;

    for(cnt=0,iptr=pp, optr=source.data[0] ; cnt<sz ; cnt++, iptr++){
        iptr->red = *(optr++);
        iptr->green = *(optr++);
        iptr->blue = *(optr++);
    }
*/
	sprintf(image_info->filename,"%s", filename);

	WriteImage(image_info, myI);

	DestroyImageInfo(image_info);
	DestroyExceptionInfo(&exception);

	return ret;
}


VIPRESULT vipCodec_IMG::save(vipFrameT<unsigned char>& source, const char *filename)
 {
	DEBUGMSG("VIPRESULT vipCodec_IMG::save(vipFrameT& source, char *filename, FileFormat format) [saving frame to file]", filename)

	return VIPRET_NOT_IMPLEMENTED;

 }



/**
 * @brief	Enable or disable filename progression, for example:
 *          basefile name is "output", index is 13 so filename is output13.bmp,
 *			if filename progression is enabled, when an operation is done
 *          onto file, idex is incremented (output14.bmp).
 *
 * @param[in] value true to enable file name progression.
 */
void vipCodec_IMG::setFileNameProgression(bool value) { myParams->fileNameProgression = value; }

/**
 * @brief   Enable or disable auto input feature,
 *
 *
 * @param[in]
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note
 * @see
 */
void vipCodec_IMG::setAutoOutputEnabled(bool value) { myParams->autoOuput = value; }

/**
 * @brief
 *
 *
 * @param[in]
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note
 * @see
 */
void vipCodec_IMG::setAutoInputEnabled(bool value) { myParams->autoInput = value; }

/**
 * @brief
 *
 *
 * @param[in]
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note
 * @see
 */
void vipCodec_IMG::setDoBuffering(bool value) { myParams->doBuffering = value; }


/**
 * @brief  Read current file name index, used in file name progression
 *         routines.
 *
 * @return VIPRET_OK if everything is fine,
 *		   VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note
 * @see
 */
int vipCodec_IMG::getFileNameIndex() { return myParams->fileNameIndex; }
/**
 * @brief
 *
 *
 * @return true if filename progression is enabled.
 *
 * @see   fileNameProgression
 */
bool vipCodec_IMG::isFileNameProgressionEnabled() { return myParams->fileNameProgression; }

/**
 * @brief
 *

 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note
 * @see
 */
bool vipCodec_IMG::isAutoInputEnabled() { return myParams->autoInput; }

/**
 * @brief
 *
 *
 * @param[in]
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note
 * @see
 */
bool vipCodec_IMG::isAutoOutputEnabled() { return myParams->autoOuput; }

/**
 * @brief
 *
 *
 * @param[in]
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note
 * @see
 */

bool vipCodec_IMG::isBufferingEnabled() { return myParams->doBuffering; }

/**
 * @brief Read current bitmap encoding/decoding format.
 *
 * @return Current I/O BMP format.
 *
 * @see   FileFormat
 * @see   fileFormat
 */







vipCodec_IMGParameters::vipCodec_IMGParameters()
 {
	reset();
 }

vipCodec_IMGParameters::vipCodec_IMGParameters(char* filename)
 {
	reset();
	setFileName(filename);
}

void vipCodec_IMGParameters::reset()
 {
	strcpy(fileNameBase, (const char*)"OUTPUT_1\0");
	setDoBuffering(true);
	setFileNameProgression(true);
	setFileNameIndex(-1);
	setAutoInputEnabled(false);
	setAutoOutputEnabled(true);
 }



void vipCodec_IMGParameters::setFileName(const char *filename)
 {
	strncpy(fileNameBase, filename, 64);
 }


void vipCodec_IMGParameters::getFileName(char *filename)
 {
	strcpy(filename, fileNameBase);
 }


int vipCodec_IMGParameters::saveToStreamXML(FILE *fp)
 {
	if ( fp == NULL )
		return VIPRET_PARAM_ERR;

	if( fprintf(fp, "<vipCodec_IMGParameters>\n") == EOF )
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <filename value=\"%s\" />\n", fileNameBase) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <fileNameIndex value=\"%i\" />\n", fileNameIndex) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <doBuffering value=\"%u\" />\n", (int)doBuffering) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <autoOuput value=\"%u\" />\n", (int)autoOuput) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <autoInput value=\"%u\" />\n", (int)autoInput) == EOF)
		return VIPRET_INTERNAL_ERR;

	if( fprintf(fp, "</vipCodec_IMGParameters>\n") == EOF )
		return VIPRET_INTERNAL_ERR;

	return VIPRET_OK;
 }


int vipCodec_IMGParameters::loadFromStreamXML(FILE *fp)
 {
	if ( fscanf(fp, "<vipCodec_IMGParameters>\n") == EOF )
		throw "error in XML file, unable to import data.";

	if ( fscanf(fp, "  <filename value=\"%s\" />\n", fileNameBase) == EOF )
		throw "error in XML file, unable to import data.";

	if ( fscanf(fp, "  <fileNameIndex value=\"%i\" />\n", &fileNameIndex) == EOF )
		throw "error in XML file, unable to import data.";

	int boolTmp = 1;
	if ( fscanf(fp, "  <doBuffering value=\"%u\" />\n", &boolTmp) == EOF )
		throw "error in XML file, unable to import data.";

	if (boolTmp == 0)
		doBuffering = false;
	else
		doBuffering = true;

	boolTmp = 0;
	if ( fscanf(fp, "  <autoOuput value=\"%u\" />\n", &boolTmp) == EOF )
		throw "error in XML file, unable to import data.";

	if (boolTmp == 0)
		autoOuput = false;
	else
		autoOuput = true;

	boolTmp = 0;
	if ( fscanf(fp, "  <autoInput value=\"%u\" />\n", &boolTmp) == EOF )
		throw "error in XML file, unable to import data.";

	if (boolTmp == 0)
		autoInput = false;
	else
		autoInput = true;

	return VIPRET_OK;
 }




