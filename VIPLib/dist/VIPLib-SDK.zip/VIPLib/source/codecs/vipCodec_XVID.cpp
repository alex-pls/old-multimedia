/** @file vipCodec_XVID.cpp
 *
 * File containing methods for the 'vipCodec_XVID' class.
 * The header for this class can be found in vipCodec_XVID.h, check
 * that file for class description.
 *
 *
 ****************************************************************************
 * VIPLib Framework 1.1
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib/
 *
 ****************************************************************************/





#include "vipCodec_XVID.h"
#include "../vipUtility.h"	//getTime_usec()



vipCodec_XVID::vipCodec_XVID(char *filename, int stream) : vipCodec()
/**
 * Allocates an array of size taken from file for storage of red, green and
 * blue data and fills it with data taken from file.
 * Sets the parameters Width and Height to the inputs width and height.
 *
 * @param filename The name of the image file.
 * @param FileFormat The format of the image file.
 */
 {
	DEBUGMSG("vipCodec_XVID::vipCodec_XVID(char *filename, FileFormat format) [CONTRUCTOR] ", *filename)

	stream_handle = NULL;
	mp4_buffer = NULL;
	buffer = NULL;

	setParameters(NULL);
	reset();

	init();

 	load( filename, stream );

 }

vipCodec_XVID::vipCodec_XVID( vipCodec_XVIDParameters* initParams ) : vipCodec()
 {
	DEBUGMSG("vipCodec_XVID::vipCodec_XVID(vipCodec_XVIDParameters* initParams) [CONTRUCTOR] ", *filename)

	stream_handle = NULL;
	mp4_buffer = NULL;
	buffer = NULL;

	setParameters(initParams);
	reset();

	init();
 }

VIPRESULT vipCodec_XVID::reset()
 {
	INFO("VIPRESULT vipCodec_XVID::reset() [SET DEFAULT PARAMETERS]")

	setName("XVID Coder");
	setDescription("Read or write video stream.");
	setVersion(1.0);

	use_assembler = 0;
	debug_level = 0;
	mp4_ptr = NULL;

	height = 0;
	width = 0;

	totaldectime = 0;
	totalsize = 0;
	filenr = 0;

	chunk = 0;
	if (myParams != NULL)
		myParams->reset();

//BUG 	flush(); ?
	if (stream_handle != NULL)
		close();

	if (mp4_buffer != NULL || buffer != NULL)
		release();

	mp4_buffer = NULL;
	buffer = NULL;

	return VIPRET_OK;
 }


VIPRESULT vipCodec_XVID::setParameters (vipCodec_XVIDParameters* initParams)
 {

	if ( initParams == NULL )
		myParams = new vipCodec_XVIDParameters();
	else
		myParams = initParams;

	return VIPRET_OK;
 }

vipCodec_XVID::~vipCodec_XVID()
 {
//BUG 	flush(); ?

	if (stream_handle != NULL)
		close();

	if (buffer != NULL)
 		release();
 }

bool vipCodec_XVID::EoF()	// buggy
 {
	if (stream_handle == NULL)
		return true;


	return false;
 }



VIPRESULT vipCodec_XVID::extractTo(vipFrameYUV420& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_XVID::extractTo(vipFrameYUV420& img) [pushing data]", doBuffering)

	if (stream_handle == NULL)
		return VIPRET_ILLEGAL_USE;

	return VIPRET_NOT_IMPLEMENTED;

 }

VIPRESULT vipCodec_XVID::extractTo(vipFrameRGB24& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_XVID::extractTo(vipFrameRGB24& img) [pushing data]", doBuffering)

	if (stream_handle == NULL)
		return VIPRET_ILLEGAL_USE;

	if (width != img.width || height != img.height)
		img.reAllocCanvas(width, height);

	int ret = doDecodeFrame();

	vipUtility::conv_bgr_rgb((unsigned char*)img.data[0], buffer, width, height);


	/* Save output frame TEMPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP*/
//		sprintf(myParams->fileName, "dec%05d", filenr);
//		write_image(myParams->fileName, buffer);

/*	unsigned char* cpy_ptr = buffer;
	unsigned int i;
	for(i=0; i<img.width*img.height; i++)
	 {
		img.data[0][0] = *(cpy_ptr++);
		img.data[0][1] = *(cpy_ptr++);
		img.data[0][2] = *(cpy_ptr++);
	 }
*/

//	memcpy( (unsigned char*)img.data[0], buffer, img.width*img.height*3*sizeof(char) );





	return ret;


 }


VIPRESULT vipCodec_XVID::extractTo(vipFrameT<unsigned char>& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_XVID::extractTo(vipFrameT& img) [pushing data]", doBuffering)

	if (stream_handle == NULL)
		return VIPRET_ILLEGAL_USE;

	int ret = VIPRET_OK;

	if ( img.profile == vipFrame::VIPFRAME_BGR24 )
	 {
		if (width != img.width || height != img.height)
			img.reAllocCanvas(width, height);

		ret = doDecodeFrame();

		memcpy( (unsigned char*)img.data[0], buffer, width * height * 3 );

		return ret;
	 }

	return VIPRET_NOT_IMPLEMENTED;

 }



VIPRESULT vipCodec_XVID::importFrom(vipFrameYUV420& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_XVID::importFrom(vipFrameYUV420& img) [reading data]", doBuffering)

	return VIPRET_NOT_IMPLEMENTED;

 }


VIPRESULT vipCodec_XVID::importFrom(vipFrameRGB24& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_XVID::importFrom(vipFrameRGB24& img) [reading data]", doBuffering)

	return VIPRET_NOT_IMPLEMENTED;

 }


VIPRESULT vipCodec_XVID::importFrom(vipFrameT<unsigned char>& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_XVID::importFrom(vipFrameT<unsigned char>& img) [reading data]", doBuffering)

	return VIPRET_NOT_IMPLEMENTED;

 }



VIPRESULT vipCodec_XVID::save(char *filename, int stream)
 {
	INFO("VIPRESULT vipCodec_XVID::save() [saving buffered data]")

	return VIPRET_NOT_IMPLEMENTED;
}

VIPRESULT vipCodec_XVID::save()
 {
	INFO("VIPRESULT vipCodec_XVID::save() [saving buffered data]")

	return VIPRET_NOT_IMPLEMENTED;
}


VIPRESULT vipCodec_XVID::load(char *filename, int stream)
 {
	DEBUGMSG("VIPRESULT vipCodec_XVID::load(char *filename, FileFormat format) [loading data to buffer]", filename)

 	myParams->setFileName(filename);
 	myParams->setStream(stream);

	return load();
 }






VIPRESULT vipCodec_XVID::init()
 {
	INFO("VIPRESULT vipCodec_XVID::init() [INITIALIZING MEMORY]")

	/* Memory for encoded mp4 stream */
	mp4_buffer = (unsigned char *) malloc(BUFFER_SIZE);
	mp4_ptr = mp4_buffer;

	if (!mp4_buffer)
	 {
		free(mp4_buffer);
		return VIPRET_INTERNAL_ERR;
	 }

	if ( dec_init(use_assembler, debug_level) )
	 {
//BUG return check!
		close();
		return VIPRET_INTERNAL_ERR;
 	 }

	return VIPRET_OK;
 }










VIPRESULT vipCodec_XVID::close()
 {
	INFO("VIPRESULT vipCodec_XVID::close() [DESTROYING HANDLE]")

	int ret;
	ret = xvid_decore(stream_handle, XVID_DEC_DESTROY, NULL, NULL);
	return ret; //BUG
 }










VIPRESULT vipCodec_XVID::release()
 {
	INFO("VIPRESULT vipCodec_XVID::release() [RELEASING MEMORY]")

	free(buffer);
	free(mp4_buffer);
	return VIPRET_OK;
 }

VIPRESULT vipCodec_XVID::updateBuffer(unsigned int width, unsigned int height)
 {
	INFO("VIPRESULT vipCodec_XVID::release() [RELEASING MEMORY]")
	//					fprintf(stderr, "Resized frame buffer to %dx%d\n", width, height);

	/* Free old output buffer*/
	if ( buffer )
		free(buffer);

	/* Allocate the new buffer */
	buffer = (unsigned char*)malloc( width * height * 4);
	if ( buffer == NULL )
	 {
		release();
		return VIPRET_INTERNAL_ERR;
	 }

	return VIPRET_OK;
 }

















VIPRESULT vipCodec_XVID::load()
 {
	INFO("VIPRESULT vipCodec_XVID::load() [loading data to buffer]")

	file = fopen(myParams->fileName, "rb");

	if (file == NULL)
		return VIPRET_PARAM_ERR;



	INFO("VIPRESULT vipCodec_XVID::dodecode()")

	if ( file == NULL)
		return VIPRET_ILLEGAL_USE;

	/* Fill the buffer */
	useful_bytes = fread(mp4_buffer, 1, BUFFER_SIZE, file);

	totaldectime = 0;
	totalsize = 0;
	filenr = 0;
	mp4_ptr = mp4_buffer;

	chunk = 0;

	int ret = doDecodeFrame();

	return VIPRET_OK;
}



VIPRESULT vipCodec_XVID::doDecodeFrame()
 {
	int used_bytes = 0;
	double dectime;

	/*
	 * If the buffer is half empty or there are no more bytes in it then fill it.
	 */
	if (mp4_ptr > mp4_buffer + BUFFER_SIZE/2)
	 {
		int already_in_buffer = (mp4_buffer + BUFFER_SIZE - mp4_ptr);

		/* Move data if needed */
		if (already_in_buffer > 0)
			memcpy(mp4_buffer, mp4_ptr, already_in_buffer);

		/* Update mp4_ptr */
		mp4_ptr = mp4_buffer;

		/* read new data */
		if( feof(file) )
		 {
			flush();
			return VIPRET_INTERNAL_ERR;
		 }

		useful_bytes += fread(mp4_buffer + already_in_buffer,
							  1, BUFFER_SIZE - already_in_buffer,
							  file);

	}


	/* This loop is needed to handle VOL/NVOP reading */
	do
	 {

		/* Decode frame */
		dectime =vipUtility::getTime_usec();
		used_bytes = dec_main(mp4_ptr, buffer, useful_bytes, &xvid_dec_stats);
		dectime = vipUtility::getTime_usec() - dectime;




		/* Resize image buffer if needed */
		if(xvid_dec_stats.type == XVID_TYPE_VOL) {

			/* Check if old buffer is smaller */
			if(width*height < xvid_dec_stats.data.vol.width*xvid_dec_stats.data.vol.height) {

				/* Copy new witdh and new height from the vol structure */
				width = xvid_dec_stats.data.vol.width;
				height = xvid_dec_stats.data.vol.height;

				if ( updateBuffer(width, height) )
					return VIPRET_INTERNAL_ERR;

			}

		}

		/* Update buffer pointers */
		if(used_bytes > 0) {
			mp4_ptr += used_bytes;
			useful_bytes -= used_bytes;

			/* Total size */
			totalsize += used_bytes;
		}

		DEBUGMSG("Data chunk", chunk)
		DEBUGMSG("bytes consumed", used_bytes)
		DEBUGMSG("bytes in buffer", useful_bytes)
		++chunk;


	} while (xvid_dec_stats.type <= 0 && useful_bytes > 0);

	/* Check if there is a negative number of useful bytes left in buffer
	 * This means we went too far */
	if(useful_bytes < 0)
	 {
		flush();
		return VIPRET_INTERNAL_ERR;
	 }

	/* Updated data - Count only usefull decode time */
	totaldectime += dectime;


	DEBUGMSG("Frame", filenr)
	DEBUGMSG("type", type2str(xvid_dec_stats.type) )
	DEBUGMSG("dectime(ms) =", dectime)
	DEBUGMSG("length(bytes)", used_bytes)
	//		printf("Frame %5d: type = %s, dectime(ms) =%6.1f, length(bytes) =%7d\n", filenr, type2str(xvid_dec_stats.type), dectime, used_bytes);


	filenr++;

	return VIPRET_OK;
 }


VIPRESULT vipCodec_XVID::flush()
 {
	useful_bytes = 0; /* Empty buffer */

/*****************************************************************************
 *     Flush decoder buffers
 ****************************************************************************/

	do {

		/* Fake vars */
		int used_bytes;
		double dectime;

        do {
		    dectime = vipUtility::getTime_usec();
		    used_bytes = dec_main(NULL, buffer, -1, &xvid_dec_stats);
		    dectime = vipUtility::getTime_usec() - dectime;

			DEBUGMSG("Data chunk", chunk)
			DEBUGMSG("bytes consumed", used_bytes)
			DEBUGMSG("bytes in buffer", useful_bytes)
			++chunk;

        } while(used_bytes>=0 && xvid_dec_stats.type <= 0);

        if (used_bytes < 0) {   /* XVID_ERR_END */
            break;
        }

		/* Updated data - Count only usefull decode time */
		totaldectime += dectime;

		/* Prints some decoding stats */
		DEBUGMSG("Frame", filenr)
		DEBUGMSG("type", type2str(xvid_dec_stats.type) )
		DEBUGMSG("dectime(ms) =", dectime)
		DEBUGMSG("length(bytes)", used_bytes)
//		printf("Frame %5d: type = %s, dectime(ms) =%6.1f, length(bytes) =%7d\n", filenr, type2str(xvid_dec_stats.type), dectime, used_bytes);

		/* Save output frame if required */
/*
		if (ARG_SAVEDECOUTPUT) {
			sprintf(filename, "%sdec%05d", filepath, filenr);
			if(write_image(filename, out_buffer)) {
				fprintf(stderr,
						"Error writing decoded frame %s\n",
						filename);
			}
		}
*/
		filenr++;

	}while(1);







/*****************************************************************************
 *     Calculate totals and averages for output, print results
 ****************************************************************************/

	if (filenr>0) {
		totalsize    /= filenr;
		totaldectime /= filenr;
//		printf("Avg: dectime(ms) =%7.2f, fps =%7.2f, length(bytes) =%7d\n",
//			   totaldectime, 1000/totaldectime, (int)totalsize);
	}
	//else{
//		printf("Nothing was decoded!\n");
//	}

	return VIPRET_OK;
 }






VIPRESULT vipCodec_XVID::doDecode(long frameCount)
 {
	bool temp;
	do
	 {
		if ( doDecodeFrame() )
			temp = false;

		filenr++;

		if (frameCount && filenr > frameCount)
			temp = false;

	} while ( ( useful_bytes>0 || !feof(file) ) && temp);

	return flush();
 }







const char * type2str(int type)
{
    if (type==XVID_TYPE_IVOP)
        return "I";
    if (type==XVID_TYPE_PVOP)
        return "P";
    if (type==XVID_TYPE_BVOP)
        return "B";
    return "S";
}




















//////////////////////////////////////////////////////////////////////////////////
// XVID DIRECT FUNCTIONS

/* init decoder before first run */

VIPRESULT vipCodec_XVID::dec_init(int use_assembler, int debug_level)
 {
	INFO("VIPRESULT vipCodec_XVID::dec_init(int use_assembler, int debug_level) [INITIALIZING MEMORY]")

	int ret;

	xvid_gbl_init_t   xvid_gbl_init;
	xvid_dec_create_t xvid_dec_create;

	/* Reset the structure with zeros */
	memset(&xvid_gbl_init, 0, sizeof(xvid_gbl_init_t));
	memset(&xvid_dec_create, 0, sizeof(xvid_dec_create_t));

	/*------------------------------------------------------------------------
	 * XviD core initialization
	 *----------------------------------------------------------------------*/

	/* Version */
	xvid_gbl_init.version = XVID_VERSION;

	/* Assembly setting */
	if(use_assembler)
#ifdef ARCH_IS_IA64
		xvid_gbl_init.cpu_flags = XVID_CPU_FORCE | XVID_CPU_IA64;
#else
	xvid_gbl_init.cpu_flags = 0;
#endif
	else
		xvid_gbl_init.cpu_flags = XVID_CPU_FORCE;

	xvid_gbl_init.debug = debug_level;

	xvid_global(NULL, 0, &xvid_gbl_init, NULL);

	/*------------------------------------------------------------------------
	 * XviD encoder initialization
	 *----------------------------------------------------------------------*/

	/* Version */
	xvid_dec_create.version = XVID_VERSION;

	/*
	 * Image dimensions -- set to 0, xvidcore will resize when ever it is
	 * needed
	 */
	xvid_dec_create.width = 0;
	xvid_dec_create.height = 0;

	ret = xvid_decore(NULL, XVID_DEC_CREATE, &xvid_dec_create, NULL);

	stream_handle = xvid_dec_create.handle;

	return(ret);
 }


static int BPP = 3;
static int CSP = XVID_CSP_BGR;//XVID_CSP_I420;


/* decode one frame  */
VIPRESULT vipCodec_XVID::dec_main(unsigned char *istream, unsigned char *ostream, int istream_size, xvid_dec_stats_t *xvid_dec_stats)
 {
	INFO("VIPRESULT vipCodec_XVID::dec_main(unsigned char *istream, unsigned char *ostream, int istream_size, xvid_dec_stats_t *xvid_dec_stats) [DECODE ONE FRAME]")
	DEBUG(istream)
	DEBUG(ostream)
	DEBUG(istream_size)

	int ret;

	xvid_dec_frame_t xvid_dec_frame;

	/* Reset all structures */
	memset(&xvid_dec_frame, 0, sizeof(xvid_dec_frame_t));
	memset(xvid_dec_stats, 0, sizeof(xvid_dec_stats_t));

	/* Set version */
	xvid_dec_frame.version = XVID_VERSION;
	xvid_dec_stats->version = XVID_VERSION;

	/* No general flags to set */
	xvid_dec_frame.general          = 0;

	/* Input stream */
	xvid_dec_frame.bitstream        = istream;
	xvid_dec_frame.length           = istream_size;

	/* Output frame structure */
	xvid_dec_frame.output.plane[0]  = ostream;
	xvid_dec_frame.output.stride[0] = width*BPP;
	xvid_dec_frame.output.csp = CSP;

	ret = xvid_decore(stream_handle, XVID_DEC_DECODE, &xvid_dec_frame, xvid_dec_stats);

//update buffer ??? why not

	return(ret);
 }






VIPRESULT vipCodec_XVID::write_pnm(char *filename, unsigned char *image)
{
	INFO("VIPRESULT vipCodec_XVID::write_pnm(char *filename, unsigned char *image)")

	FILE * f;

	f = fopen(filename, "wb");
	if ( f == NULL) {
		return -1;
	}

	if (BPP == 1) {
		unsigned int i;
		fprintf(f, "P5\n#xvid\n%i %i\n255\n", width, height*3/2);

		fwrite(image, 1, width*height, f);

		for (i=0; i<height/2;i++) {
			fwrite(image+width*height + i*width/2, 1, width/2, f);
			fwrite(image+5*width*height/4 + i*width/2, 1, width/2, f);
		}
	} else if (BPP == 3) {
		unsigned int i;
		fprintf(f, "P6\n#xvid\n%i %i\n255\n", width, height);
		for (i=0; i<width*height*3; i+=3) {
//#ifdef ARCH_IS_LITTLE_ENDIAN
//			fputc(image[i+2], f);
//			fputc(image[i+1], f);
//			fputc(image[i+0], f);
//#else
			fputc(image[i+0], f);
			fputc(image[i+1], f);
			fputc(image[i+2], f);
//#endif
		}
	}

	fclose(f);

	return 0;
}



VIPRESULT vipCodec_XVID::write_image(char *prefix, unsigned char *image)
{
	INFO("VIPRESULT vipCodec_XVID::write_image(char *prefix, unsigned char *image)")

	char filename[1024];
	char *ext;
	int ret;

	if (BPP == 1) {
		ext = "pgm";
	} else if (BPP == 3) {
		ext = "pnm";
	} else {
		fprintf(stderr, "Bug: should not reach this path code -- please report to xvid-devel@xvid.org with command line options used");
		exit(-1);
	}

	sprintf(filename, "%s.%s", prefix, ext);

	ret = write_pnm(filename, image);

	return(ret);
}























vipCodec_XVIDParameters::vipCodec_XVIDParameters()
 {
	reset();
 }

vipCodec_XVIDParameters::vipCodec_XVIDParameters(const char* filename, int stream, long frameIndex)
 {
	reset();
	setFileName(filename);
	setStream(stream);
	setFrameIndex(frameIndex);
 }

void vipCodec_XVIDParameters::reset()
 {
	strcpy(fileName, (const char*)"input.avi\0");
	frameIndex = 0;
	stream = 0;
 }


void vipCodec_XVIDParameters::setFileName(const char *filename)
 {
	strncpy(fileName, filename, 64);
 }

void vipCodec_XVIDParameters::setFrameIndex(long index)
 {
	frameIndex = index;
 }

void vipCodec_XVIDParameters::setStream(int s)
 {
	stream = s;
 }


int vipCodec_XVIDParameters::saveToStreamXML(FILE *fp)
 {
	if ( fp == NULL )
		return VIPRET_PARAM_ERR;

	if( fprintf(fp, "<vipCodec_XVIDParameters>\n") == EOF )
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <filename value=\"%s\" />\n", fileName) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <stream value=\"%d\" />\n", stream) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <frameIndex value=\"%ld\" />\n", frameIndex) == EOF)
		return VIPRET_INTERNAL_ERR;

	if( fprintf(fp, "</vipCodec_XVIDParameters>\n") == EOF )
		return VIPRET_INTERNAL_ERR;

	return VIPRET_OK;
 }


int vipCodec_XVIDParameters::loadFromStreamXML(FILE *fp)
 {
	if ( fscanf(fp, "<vipCodec_XVIDParameters>\n") == EOF )
		throw "error in XML file, unable to import data.";

	if ( fscanf(fp, "  <filename value=\"%s\" />\n", fileName) == EOF )
		throw "error in XML file, unable to import data.";

	if ( fscanf(fp, "  <stream value=\"%d\" />\n", &stream) == EOF )
		throw "error in XML file, unable to import data.";

	if ( fscanf(fp, "  <frameIndex value=\"%ld\" />\n", &frameIndex) == EOF )
		throw "error in XML file, unable to import data.";

	return VIPRET_OK;
 }




