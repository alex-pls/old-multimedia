/**
 *  @class   vipCodec_XVID
 *
 *  @brief

 *
 *  @bug
 *  @warning
 *  @todo
 *
 *  @see     vipCodec
 *  @example test_vipCodec_XVID.cpp
 *  @example test_vipLinuxXVIDPlayer.cpp
 *  @example test_vipLinuxXVIDPlayerGTK.cpp
 *  @example test_vipLinuxXVIDPlayerWin.cpp
 *
 *  @version 1.0
 *  @date    12/07/2005 - //2005
 *  @author  Alessandro Polo
 *
 *
 ****************************************************************************
 * VIPLib Framework 1.1
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib/
 *
 ****************************************************************************/




#ifndef __VIPLIB_VETCODEC_XVID_H__
 #define __VIPLIB_VETCODEC_XVID_H__

 #include "../vipDefs.h"
 #include "../vipCodec.h"

 #include "../vipFrameYUV420.h"
 #include "../vipFrameRGB24.h"
 #include "../vipFrameT.h"



 #include "../../support/xvidcore/src/xvid.h"



 #define BUFFER_SIZE (2*1024*1024)





class vipCodec_XVIDParameters : public vipCodecParameters
{
	protected:

		char fileName[64];
		long frameIndex;
		int stream;

		friend class vipCodec_XVID;


	public:

		vipCodec_XVIDParameters();
		vipCodec_XVIDParameters(const char* filename, int stream = 0, long frameIndex = 0);
		~vipCodec_XVIDParameters() {  }

		void reset();

		void setStream(int stream);
		void setFileName(const char *filename);
		void setFrameIndex(long index = 0);

		VIPRESULT saveToStreamXML(FILE *fp);
		VIPRESULT loadFromStreamXML(FILE *fp);

};


class vipCodec_XVID :  public vipCodec
 {

	protected:

		void *stream_handle;

		unsigned char *mp4_buffer;
		unsigned char *mp4_ptr;

		unsigned char *buffer;

		FILE* file;

		int use_assembler;
		int debug_level;

		int useful_bytes;
		int chunk;
		xvid_dec_stats_t xvid_dec_stats;

		double totaldectime;

		long totalsize;
		int status;

		int filenr;


		vipCodec_XVIDParameters* myParams;


		unsigned int width;		///< XVID width
		unsigned int height;		///< XVID height

		VIPRESULT doDecodeFrame();

		VIPRESULT init();
		VIPRESULT close();
		VIPRESULT flush();
		VIPRESULT release();

		VIPRESULT updateBuffer(unsigned int width, unsigned int height);

		VIPRESULT dec_init(int use_assembler, int debug_level);
		VIPRESULT dec_main(unsigned char *istream, unsigned char *ostream, int istream_size, xvid_dec_stats_t *xvid_dec_stats);

		VIPRESULT write_image(char *prefix, unsigned char *image);
		VIPRESULT write_pnm(char *filename, unsigned char *image);


	public:


		/**
		 * @brief Default constructor, initializa parameters and superclasses.
		 */
		vipCodec_XVID(vipCodec_XVIDParameters* initParams = NULL);

		/**
		 * @brief Creates a new frame from given dimensions, call superclass
		 *        vipFrameRGB constructor.
		 *
		 * @param[in] filename Input BMP filename.
		 * @param[in] format BMP Encoding Format, default auto-selection.
		 */
		vipCodec_XVID(char* filename, int stream = 0);


		~vipCodec_XVID();



		/**
		 * @brief  Set parameters for this filter.
		 *
		 * @param[in] initParams Instance of vipFilterColorParameters or NULL,
		 *                       NULL argument make function to create a new
		 *                       instance with default parameters.
		 *
		 * @return VIPRET_OK
		 */
		VIPRESULT setParameters(vipCodec_XVIDParameters* initParams);

		/**
		 * @brief  Get parameters for this filter.
		 *
		 * @return pointer to vipFilterColorParameters instance.
		 */
		vipCodec_XVIDParameters& getParameters() { return *myParams; };


		VIPRESULT setFilterParameters (vipFilterParameters* initParams) { return setParameters(static_cast<vipCodec_XVIDParameters*>(initParams)); };
		vipFilterParameters* getFilterParameters () { return static_cast<vipFilterParameters*>(myParams); };


		/**
		 * @brief Save current buffered image to current filename, first
		 *        setup current filename and format then call this function.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
		 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
		 */
		VIPRESULT save();


		/**
		 * @brief Load a BMP format image into current buffer (vipFrameRGB), first
		 *        setup current filename and format then call this function.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
		 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
		 */
		VIPRESULT load();

		/**
		 * @brief Load a BMP format image into current buffer (vipFrameRGB).
		 *
		 * @param[in] filename Input BMP filename.
		 * @param[in] format BMP Encoding Format.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
		 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
		 */
		VIPRESULT load(char *filename, int stream = 0);


		VIPRESULT save(char *filename, int stream = 0);


		/**
		 * @brief Reset filename related setup.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_INTERNAL_ERR
		 *		   or VIPRET_ILLEGAL_USE else.
		 */
		VIPRESULT reset();

		/**
		 * @brief  Get the state of current data source.
		 *
		 * @return true is there are no more frames to load, false else.
		 */

		bool EoF();


		/**
		 * @brief Load bmp data into image parameter, if AutoInput is enabled
		 *        try to load next filename, else just copy current data to img.
		 *
		 * @param[out] img VIPLibb Cache Frame to store data.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
		 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
		 *
		 * @note  Ouput operator (>>) call directly this function.
		 * @see   operator >> (vipFrameYUV420&)
		 * @see   AutoInput
		 */
		VIPRESULT extractTo(vipFrameYUV420& img);

		/**
		 * @brief Load bmp data into image parameter, if AutoInput is enabled
		 *        try to load next filename, else just copy current data to img.
		 *
		 * @param[out] img VIPLibb Cache24 Frame to store data.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
		 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
		 *
		 * @note  Ouput operator (>>) call directly this function.
		 * @see   operator >> (vipFrameRGB24&)
		 * @see   AutoInput
		 */
		VIPRESULT extractTo(vipFrameRGB24& img);

		/**
		 * @brief Load bmp data into image parameter, if AutoInput is enabled
		 *        try to load next filename, else just copy current data to img.
		 *
		 * @param[out] img Greyscale VIPLibb Frame to store data.
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
		 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
		 *
		 * @note  Ouput operator (>>) call directly this function.
		 * @see   operator >> (vipFrameT&)
		 * @see   AutoInput
		 */
		VIPRESULT extractTo(vipFrameT<unsigned char>& img);



		/**
		 * @brief Load given image into memory, if AutoOutput is enabled
		 *        image data will be saved as a BMP format file.
		 *
		 * @param[in] img VIPLibb Cache Frame to be processed (encoded for example)
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
		 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
		 *
		 * @note  Input operator (<<) call directly this function.
		 * @see   operator << (vipFrameYUV420&)
		 */
		VIPRESULT importFrom(vipFrameYUV420& img);

		/**
		 * @brief Load given image into memory, if AutoOutput is enabled
		 *        image data will be saved as a BMP format file.
		 *
		 * @param[in] img VIPLibb Cache24 Frame to be processed (encoded for example)
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
		 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
		 *
		 * @note  Input operator (<<) call directly this function.
		 * @see   operator << (vipFrameRGB24&)
		 */
		VIPRESULT importFrom(vipFrameRGB24& img);

		/**
		 * @brief Load given image into memory, if AutoOutput is enabled
		 *        image data will be saved as a BMP format file.
		 *
		 * @param[in] img Greyscale VIPLibb Frame to be processed (encoded for example)
		 *
		 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
		 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
		 *
		 * @note  Input operator (<<) call directly this function.
		 * @see   operator << (vipFrameT&)
		 */
		VIPRESULT importFrom(vipFrameT<unsigned char>& img);




// FRAME BROWSING FUNCTIONS

/*
		/// Seek to point in file
		VIPRESULT setFrameIndex(long index, int stream = 0);

		/// Test for end of file
		bool eof(int stream = 0) const;

		VIPRESULT goToPreviousFrame(int stream = 0);

		VIPRESULT goToVideoEnd(int stream = 0);
		VIPRESULT goToAudioEnd(int stream = 0);
*/
/* Give the seconds time in the last packet read */
		double getLastPacketTime();


// VIDEO INFO FUNCTIONS

		unsigned int getHeight() const { return height; };

		unsigned int getWidth() const { return width; };

		/**
		 * @brief get movie's video frame count.
		 *
		 * @param[in] stream select stream index.
		 *                   default is -1: current active stream.
		 *
		 * @return number of frames in the stream.
		 */
		long getVideoStreamLength(int stream = 0) { return totalsize; };

		/**
		 * @brief get movie's audio sample count for selected stream.
		 *
		 * @param[in] stream select stream index.
		 *                   default is -1: current active stream.
		 *
		 * @return number of sample.
		 */
		long getAudioStreamLength(int stream = -1) { return -1; };


		int getVideoStreamPosition(int stream = 0) { return filenr; };

		double getVideoStreamDecodedTotalTime(int stream = 0) { return totaldectime; };

		/**
		 * @brief get movie's audio streams count.
		 *
		 * @return number of audio streams.
		 */
		bool hasAudio(int stream = -1) { return false; };


		/**
		 * @brief check if loaded movie has a video stream.
		 *
		 * @return true if there is at least one video stream, false else.
		 */
		bool hasVideo(int stream = -1) { return false; };


		/**
		 * @brief get movie's audio streams count.
		 *
		 * @return number of audio streams.
		 */
		int getAudioStreamCount() { return -1; };

		/**
		 * @brief get movie's video streams count.
		 *
		 * @return number of video streams.
		 */
		int getVideoStreamCount() { return -1; };




		/**
		 * @brief get movie's video frame rate.
		 *
		 * @param[in] stream select stream index.
		 *                   default is -1: current active stream.
		 *
		 * @return number of frame per second.
		 */
//		float getVideoFrameRate(int stream = -1) ;








/*
		int getColorModel(int stream = 0);


		bool hasVideo();



		/// Return the frame rate of the XVID
		float getVideoFrameRate(int stream = 0);




// AUDIO INFO FUNCTIONS

		bool hasAudio();


		int getAudioChannels(int stream = 0);

		/// Return the frame rate of the XVID
		float getAudioSampleRate(int stream = 0);

		long getAudioStreamLength(int stream = 0);






		int getXVID3_Version_major() { return mpeg3_major(); };
		int getXVID3_Version_minor() { return mpeg3_minor(); };
		int getXVID3_Version_release() { return mpeg3_release(); };

*/

		// decode all stream !
		VIPRESULT doDecode(long frameCount = 0);

		/**
		 * @brief  Set current canvas' height.
		 *
		 * @return height in pixel.
		 */
		VIPRESULT setHeight(unsigned int value)
		 {
			height = value;
			return VIPRET_OK;
		 };

		/**
		 * @brief  Set current canvas' width.
		 *
		 * @return width in pixel.
		 */
		VIPRESULT setWidth(unsigned int value)
		 {
			width = value;
			return VIPRET_OK;
		 };


// call importFrom, so filename index is managed

		/**
		 * @brief Input operator, import standard VIPLibb frame formats,
		 *        current implementation calls directly importFrom() method.
		 *
		 * @param[in] img VIPLibb Cache Frame to be processed (encoded for example)
		 *
		 * @see   importFrom(vipFrameYUV420&)
		 */
//		void operator << (vipFrameYUV420& img) { vipOutput::operator << (img); }
//		void operator << (vipFrameRGB24& img) { vipOutput::operator << (img); }
//		void operator << (vipFrameT<unsigned char>& img) { vipOutput::operator << (img); }

// call extractTo, so filename index and frame rate are managed

		/**
		 * @brief Ouput operator, export to standard VIPLibb frame formats,
		 *        current implementation calls directly extractTo() method
		 *        and if framerate isn't zero waits untill clock is syncronized,
		 *        if elaboration time is greater than sleeptime, no delay is applied.
		 *
		 * @param[out] img VIPLibb Cache Frame to store data.
		 *
		 * @return Address of current instance.
		 *
		 * @see   importFrom(vipFrameYUV420&)
		 * @see   vipsleep()
		 * @see   setElaborationStart()
		 * @see   getElaborationTime()
		 */
//		vipInput& operator >> (vipFrameYUV420& img) { vipInput::operator >> (img); return *this; }
//		vipInput& operator >> (vipFrameRGB24& img) { vipInput::operator >> (img); return *this; }
//		vipInput& operator >> (vipFrameT<unsigned char>& img) { vipInput::operator >>( img); return *this; }


		bool isEncodingAvailable() { return false; }; //{ return true; };
		bool isDecodingAvailable() { return true; };


};







#endif //__VIPLIB_VETCODEC_XVID_H__
