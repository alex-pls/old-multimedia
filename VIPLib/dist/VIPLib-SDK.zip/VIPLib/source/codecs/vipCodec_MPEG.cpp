/** @file vipCodec_MPEG.cpp
 *
 * File containing methods for the 'vipCodec_MPEG' class.
 * The header for this class can be found in vipCodec_MPEG.h, check
 * that file for class description.
 *
 *
 ****************************************************************************
 * VIPLib Framework 1.1
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib/
 *
 ****************************************************************************/





#include "vipCodec_MPEG.h"
#include "../vipUtility.h"

// #include "../../support/libmpeg3/libmpeg3.h"

/**
 * @brief  Default constructor, initialize parameters and superclasses.
 * @param[in] initParams parameters for this module or NULL for defaults.
 */
vipCodec_MPEG::vipCodec_MPEG(char *filename, int stream) : vipCodec()
 {
	DEBUGMSG("vipCodec_MPEG::vipCodec_MPEG(char *filename, FileFormat format) [CONTRUCTOR] ", *filename)

	buff = NULL;
	file = NULL;
	setParameters(NULL);
	reset();

 	load( filename, stream );

 }

/**
 * @brief   Initialize parameters and load given quicktime movie.
 *
 * @param[in] filename a valid MOV movie filename
 * @param[in] stream video stream to load (default is first: 0)
 *
 */
vipCodec_MPEG::vipCodec_MPEG( vipCodec_MPEGParameters* initParams ) : vipCodec()
 {
	DEBUGMSG("vipCodec_MPEG::vipCodec_MPEG(vipCodec_MPEGParameters* initParams) [CONTRUCTOR] ", *filename)

	buff = NULL;
	file = NULL;

	setParameters(initParams);
	reset();
 }

/**
 * @brief  Reset filename and movie related settings.
 *
 * @return VIPRET_OK
 */
VIPRESULT vipCodec_MPEG::reset()
 {
	INFO("VIPRESULT vipCodec_MPEG::reset() [SET DEFAULT PARAMETERS]")

	setName("MPEG Coder");
	setDescription("Read or write video stream.");
	setVersion(1.0);

	if (file != NULL)
	 {
		mpeg3_close(file);
		file = NULL;
	 }

	if (buff != NULL)
	 {
		// free the memory for each of the rows
		for (unsigned int i = 0; i < height; i++)
			delete [] buff[i];

		// free the rest of the memory
		delete [] buff;
	 }

	width  = 0;
	height = 0;

	if (myParams != NULL)
		myParams->reset();

	return VIPRET_OK;
 }


/**
 * @brief  Set parameters for (de)coding.
 *
 * @param[in] initParams Instance of vipCodec_MPEGParameters or NULL,
 *                       NULL argument make function to create a new
 *                       instance with default parameters.
 *
 * @return VIPRET_OK
 */
VIPRESULT vipCodec_MPEG::setParameters (vipCodec_MPEGParameters* initParams)
 {

	if ( initParams == NULL )
		myParams = new vipCodec_MPEGParameters();
	else
		myParams = initParams;

	return VIPRET_OK;
 }

/**
 * @brief Default destructor, close file and free buffer.
 */
vipCodec_MPEG::~vipCodec_MPEG()
 {
	if (file != NULL)
		mpeg3_close(file);

	if (buff != NULL)
	 {
		// free the memory for each of the rows
		for (unsigned int i = 0; i < height; i++)
			delete [] buff[i];

		// free the rest of the memory
		delete [] buff;
	 }
 }

bool vipCodec_MPEG::EoF()	// buggy
 {
	if (file == NULL)
		return true;

	return false;
 }


/**
 * @brief Load current frame data into image (parameter), increments
 *        frame index.
 *
 * @param[out] img VIPLibb Cache Frame to store data.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note  Ouput operator (>>) call directly this function.
 * @see   operator >> (vipFrameYUV420&)
 */
VIPRESULT vipCodec_MPEG::extractTo(vipFrameYUV420& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_MPEG::extractTo(vipFrameYUV420& img) [pushing data]", doBuffering)

	if (file == NULL)
		return VIPRET_ILLEGAL_USE;

	if (width != img.width || height != img.height)
		img.reAllocCanvas(width, height);

	// read the frame to a temporary buffer
	mpeg3_read_yuvframe(file,
						(char*)img.Y,
						(char*)img.U,
						(char*)img.V,
						0, 0,
						width, height,
						0);

/* Supported color models for mpeg3_read_yuvframe */
//#define MPEG3_YUV420P 12
//#define MPEG3_YUV422P 13

	return VIPRET_NOT_IMPLEMENTED;
 }


/**
 * @brief Load current frame data into image (parameter), increments
 *        frame index.
 *
 * @param[out] img VIPLibb Cache24 Frame to store data.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note  Ouput operator (>>) call directly this function.
 * @see   operator >> (vipFrameRGB24&)
 */
VIPRESULT vipCodec_MPEG::extractTo(vipFrameRGB24& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_MPEG::extractTo(vipFrameRGB24& img) [pushing data]", doBuffering)

	if (file == NULL)
		return VIPRET_ILLEGAL_USE;

	if (width != img.width || height != img.height)
		img.reAllocCanvas(width, height);

	// read the frame to a temporary buffer
	mpeg3_read_frame(file, buff,
					 0, 0,
					 width, height,
					 width, height,
					 MPEG3_RGB888, 0);


	vipUtility::conv_rgb24_rgb96(buff, (unsigned char*)img.data[0], width, height);
//non va	memcpy((unsigned char*)img.data[0], buff, width*height*3);

	return VIPRET_OK;

 }


/**
 * @brief Load current frame data into image (parameter), increments
 *        frame index.
 *
 * @param[out] img Greyscale VIPLibb Frame to store data.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note  Ouput operator (>>) call directly this function.
 * @see   operator >> (vipFrameT&)
 */
VIPRESULT vipCodec_MPEG::extractTo(vipFrameT<unsigned char>& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_MPEG::extractTo(vipFrameT& img) [pushing data]", doBuffering)

//#define MPEG3_RGB565 2
//#define MPEG3_BGR888 0
//#define MPEG3_BGRA8888 1
//#define MPEG3_RGB888 3
//#define MPEG3_RGBA8888 4
//#define MPEG3_RGBA16161616 5


	return VIPRET_NOT_IMPLEMENTED;


 }


/**
 * @brief Encode given image to stream, increments frame index.
 *
 * @param[in] img VIPLibb Cache Frame to be encoded.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note  Input operator (<<) call directly this function.
 * @see   operator << (vipFrameYUV420&)
 */
VIPRESULT vipCodec_MPEG::importFrom(vipFrameYUV420& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_MPEG::importFrom(vipFrameYUV420& img) [reading data]", doBuffering)

	return VIPRET_NOT_IMPLEMENTED;


 }

/**
 * @brief Encode given image to stream, increments frame index.
 *
 * @param[in] img VIPLibb Cache Frame to be encoded.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note  Input operator (<<) call directly this function.
 * @see   operator << (vipFrameRGB24&)
 */
VIPRESULT vipCodec_MPEG::importFrom(vipFrameRGB24& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_MPEG::importFrom(vipFrameRGB24& img) [reading data]", doBuffering)

	return VIPRET_NOT_IMPLEMENTED;


 }

/**
 * @brief Encode given image to stream, increments frame index.
 *
 * @param[in] img VIPLibb Cache Frame to be encoded.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if frame
 *		   is not valid, VIPRET_INTERNAL_ERR or VIPRET_ILLEGAL_USE else.
 *
 * @note  Input operator (<<) call directly this function.
 * @see   operator << (vipFrameT&)
 */
VIPRESULT vipCodec_MPEG::importFrom(vipFrameT<unsigned char>& img)
 {
	DEBUGMSG("VIPRESULT vipCodec_MPEG::importFrom(vipFrameYUV420& img) [reading data]", doBuffering)

	return VIPRET_NOT_IMPLEMENTED;


 }



/**
 * @brief  Load movie from current filename, use SetFileName() or
 *         load(char*, int).
 *
 * @return VIPRET_ILLEGAL_USE if file is not correctly loaded, VIPRET_OK else.
 */
VIPRESULT vipCodec_MPEG::load()
 {
	INFO("VIPRESULT vipCodec_MPEG::load() [loading data to buffer]")

	// check the files signature is valid
	if ( !mpeg3_check_sig(myParams->fileName) )
		return VIPRET_ILLEGAL_USE;

	file = mpeg3_open(myParams->fileName);

	if (file == NULL)
		return VIPRET_ILLEGAL_USE;


	// check that it is a video MPEG file
	if (!mpeg3_has_video(file))
		return VIPRET_ILLEGAL_USE;//non-video MPEG file";

//BUG CHECK STREAM RANGE

	width  = mpeg3_video_width(file, myParams->stream);
	height = mpeg3_video_height(file, myParams->stream);

	// allocate memory for rgb rows
	buff = new (unsigned char*)[height];
	for (unsigned int i = 0; i < height - 1; i++)
		buff[i] = new (unsigned char)[width*3];

	// last row need space for mmx scratch area
	buff[height - 1] = new (unsigned char)[width*3 + 4];

        // Allocate memory for YUV data
        Y = new char[width*height] ;
        U = new char[width*height/4] ;
        V = new char[width*height/4] ;

	return VIPRET_OK;
}

/**
 * @brief  Load a BMP format image into current buffer (vipFrameRGB).
 *
 * @param[in] filename a valid MPEG1-2 movie filename
 * @param[in] stream video stream to load (default is first: 0)
 *
 * @return VIPRET_ILLEGAL_USE if file is not correctly loaded, VIPRET_OK else.
 */
VIPRESULT vipCodec_MPEG::load(char *filename, int stream)
 {
	DEBUGMSG("VIPRESULT vipCodec_MPEG::load(char *filename, FileFormat format) [loading data to buffer]", filename)

 	myParams->setFileName(filename);
 	myParams->setStream(stream);

	return load();
 }



/**
 * @brief  Move frame index to previous frame
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_ILLEGAL_USE is stream
 *		   hasn't been loaded.
 */
VIPRESULT vipCodec_MPEG::goToPreviousFrame(int stream)
 {
	if ( file == NULL)
		return VIPRET_ILLEGAL_USE;

	if ( stream == -1  )
		return mpeg3_previous_frame(file, myParams->stream);

	if ( stream < 0 || stream >= getVideoStreamCount() )
		return VIPRET_PARAM_ERR;

	return mpeg3_previous_frame(file, stream);
 }

/**
 * @brief  Move video frame index to end (last frame)
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_ILLEGAL_USE is stream
 *		   hasn't been loaded.
 */
VIPRESULT vipCodec_MPEG::goToVideoEnd(int stream)
 {
	if ( file == NULL)
		return VIPRET_ILLEGAL_USE;

	if ( stream == -1  )
		return mpeg3_end_of_video(file, myParams->stream);

	if ( stream < 0 || stream >= getVideoStreamCount() )
		return VIPRET_PARAM_ERR;

	return mpeg3_end_of_video(file, stream);
 }

/**
 * @brief  Move audio sample index to end (last frame)
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_ILLEGAL_USE is stream
 *		   hasn't been loaded.
 */
VIPRESULT vipCodec_MPEG::goToAudioEnd(int stream)
 {
	if ( file == NULL)
		return VIPRET_ILLEGAL_USE;

	if ( stream == -1  )
		return mpeg3_end_of_audio(file, myParams->stream);

	if ( stream < 0 || stream >= getAudioStreamCount() )
		return VIPRET_PARAM_ERR;

	return mpeg3_end_of_audio(file, stream);
 }


double vipCodec_MPEG::getLastPacketTime()
 {
	if ( file == NULL)
		return -1;

	return mpeg3_get_time(file);
 }



/**
 * @brief check if loaded movie has a video stream.
 *
 * @return true if there is at least one video stream, false else.
 */
bool vipCodec_MPEG::hasVideo()
 {
	if ( file == NULL)
		return false;

	if ( mpeg3_has_video(file) )
		return true;
	else
		return false;
 }

/**
 * @brief get movie's video streams count.
 *
 * @return number of video streams.
 */
int vipCodec_MPEG::getVideoStreamCount()
 {
	if ( file == NULL)
		return -1;

	return mpeg3_total_vstreams(file);
 }

/**
 * @brief get movie's audio streams count.
 *
 * @return number of audio streams.
 */
bool vipCodec_MPEG::hasAudio()
 {
	if ( file == NULL)
		return false;

	if ( mpeg3_has_audio(file) )
		return true;
	else
		return false;
 }

/**
 * @brief get movie's audio streams count.
 *
 * @return number of audio streams.
 */
int vipCodec_MPEG::getAudioStreamCount()
 {
	if ( file == NULL)
		return -1;

	return mpeg3_total_astreams(file);
 }

/**
 * @brief get movie's audio sample count for selected stream.
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return number of sample.
 */
long vipCodec_MPEG::getAudioStreamLength(int stream)
 {
	if ( hasAudio() && stream == -1  )
		return mpeg3_audio_samples(file, myParams->stream);

	if ( !hasAudio() || stream < 0 || stream >= getAudioStreamCount() )
		return -1;

	return mpeg3_audio_samples(file, stream);
 }

/**
 * @brief get movie's video frame count.
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return number of frames in the stream.
 */
long vipCodec_MPEG::getVideoStreamLength(int stream)
 {
	if ( hasVideo() && stream == -1  )
		return mpeg3_video_frames(file, myParams->stream);

	if ( !hasVideo() || stream < 0 || stream >= getVideoStreamCount() )
		return -1;

	return mpeg3_video_frames(file, stream);
 }

/**
 * @brief get movie's audio sample rate for selected stream.
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return number of sample per second.
 */
float vipCodec_MPEG::getAudioSampleRate(int stream)
 {
	if ( hasAudio() && stream == -1  )
		return  mpeg3_sample_rate(file, myParams->stream);

	if ( !hasAudio() || stream < 0 || stream >= getAudioStreamCount() )
		return -1;

	return mpeg3_sample_rate(file, stream);
 }

/**
 * @brief get movie's audio channel count for selected stream.
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return number of audio channels.
 */
int vipCodec_MPEG::getAudioChannels(int stream)
 {
	if ( hasAudio() && stream == -1  )
		return  mpeg3_audio_channels(file, myParams->stream);

	if ( !hasAudio() || stream < 0 || stream >= getAudioStreamCount() )
		return -1;

	return mpeg3_audio_channels(file, stream);
 }

/**
 * @brief get movie's video frame rate.
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return number of frame per second.
 */
float vipCodec_MPEG::getVideoFrameRate(int stream)
 {
	if ( hasVideo() && stream == -1  )
		return  mpeg3_frame_rate(file, myParams->stream);

	if ( !hasVideo() || stream < 0 || stream >= getVideoStreamCount() )
		return -1;

	return mpeg3_frame_rate(file, stream);
 }

/**
 * @brief read color model for selected stream.
 *
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return Color Model.
 */
int vipCodec_MPEG::getColorModel(int stream)
 {
	if ( !hasVideo() || stream < 0 || stream >= getVideoStreamCount() )
		return -1;

	return mpeg3_colormodel(file, stream);
 }






/**
 * @brief  Seek to point in stream (position in the video timeline).
 *
 * @param[in] index position to set, number of frame offset [0, framesCount[
 * @param[in] stream select stream index.
 *                   default is -1: current active stream.
 *
 * @return VIPRET_OK if everything is fine, VIPRET_PARAM_ERR if index or
 *		   stream are not valid, VIPRET_ILLEGAL_USE if stream hasn't been loaded.
 */
VIPRESULT vipCodec_MPEG::setFrameIndex(long index, int stream)
 {
	if ( file == NULL)
		return VIPRET_ILLEGAL_USE;

	if ( hasVideo() && stream == -1  )
		return  mpeg3_set_frame(file, index, myParams->stream);

	if ( !hasVideo() || stream < 0 || stream >= getVideoStreamCount() )
		return VIPRET_ILLEGAL_USE;

	myParams->setFrameIndex(index);

    return mpeg3_set_frame(file, index, stream);
 }

/**
 * @brief  Test for end of file.
 *
 * @return true if frame index is last frame, false else.
 */
bool vipCodec_MPEG::eof(int stream) const
 {
	if ( file == NULL)
		return true;

	if ( stream == -1  )
		if ( mpeg3_end_of_video(file, myParams->stream) == 0 )
			return false;
		else
			return true;

	if ( mpeg3_end_of_video(file, stream) == 0 )
		return false;
	else
		return true;
 }






int vipCodec_MPEG::getMPEG3_Version_major() { return mpeg3_major(); };
int vipCodec_MPEG::getMPEG3_Version_minor() { return mpeg3_minor(); };
int vipCodec_MPEG::getMPEG3_Version_release() { return mpeg3_release(); };























vipCodec_MPEGParameters::vipCodec_MPEGParameters()
 {
	reset();
 }

vipCodec_MPEGParameters::vipCodec_MPEGParameters(const char* filename, int stream, long frameIndex)
 {
	reset();
	setFileName(filename);
	setStream(stream);
	setFrameIndex(frameIndex);
 }

void vipCodec_MPEGParameters::reset()
 {
	strcpy(fileName, (const char*)"input.mpg\0");
	frameIndex = 0;
	stream = 0;
 }


void vipCodec_MPEGParameters::setFileName(const char *filename)
 {
	strncpy(fileName, filename, 64);
 }

void vipCodec_MPEGParameters::setFrameIndex(long index)
 {
	frameIndex = index;
 }

void vipCodec_MPEGParameters::setStream(int s)
 {
	stream = s;
 }


int vipCodec_MPEGParameters::saveToStreamXML(FILE *fp)
 {
	if ( fp == NULL )
		return VIPRET_PARAM_ERR;

	if( fprintf(fp, "<vipCodec_MPEGParameters>\n") == EOF )
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <filename value=\"%s\" />\n", fileName) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <stream value=\"%d\" />\n", stream) == EOF)
		return VIPRET_INTERNAL_ERR;

	if ( fprintf(fp, "  <frameIndex value=\"%ld\" />\n", frameIndex) == EOF)
		return VIPRET_INTERNAL_ERR;

	if( fprintf(fp, "</vipCodec_MOVParameters>\n") == EOF )
		return VIPRET_INTERNAL_ERR;

	return VIPRET_OK;
 }


int vipCodec_MPEGParameters::loadFromStreamXML(FILE *fp)
 {
	if ( fscanf(fp, "<vipCodec_MPEGParameters>\n") == EOF )
		throw "error in XML file, unable to import data.";

	if ( fscanf(fp, "  <filename value=\"%s\" />\n", fileName) == EOF )
		throw "error in XML file, unable to import data.";

	if ( fscanf(fp, "  <stream value=\"%d\" />\n", &stream) == EOF )
		throw "error in XML file, unable to import data.";

	if ( fscanf(fp, "  <frameIndex value=\"%ld\" />\n", &frameIndex) == EOF )
		throw "error in XML file, unable to import data.";

	return VIPRET_OK;
 }
