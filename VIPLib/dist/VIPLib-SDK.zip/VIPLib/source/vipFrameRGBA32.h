/**
 *  @class   vipFrameRGBA32
 *
 *  @brief   This Class implements standard VIPLib I/O Frame format.
 *           An image consisting of red, green and blue pixels.
 *           PixelRGB24 Array [width*height] (raster scan)
 *           Currently PixelRGB24 is difined as 3 char (3 * 8 = 24bits)
 *
 *
 *  @see     PixelRGB24
 *  @see     vipFrame
 *
 *  @version 0.6
 *  @date    12/07/2005 - //2005
 *  @author  Alessandro Polo
 *
 *
 ****************************************************************************
 * VIPLib Framework
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib
 *
 *  maintained by MultiMedia Laboratory - DIT - University of Trento
 *
 ****************************************************************************/




#ifndef __VIPLIBVIPFRAMERGBA32_H__
 #define __VIPLIBVIPFRAMERGBA32_H__

 #define VIPFRAMERGB24_SLOWMODE

 #include "vipDefs.h"

// #include "PixelRGB24.h"
 #include "vipFrame.h"

 class vipFrameRGBA32;
  #include "vipFrameYUV420.h"
  #include "vipFrameRGB24.h"
  #include "vipFrameRGB96.h"

typedef char* PixelRGBA32;

class vipFrameRGBA32 : public virtual vipFrame
 {

	public:

		/**
		 * @var   This value is used only by destructor, if true array will be deleted.
		 */
		bool autoFreeData;


		/**
		 * @var   RGB data array pointer. Size is width * height.
		 */
		unsigned char *data;


	public:

		/**
		 * @var   Enumerate available Channels.
		 */
		enum ChannelRGBA { RED, GREEN, BLUE, ALPHA };

		/**
		 * @brief Default constructor, initialize height and width to 0.
		 */
		vipFrameRGBA32();

		/**
		 * @brief Create an image with the given dimensions, allocates empty data.
		 * @param width Width of the image.
		 * @param height Height of the image.
		 */
		vipFrameRGBA32(unsigned int width, unsigned int height);

		/**
		 * @brief Copy Constructor, create an image from another image, copying memory.
		 * @param img source image.
		 */
		vipFrameRGBA32(vipFrameRGBA32& img);

		/**
		 * @brief Copy Constructor, create an image from another image, copying memory.
		 * @param img source image.
		 */
		vipFrameRGBA32(vipFrameRGB24& img);

		/**
		 * @brief Copy Constructor, create an image from another image, copying memory.
		 * @param img source image.
		 */
		vipFrameRGBA32(vipFrameRGB96& img);

		/**
		 * @brief Destructor currenly clear pixel data (array).
		 */
		~vipFrameRGBA32();


		void* dump_buffer() { return static_cast<void*>(data); };

		unsigned int getBufferSize() { return (unsigned int)( width * height * 4); };


		VIPRESULT reAllocCanvas(unsigned int w, unsigned int h);

		unsigned int getBpp() { return 32; };
		VIPRESULT setBlack();
		VIPRESULT setWhite();

		VIPRESULT extractBrightness(unsigned char* buffer, unsigned int* size = NULL );

		/**
		 * @brief Clear all pixel to the specified value.
		 *
		 * @param bg a PixelRGB to overwrite on all image.
		 *
		 * @return current instance address.
		 */
		vipFrameRGBA32& clearWith(unsigned char* bg);


		/**
		 * @brief Set pixel (x, y) to the specified value.
		 *
		 * @param x x position of the pixel.
		 * @param y y position of the pixel.
		 * @param p new value for the selected coords.
		 *
		 * @note No check is made that x and y are in range.
		 */
		VIPRESULT setPixel(unsigned int x, unsigned int y, unsigned char* p);


		/**
		 * @brief Get pixel (x, y) value and store it to p.
		 *
		 * @param x x position of the pixel.
		 * @param y y position of the pixel.
		 * @param p address to store selected pixel's value.
		 *
		 * @note No check is made that x and y are in range.
		 */
		VIPRESULT getPixel(unsigned int x, unsigned int y, unsigned char* p);



		/**
		 * @brief Copies all pixel data from img.
		 *        Throws an exception if images are of different size.
		 *
		 * @param img The image to copy the data from.
		 *
		 * @return current instance.
		 */
		vipFrameRGBA32& operator = (vipFrameRGBA32& img);

		/**
		 * @brief Overload equals-add (+=) operator for two images (pixel += loop)
		 *        Throws an exception if images are of different size.
		 *
		 * @param img The image to add to current data.
		 *
		 * @return current instance.
		 */
		vipFrameRGBA32& operator += (vipFrameRGBA32& img);

		/**
		 * @brief Overload equals-add (+=) operator for two images (pixel += loop)
		 *        Throws an exception if images are of different size.
		 *
		 * @param img The image to add to current data.
		 *
		 * @return current instance.
		 */
		vipFrameRGBA32& operator -= (vipFrameRGBA32& img);


		void operator << (const vipFrameRGB24& img);
		void operator << (const vipFrameRGB96& img);

		vipFrameRGBA32& operator >> (vipFrameRGB24& img);
		vipFrameRGBA32& operator >> (vipFrameRGB96& img);


		VIPFRAME_PROFILE getProfile() { return vipFrame::VIPFRAME_RGBA32; };
		VIPFRAME_CHANNEL_TYPE getChannelType() { return vipFrame::VIPFRAME_CT_PLANAR; };

		int getFOURCC() { return 0x41424752; };

 };



#endif //__VIPLIBVIPFRAMERGBA32_H__

