/** @file    test_vipFilterColor.cpp
 *
 *  @brief   Testing code for class vipFilterColor.
 *
 *           Performs all available operations on a source image and
 *           save output to BMP file. Then tests settings serialization.
 *
 *
 *  @todo	 update whaen vipFilterColor is fully implemented
 *
 *  @see     vipFilterColor
 *
 *  @version 0.1
 *  @date    20/08/2005
 *  @author  Alessandro Polo
 *
 *
 ****************************************************************************
 * VIPLib Framework
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib
 *
 *  maintained by MultiMedia Laboratory - DIT - University of Trento
 *
 ****************************************************************************/


//---------------------------------------------------------------------------

#pragma hdrstop

//---------------------------------------------------------------------------

#include "../source/vipFrameRGB96.h"

#include "../source/codecs/vipCodec_BMP.h"
#include "../source/filters/vipFilterColor.h"

#include <stdio.h>

#pragma argsused

int main(int argc, char* argv[])
 {
	printf("Testing vipFilterColor Development...\n");

	printf("\nCreating Instances...\n");
	vipFrameRGB96 img, img2(320,200);
	vipFilterColor colorf;

	printf("Loading Frame...\n");
	vipCodec_BMP::load(img, "frame1.bmp", vipCodec_BMP::FORMAT_BMP_24);

	printf("Start Processing...\n\n");

	printf(" ..\n");
	colorf.getParameters().setRunMode(vipFilterColorParameters::CLAMP);
	colorf.getParameters().setWorkingBpp(24);
	colorf << img;
	colorf >> img2;
	vipCodec_BMP::save(img2, "OUT_CLAMP24.bmp", vipCodec_BMP::FORMAT_BMP_24);

	printf(" ..\n");
	colorf.getParameters().setRunMode(vipFilterColorParameters::CLAMP);
	colorf.getParameters().setWorkingBpp(16);
	colorf << img;
	colorf >> img2;
	vipCodec_BMP::save(img2, "OUT_CLAMP16.bmp", vipCodec_BMP::FORMAT_BMP_24);

	printf(" ..\n");
	colorf.getParameters().setRunMode(vipFilterColorParameters::INVERT);
	colorf << img;
	colorf >> img2;
	vipCodec_BMP::save(img2, "OUT_INVERT.bmp", vipCodec_BMP::FORMAT_BMP_24);

	printf(" ..\n");
	colorf.getParameters().setRunMode(vipFilterColorParameters::EXTRACTBITPLANE);
	colorf << img;
	colorf >> img2;
	vipCodec_BMP::save(img2, "OUT_EXTRACTBITPLANE1.bmp", vipCodec_BMP::FORMAT_BMP_24);

	printf(" ..\n");
	colorf.getParameters().setRunMode(vipFilterColorParameters::EXTRACTBITPLANE);
	colorf.getParameters().setBitPlaneBits(4);
	colorf << img;
	colorf >> img2;
	vipCodec_BMP::save(img2, "OUT_EXTRACTBITPLANE4.bmp", vipCodec_BMP::FORMAT_BMP_24);

	printf("\nParameters Serialization (XML)...\n");
	colorf.getParameters().setRunMode(vipFilterColorParameters::CLAMP);
	colorf.getParameters().setWorkingBpp(16);
	colorf.getParameters().setBitPlaneBits(4);
	colorf.getParameters().saveToXML("color.XML");

	vipFilterColor colorf2;
	colorf2.getParameters().loadFromXML("color.XML");
	colorf2.getParameters().saveToXML("color_COPY.XML");

	printf("Test Completed. Type something to continue...\n");
	getchar();

	return 0;
 }
//---------------------------------------------------------------------------
