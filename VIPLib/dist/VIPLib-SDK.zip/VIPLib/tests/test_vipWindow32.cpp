/** @file    test_vipWindow32.cpp
 *
 *  @brief   Testing code for class vipWindow32.
 *
 *           This is a very simple Win32 application, using only
 *           Windows' Application Programming Interface and GDI
 *           for displaying images. It slides between 2 frames
 *           some times. You can type any key for refreshing window.
 *
 *
 *  @bug     This way to draw canvas is very slow, should interface
 *           with DirectX instead of GDI.
 *
 *  @warning Slow drawing, designed for static preview.
 *  @note    Need Windows 95 or later
 *
 *  @see     vipWindow32
 *
 *  @version 1.0.2
 *  @date    27/08/2005
 *  @author  Alessandro Polo
 *
 *
 ****************************************************************************
 * VIPLib Framework
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib
 *
 *  maintained by MultiMedia Laboratory - DIT - University of Trento
 *
 ****************************************************************************/


//---------------------------------------------------------------------------

#pragma hdrstop

//---------------------------------------------------------------------------

#define _WIN32_DCOM // needed by VC6 for OLE..

#include "../../source/vipFrameRGB96.h"
#include "../../source/codecs/vipCodec_BMP.h"
#include "../../source/outputs/vipWindow32.h"

#include <windows.h>

//---------------------------------------------------------------------------

// Global Objects
vipWindow32* myOut;
vipFrameRGB24* frame1;
vipFrameRGB24* frame2;

// Declarations
LRESULT CALLBACK WndMainProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

/**
 * @brief  Main function (called by OS)
 *         Loads 2 frames, create a new instance of vipWindow32 and show it.
 *
 *
 * @return DefWindowProc(..)
 */
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hInstP, LPSTR lpCmdLine, int nCmdShow)
{
    MSG msg={0};
    WNDCLASS wc;

    // Initialize COM
    if(FAILED(CoInitializeEx(NULL, COINIT_APARTMENTTHREADED)))
    {
        MessageBox(NULL, TEXT("CoInitialize Failed!\r\n"), TEXT("PlayCapMoniker"), MB_OK | MB_ICONERROR);
        exit(1);
    }

    // Register the window class
    ZeroMemory(&wc, sizeof wc);
    wc.lpfnWndProc   = WndMainProc;
    wc.hInstance     = hInstance;
    wc.lpszClassName = VIPW32_DEF_CLSNAME;
    wc.lpszMenuName  = NULL;
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    if(!RegisterClass(&wc))
    {
        MessageBox(NULL, TEXT("RegisterClass Failed! Error=0x%x\r\n"), TEXT("PlayCapMoniker"), MB_OK | MB_ICONERROR);
        CoUninitialize();
        exit(1);
    }


	// load frames for animation example
	frame1 = new vipFrameRGB24();
	frame2 = new vipFrameRGB24();
	vipCodec_BMP::load(*frame1, "frame1.bmp", vipCodec_BMP::FORMAT_BMP_24);
	vipCodec_BMP::load(*frame2, "frame2.bmp", vipCodec_BMP::FORMAT_BMP_24);

    myOut = new vipWindow32(hInstance);

    if( myOut->dump_handle() )
    {
		myOut->show();

        // Main message loop
        while(GetMessage(&msg,NULL,0,0))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    // Release COM
    CoUninitialize();

	delete frame1;
	delete frame2;
	delete myOut;

    return ((int) msg.wParam);
}



/**
 * @brief  This function manage message loop.
 *         It's implemented for events: WM_KEYDOWN and WM_PAINT, on paint frames
 *         are drawed sequentially.
 *
 * @param hwnd	application's handle
 * @param message message to process
 * @param wParam message parameter
 * @param lParam message parameter pointer
 *
 * @return DefWindowProc(..)
 */
LRESULT CALLBACK WndMainProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_SIZE:

            break;

		// Force a redraw when a key is pressed
		case WM_KEYDOWN:
			InvalidateRect(myOut->dump_handle(), NULL, TRUE);
			break;

		// Paint our window
		case WM_PAINT:
			{
			// gdi allows to redraw window only here ! (call InvalidateRect(..) to raise WM_PAINT message)

			// [.code here.]

                for (int i = 0; i< 10; i++)
                 {
                        *myOut << *frame1;
                        *myOut << *frame2;
                 }


			}
		break;

        case WM_CLOSE:
            myOut->hide();//same as calling ShowWindow(myOut->getHandle(), SW_HIDE);
            break;

        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
    }

    return DefWindowProc (hwnd, message, wParam, lParam);
}




