/** @file    test_vipCodec_XVID.cpp
 *
 *  @brief   Testing code for class vipCodec_XVID.

 *
 *  @warning
 *
 *  @see     vipCodec_XVID
 *  @see     vipDoctor
 *
 *  @version 1.0.2
 *  @date    14/09/2005
 *  @author  Alessandro Polo
 *
 *
 ****************************************************************************
 * VIPLib Framework
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib
 *
 *  maintained by MultiMedia Laboratory - DIT - University of Trento
 *
 ****************************************************************************/


//---------------------------------------------------------------------------

#pragma hdrstop

//---------------------------------------------------------------------------

#include "../source/vipFrameRGB96.h"
#include "../source/vipFrameRGB24.h"

#include "../source/outputs/vipDoctor.h"

#include "../source/codecs/vipCodec_XVID.h"
#include "../source/codecs/vipCodec_BMP.h"

#include <stdio.h>

#pragma argsused


int main(int argc, char* argv[])
 {
	printf("Testing vipCodec_XVID Development...\n");

	printf("\nCreating Instances...\n");
	vipFrameRGB96 img(320,240);
	vipFrameRGB24 img2(320,240);
	vipCodec_XVID xvidSource;
	vipDoctor doc;


	int ret = xvidSource.load("football.avi");

	if ( ret == VETRET_OK)
		printf("XVID Stream loaded.\n");
	else
	 {
		printf("XVID Stream HAS NOT BEEN loaded.\n");
		return 1;
	 }

	xvidSource >> img2;

	printf("\nXVID Stream INFO:\n");

  	printf(" VIDEO STREAM [0] WIDTH: %d\n", xvidSource.getWidth() );
	printf(" VIDEO STREAM [0] HEIGHT: %d\n", xvidSource.getHeight() );


	xvidSource >> img;
	xvidSource >> img2;
	xvidSource >> img;
	xvidSource >> img2;
	vipCodec_BMP::save(img, "XVID_Extracted_Frame1.bmp", vipCodec_BMP::FORMAT_BMP_24);
	vipCodec_BMP::save(img2, "XVID_Extracted_Frame1_24b.bmp", vipCodec_BMP::FORMAT_BMP_24);

/*

	printf(" VIDEO STREAMS COUNT: %d\n", mpegSource.getVideoStreamCount() );
	printf(" VIDEO STREAM [0] FRAME RATE: %f\n", mpegSource.getVideoFrameRate() );
	printf(" VIDEO STREAM [0] FRAME COUNT: %ld\n", mpegSource.getVideoStreamLength() );


	printf(" AUDIO STREAMS COUNT: %d\n", mpegSource.getAudioStreamCount() );
	printf(" AUDIO STREAM [0] CHANNELS: %d\n", mpegSource.getAudioChannels() );
	printf(" AUDIO STREAM [0] SAMPLE RATE: %f\n", mpegSource.getAudioSampleRate() );
	printf(" AUDIO STREAM [0] SAMPLE COUNT: %ld\n", mpegSource.getAudioStreamLength() );

	vipFrameRGB24 img24a(mpegSource.getWidth(), mpegSource.getHeight());
	vipFrameRGB24 img24b(mpegSource.getWidth(), mpegSource.getHeight());

	printf("\nExtracting frames..\n");

	mpegSource >> img24a;
	mpegSource >> img24b;

	vipCodec_BMP::save(img24a, "XVID_Extracted_Frame1.bmp", vipCodec_BMP::FORMAT_BMP_24);
	vipCodec_BMP::save(img24b, "XVID_Extracted_Frame2.bmp", vipCodec_BMP::FORMAT_BMP_24);



	printf("\nParameters Serialization (XML)...\n");
	xvidSource.getParameters().setFileName("input_video.avi");
	xvidSource.getParameters().setFrameIndex(1000);
	xvidSource.getParameters().setStream(0);
	xvidSource.getParameters().saveToXML("XVID_param.XML");


	vipCodec_XVID xvidSource2;

	xvidSource2.getParameters().loadFromXML("XVID_param.XML");
	xvidSource2.getParameters().saveToXML("XVID_param_COPY.XML");

	printf("Test Completed. Type something to continue...\n");
	getchar();

*/

	return 0;
 }
//---------------------------------------------------------------------------
