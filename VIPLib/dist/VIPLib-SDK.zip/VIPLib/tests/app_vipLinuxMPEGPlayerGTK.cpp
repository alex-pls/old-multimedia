/** @file    test_vipLinuxMPEGPlayer.cpp
 *
 *  @brief   Testing code for class vipCodec_MPEG and vipWindowQT.
 *
 *           Load first video stream from an MPEG1-2 format file and
 *           show preview in a window , stream is passed through
 *            vipFrameRGB24 objects.
 *           Frame rate should be the higher possible, after 100 frames,
 *           loop will exit printing average fps; this number depends
 *           on source rate and window's redrawing both (sum).
 *           Then last captured frame is saved.
 *
 *  @warning requires VIPLib with MPEG support and GUI support (make all)
 *
 *  @see     vipCodec_MPEG
 *  @see     vipWindowQT
 *  @see     app_Video4LinuxPlayer.cpp
 *  @see     app_LinuxMOVPlayer.cpp
 *
 *  @version 1.0.2
 *  @date    11/09/2005
 *  @author  Alessandro Polo
 *
 *
 ****************************************************************************
 * VIPLib Framework
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib
 *
 *  maintained by MultiMedia Laboratory - DIT - University of Trento
 *
 ****************************************************************************/


//---------------------------------------------------------------------------

#pragma hdrstop

//---------------------------------------------------------------------------

#include "../source/vipFrameRGB24.h"
#include "../source/vipUtility.h"

#include "../source/outputs/vipWindowGTK.h"
#include "../source/outputs/vipDoctor.h"

#include "../source/codecs/vipCodec_MPEG.h"

#include <stdio.h>

#pragma argsused


int main(int argc, char* argv[])
 {
	printf("Testing vipCodec_MPEG and vipWindowQT Development...\n");

	printf("\nCreating Instances...\n");
	vipFrameRGB24 img24;
	vipDoctor doc;

	int i = 0;
	long time = 0;
	float fps = 0 ;
	vipCodec_MPEG mpegSource;

	printf("\nLoading Movie...\n");
	int ret = mpegSource.load("football.mpg");

	if ( ret == VETRET_OK)
		printf("MPEG Stream loaded.\n");
	else
	 {
		printf("MPEG Stream HAS NOT BEEN loaded. (file football.mpg not found?)\n");
		return 1;
	 }

	printf("\nMPEG Stream INFO:\n");
	printf(" Video StreamS Count: %d\n", mpegSource.getVideoStreamCount() );
	printf(" Video Stream [0] Frame Rate: %f\n", mpegSource.getVideoFrameRate() );
	printf(" Video Stream [0] Frame Count: %ld\n", mpegSource.getVideoStreamLength() );
	printf(" Video Stream [0] Width: %d\n", mpegSource.getWidth() );
	printf(" Video Stream [0] Height: %d\n", mpegSource.getHeight() );
	printf(" Audio StreamS Count: %d\n", mpegSource.getAudioStreamCount() );
	printf(" Audio Stream [0] Channels: %d\n", mpegSource.getAudioChannels() );
	printf(" Audio Stream [0] Sample Rate: %f\n", mpegSource.getAudioSampleRate() );
	printf(" Audio Stream [0] Sample Count: %ld\n", mpegSource.getAudioStreamLength() );

	vipWindowGTK myWin(mpegSource.getWidth(), mpegSource.getHeight());

	myWin.show();
	myWin.setFrameRate(0);// mpegSource.getVideoFrameRate()

	printf("\nDecoding and Displaying (with vipFrameRGB24)...\n");
	double offset = 0;

	long sleeptime = (long) (1000 / mpegSource.getVideoFrameRate()) - 10; //-10 to speed up a bit :P
	doc.reset(true);
	while (i++ < 100)// 100 frames
	 {
		offset = vipUtility::getTime_usec();

		mpegSource >> img24;
		myWin << img24;

		vipUtility::vipSleep( sleeptime - (long)(vipUtility::getTime_usec()-offset)/1000 );
	 }

	time = doc.getElapsedTime();
	fps = (float)100000/(float)doc.getElapsedTime();

	printf("Elapsed milliseconds : %ld\n", time );
	printf("Average Frame Rate : %f fps\n", fps );

	printf("Test Completed. Type something to continue...\n");
	getchar();

	return 0;
 }
//---------------------------------------------------------------------------
