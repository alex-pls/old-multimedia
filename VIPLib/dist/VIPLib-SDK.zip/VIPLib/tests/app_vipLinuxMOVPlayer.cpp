/** @file    test_vipLinuxMOVPlayer.cpp
 *
 *  @brief   Testing code for class vipCodec_MOV and vipWindowQT.
 *
 *           Load first video stream from a QuickTime format file and
 *           show preview in a window , stream is passed through
 *           vipFrameRGB24 objects.
 *           Frame rate should be the higher possible, after 100 frames,
 *           loop will exit printing average fps; this number depends
 *           on source rate and window's redrawing both (sum).
 *           Then last captured frame is saved.
 *
 *  @warning requires VIPLib with QuickTime support and GUI support (make all)
 *
 *  @note    vipWindowQT must be initialized after QApplication.
 *
 *  @see     vipCodec_MOV
 *  @see     vipWindowQT
 *  @see     app_Video4LinuxPlayer.cpp
 *  @see     app_LinuxMOVPlayer.cpp
 *
 *  @version 1.0.2
 *  @date    11/09/2005
 *  @author  Alessandro Polo
 *
 *
 ****************************************************************************
 * VIPLib Framework
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib
 *
 *  maintained by MultiMedia Laboratory - DIT - University of Trento
 *
 ****************************************************************************/


//---------------------------------------------------------------------------

#pragma hdrstop

//---------------------------------------------------------------------------

#include "../source/vipFrameRGB24.h"
#include "../source/vipUtility.h"

#include "../source/outputs/vipWindowQT.h"
#include "../source/outputs/vipDoctor.h"

#include "../source/codecs/vipCodec_MOV.h"

#include <stdio.h>

#pragma argsused


int main(int argc, char* argv[])
 {
	printf("Testing vipCodec_MOV and vipWindowQT Development...\n");

	printf("\nCreating Instances...\n");

	vipDoctor doc;

	vipCodec_MOV movSource;
	int i = 0;
	long time = 0;
	float fps = 0 ;

	printf("\nLoading Movie...\n");
	int ret = movSource.load("hand.mov");

	if ( ret == VETRET_OK)
		printf("MOV Stream loaded.\n");
	else
	 {
		printf("MOV Stream HAS NOT BEEN loaded. (file hand.mov not found?)\n");
		return 1;
	 }

	vipFrameRGB24 imgRGB24 ( movSource.getWidth(), movSource.getHeight() );

	printf("\nMOV Stream INFO:\n");
	printf(" Video StreamS Count: %d\n", movSource.getVideoStreamCount() );
	printf(" Video Stream [0] Frame Rate: %f\n", movSource.getVideoFrameRate() );
	printf(" Video Stream [0] Frame Count: %ld\n", movSource.getVideoStreamLength() );
	printf(" Video Stream [0] Width: %d\n", movSource.getWidth() );
	printf(" Video Stream [0] Height: %d\n", movSource.getHeight() );
	printf(" Audio StreamS Count: %d\n", movSource.getAudioStreamCount() );
	printf(" Audio Stream [0] Channels: %d\n", movSource.getAudioChannels() );
	printf(" Audio Stream [0] Sample Rate: %f\n", movSource.getAudioSampleRate() );
	printf(" Audio Stream [0] Sample Count: %ld\n", movSource.getAudioStreamLength() );

	printf("\nCreating QApplication...\n");
	QApplication app(argc, argv);

	printf("\nCreating QWindow...\n");
	vipWindowQT *myapp = new vipWindowQT( movSource.getWidth(), movSource.getHeight() );

	printf("\nShowing vipWindowQT...\n");
	myapp->show();
	app.setMainWidget(myapp);

	printf("\nDecoding and Displaying (with vipFrameRGB24)...\n");

	long sleeptime = (long) (1000 / movSource.getVideoFrameRate()) - 10; //-10 to speed up a bit :P
	double offset = 0;
	i = 0;
	doc.reset(true);
	while (i++ < 100)
	 {
		offset = vipUtility::getTime_usec();

		movSource >> imgRGB24;
		*myapp << imgRGB24;

		vipUtility::vipSleep( sleeptime - (long)(vipUtility::getTime_usec()-offset)/1000 );
	 }

	time = doc.getElapsedTime();
	fps = (float)100000/(float)doc.getElapsedTime();

	printf("Elapsed milliseconds : %ld\n", time );
	printf("Average Frame Rate : %f fps\n", fps );

	app.exec();

	printf("Test Completed. Type something to continue...\n");
	getchar();

	return 0;
 }
//---------------------------------------------------------------------------
