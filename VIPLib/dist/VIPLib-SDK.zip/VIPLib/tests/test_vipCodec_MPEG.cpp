/** @file    test_vipCodec_MPEG.cpp
 *
 *  @brief   Testing code for class vipCodec_MPEG.

 *
 *  @warning
 *
 *  @see     vipCodec_MPEG
 *  @see     vipDoctor
 *
 *  @version 1.0.2
 *  @date    14/09/2005
 *  @author  Alessandro Polo
 *
 *
 ****************************************************************************
 * VIPLib Framework
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib
 *
 *  maintained by MultiMedia Laboratory - DIT - University of Trento
 *
 ****************************************************************************/


//---------------------------------------------------------------------------

#pragma hdrstop

//---------------------------------------------------------------------------

#include "../source/vipFrameRGB96.h"
#include "../source/vipFrameRGB24.h"

#include "../source/outputs/vipDoctor.h"

#include "../source/codecs/vipCodec_MPEG.h"
#include "../source/codecs/vipCodec_BMP.h"

#include <stdio.h>

#pragma argsused


int main(int argc, char* argv[])
 {
	printf("Testing vipCodec_MPEG Development...\n");

	printf("\nCreating Instances...\n");
	vipCodec_MPEG mpegSource;
	vipDoctor doc;

	int ret = mpegSource.load("football.mpg");

	if ( ret == VETRET_OK)
		printf("MPEG Stream loaded.\n");
	else
	 {
		printf("MPEG Stream HAS NOT BEEN loaded.\n");
		return 1;
	 }

	printf("\nMPEG Stream INFO:\n");

	printf(" VIDEO STREAMS COUNT: %d\n", mpegSource.getVideoStreamCount() );
	printf(" VIDEO STREAM [0] FRAME RATE: %f\n", mpegSource.getVideoFrameRate() );
	printf(" VIDEO STREAM [0] FRAME COUNT: %ld\n", mpegSource.getVideoStreamLength() );
	printf(" VIDEO STREAM [0] WIDTH: %d\n", mpegSource.getWidth() );
	printf(" VIDEO STREAM [0] HEIGHT: %d\n", mpegSource.getHeight() );


	printf(" AUDIO STREAMS COUNT: %d\n", mpegSource.getAudioStreamCount() );
	printf(" AUDIO STREAM [0] CHANNELS: %d\n", mpegSource.getAudioChannels() );
	printf(" AUDIO STREAM [0] SAMPLE RATE: %f\n", mpegSource.getAudioSampleRate() );
	printf(" AUDIO STREAM [0] SAMPLE COUNT: %ld\n", mpegSource.getAudioStreamLength() );

	vipFrameRGB24 img24a(mpegSource.getWidth(), mpegSource.getHeight());
	vipFrameRGB24 img24b(mpegSource.getWidth(), mpegSource.getHeight());

	printf("\nExtracting frames..\n");

	mpegSource >> img24a;
	mpegSource >> img24b;

	vipCodec_BMP::save(img24a, "MPEG_Extracted_Frame1.bmp", vipCodec_BMP::FORMAT_BMP_24);
	vipCodec_BMP::save(img24b, "MPEG_Extracted_Frame2.bmp", vipCodec_BMP::FORMAT_BMP_24);


	printf("\nParameters Serialization (XML)...\n");
	mpegSource.getParameters().setFileName("input_video.mpg");
	mpegSource.getParameters().setFrameIndex(1000);
	mpegSource.getParameters().setStream(0);
	mpegSource.getParameters().saveToXML("MPEG_param.XML");


	vipCodec_MPEG mpegSource2;

	mpegSource2.getParameters().loadFromXML("MPEG_param.XML");
	mpegSource2.getParameters().saveToXML("MPEG_param_COPY.XML");


	printf("Test Completed. Type something to continue...\n");
	getchar();


	return 0;
 }
//---------------------------------------------------------------------------
