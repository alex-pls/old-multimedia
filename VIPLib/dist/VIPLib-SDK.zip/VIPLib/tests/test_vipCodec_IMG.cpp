/** @file    test_vipCodec_IMG.cpp
 *
 *  @brief   Testing code for class vipCodec_IMG.
 *
 *           Some tests on BMP file format, read/write speed and redirection.
 *
 *
 *  @see     vipCodec_IMG
 *  @see     vipMultiplexer
 *  @see     vipDoctor
 *
 *  @version 1.0.2
 *  @date    26/07/2005
 *  @author  Alessandro Polo
 *
 *
 ****************************************************************************
 * VIPLib Framework
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib
 *
 *  maintained by MultiMedia Laboratory - DIT - University of Trento
 *
 ****************************************************************************/


//---------------------------------------------------------------------------

#pragma hdrstop

//---------------------------------------------------------------------------

#include "../source/vipFrameRGB24.h"
#include "../source/vipFrameGrey.h"

#include "../source/codecs/vipCodec_IMG.h"
#include "../source/codecs/vipCodec_BMP.h"
#include "../source/filters/vipMultiplexer.h"
#include "../source/outputs/vipDoctor.h"


#include <stdio.h>


int main(int argc, char* argv[])
 {
	printf("Testing vipCodec_IMG development...\n");

	printf("\nCreating Instances...\n");
	vipDoctor doc;

	vipCodec_IMG source;
	vipCodec_IMG dest;
	vipCodec_IMG saver;

	vipFrameRGB24 img;

	printf("\nLoading frame... (vipFrameRGB24)\n");
	vipCodec_IMG::load(img, "frame1.jpg");

	printf("\nSaving frame...\n");
	vipCodec_BMP::save(img, "frame1_COPY_24b.bmp", vipCodec_BMP::FORMAT_BMP_24);

//	source.save(img, "frame1_COPY.jpg");



	printf("Test Completed. Type something to continue...\n");
	getchar();

	return 0;
 }
//---------------------------------------------------------------------------
