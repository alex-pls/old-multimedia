/** @file    app_vipDirectXLamePlayer.cpp
 *
 *  @brief
 *
 *  @warning
 *
 *  @note
 *
 *
 *  @version 1.0.2
 *  @date    11/09/2005
 *  @author  Alessandro Polo
 *
 *
 ****************************************************************************
 * VIPLib Framework
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib
 *
 *  maintained by MultiMedia Laboratory - DIT - University of Trento
 *
 ****************************************************************************/

#define _WIN32_DCOM // needed by VC6 for OLE..

#include "../source/vipFrameRGB24.h"
#include "../source/inputs/vipDirectXInput.h"
#include "../source/outputs/vipWindow32.h"

#include <windows.h>

//---------------------------------------------------------------------------

// Global Objects
vipWindow32* myOut;
vipFrameRGB24* img;
vipDirectXInput cap;


// Declarations
LRESULT CALLBACK WndMainProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

/**
 * @brief  Main function (called by OS)
 *         Loads 2 frames, create a new instance of vipWindow32 and show it.
 *
 *
 * @return DefWindowProc(..)
 */
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hInstP, LPSTR lpCmdLine, int nCmdShow)
{
    MSG msg={0};
    WNDCLASS wc;

    // Initialize COM
    if(FAILED(CoInitializeEx(NULL, COINIT_APARTMENTTHREADED)))
    {
        MessageBox(NULL, TEXT("CoInitialize Failed!\r\n"), TEXT("PlayCapMoniker"), MB_OK | MB_ICONERROR);
        exit(1);
    }

    // Register the window class
    ZeroMemory(&wc, sizeof wc);
    wc.lpfnWndProc   = WndMainProc;
    wc.hInstance     = hInstance;
    wc.lpszClassName = VETW32_DEF_CLSNAME;
    wc.lpszMenuName  = NULL;
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    if(!RegisterClass(&wc))
    {
        MessageBox(NULL, TEXT("RegisterClass Failed! Error=0x%x\r\n"), TEXT("PlayCapMoniker"), MB_OK | MB_ICONERROR);
        CoUninitialize();
        exit(1);
    }


	// load frames for animation example

	int ret = cap.connectTo(0);
	if (ret)
	 {
		printf("CANNOT connect to device : %d [ret=%d]\n", 0, ret);
		return 1;
	 }
	else
		printf("connected to device : %d\n", 0);

	int w, h;
	cap.getImageSize(&w, &h);
	img = new vipFrameRGB24(w, h);

    myOut = new vipWindow32(hInstance);

//myOut->RESIZE

    if( myOut->dump_handle() )
    {
		myOut->show();

        // Main message loop
        while(GetMessage(&msg,NULL,0,0))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    // Release COM
    CoUninitialize();

	cap.disconnect();

    return ((int) msg.wParam);
}



/**
 * @brief  This function manage message loop.
 *         It's implemented for events: WM_KEYDOWN and WM_PAINT, on paint frames
 *         are drawed sequentially.
 *
 * @param hwnd	application's handle
 * @param message message to process
 * @param wParam message parameter
 * @param lParam message parameter pointer
 *
 * @return DefWindowProc(..)
 */
LRESULT CALLBACK WndMainProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_SIZE:

            break;

		// Force a redraw when a key is pressed
		case WM_KEYDOWN:
			InvalidateRect(myOut->dump_handle(), NULL, TRUE);
			break;

		// Paint our window
		case WM_PAINT:
			{
			// gdi allows to redraw window only here ! (call InvalidateRect(..) to raise WM_PAINT message)

			// [.code here.]

			cap >> *img;
			*myOut << *img;
			cap >> *img;
			*myOut << *img;
			cap >> *img;
			*myOut << *img;
			cap >> *img;
			*myOut << *img;
			cap >> *img;
			*myOut << *img;
			cap >> *img;
			*myOut << *img;
			cap >> *img;
			*myOut << *img;


			}

		break;

        case WM_CLOSE:
            myOut->hide();//same as calling ShowWindow(myOut->getHandle(), SW_HIDE);
            break;

        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
    }

    return DefWindowProc (hwnd, message, wParam, lParam);
}




