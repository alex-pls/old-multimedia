/** @file    test_vipCodec_MOV.cpp
 *
 *  @brief   Testing code for class vipCodec_MOV.

 *
 *  @warning
 *
 *  @see     vipCodec_MOV
 *  @see     vipDoctor
 *
 *  @version 1.0.2
 *  @date    14/09/2005
 *  @author  Alessandro Polo
 *
 *
 ****************************************************************************
 * VIPLib Framework
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib
 *
 *  maintained by MultiMedia Laboratory - DIT - University of Trento
 *
 ****************************************************************************/


//---------------------------------------------------------------------------

#pragma hdrstop

//---------------------------------------------------------------------------

#include "../source/vipFrameRGB96.h"
#include "../source/vipFrameRGB24.h"

#include "../source/outputs/vipDoctor.h"

#include "../source/codecs/vipCodec_MOV.h"
#include "../source/codecs/vipCodec_BMP.h"

#include <stdio.h>

#pragma argsused


int main(int argc, char* argv[])
 {
	printf("Testing vipCodec_MOV Development...\n");

	printf("Testing VIDEO READING...\n");

	printf("\nCreating Instances...\n");
	vipCodec_MOV movSource;
	vipDoctor doc;

	int ret = movSource.load("hand.mov");

	if ( ret == VETRET_OK)
		printf("MOV Stream loaded.\n");
	else
	 {
		printf("MOV Stream HAS NOT BEEN loaded.\n");
		return 1;
	 }

	printf("\nMOV Stream INFO:\n");

	printf(" VIDEO STREAMS COUNT: %d\n", movSource.getVideoStreamCount() );
	printf(" VIDEO STREAM [0] FRAME RATE: %f\n", movSource.getVideoFrameRate() );
	printf(" VIDEO STREAM [0] FRAME COUNT: %ld\n", movSource.getVideoStreamLength() );
	printf(" VIDEO STREAM [0] WIDTH: %d\n", movSource.getWidth() );
	printf(" VIDEO STREAM [0] HEIGHT: %d\n", movSource.getHeight() );

	printf(" AUDIO STREAMS COUNT: %d\n", movSource.getAudioStreamCount() );
	printf(" AUDIO STREAM [0] CHANNELS: %d\n", movSource.getAudioChannels() );
	printf(" AUDIO STREAM [0] SAMPLE RATE: %ld\n", movSource.getAudioSampleRate() );
	printf(" AUDIO STREAM [0] SAMPLE COUNT: %ld\n", movSource.getAudioStreamLength() );

	vipFrameRGB24 img24a(movSource.getWidth(), movSource.getHeight());
	vipFrameRGB24 img24b(movSource.getWidth(), movSource.getHeight());
	vipFrameRGB24 img24c(movSource.getWidth(), movSource.getHeight());
	vipFrameRGB24 img24d(movSource.getWidth(), movSource.getHeight());

	printf("\nExtracting frames..\n");

	movSource >> img24a;
	movSource >> img24b;
	movSource >> img24c;
	movSource >> img24d;

	vipCodec_BMP::save(img24a, "MOV_Extracted_Frame1.bmp", vipCodec_BMP::FORMAT_BMP_24);
	vipCodec_BMP::save(img24b, "MOV_Extracted_Frame2.bmp", vipCodec_BMP::FORMAT_BMP_24);
	vipCodec_BMP::save(img24c, "MOV_Extracted_Frame3.bmp", vipCodec_BMP::FORMAT_BMP_24);
	vipCodec_BMP::save(img24d, "MOV_Extracted_Frame4.bmp", vipCodec_BMP::FORMAT_BMP_24);


	printf("Testing VIDEO WRITING...\n");

	vipCodec_MOV movDest;


	movDest.newVideo("outvideo.mov", img24a.width, img24a.height, 15, 80);

	for (int i=0; i < 10; i++)
	 {

		movDest << img24a;
		movDest << img24b;
		movDest << img24c;
		movDest << img24d;

		movDest << img24d;
		movDest << img24c;
		movDest << img24b;
		movDest << img24a;
	 }

	movDest.save();

	printf("\nParameters Serialization (XML)...\n");
	movDest.getParameters().setFileName("input_video.mov");
	movDest.getParameters().setFrameIndex(1000);
	movDest.getParameters().setStream(0);
	movDest.getParameters().saveToXML("MOV_param.XML");


	vipCodec_MOV movDest2;

	movDest2.getParameters().loadFromXML("MOV_param.XML");
	movDest2.getParameters().saveToXML("MOV_param_COPY.XML");



	printf("Test Completed. Type something to continue...\n");
	getchar();


	return 0;
 }
//---------------------------------------------------------------------------
