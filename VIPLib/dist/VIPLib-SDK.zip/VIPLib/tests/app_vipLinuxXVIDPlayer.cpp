/** @file    test_vipLinuxXVIDPlayer.cpp
 *
 *  @brief   Testing code for class vipCodec_XVID and vipWindowQT.
 *

 *
 *  @warning requires VIPLib with MPEG support and GUI support (make all)
 *
 *  @see     vipCodec_MPEG
 *  @see     vipWindowQT
 *  @see     app_Video4LinuxPlayer.cpp
 *  @see     app_LinuxMOVPlayer.cpp
 *
 *  @version 1.0.2
 *  @date    11/09/2005
 *  @author  Alessandro Polo
 *
 *
 ****************************************************************************
 * VIPLib Framework
 *  open source, founded by Alessandro Polo 2006
 *  http://mmlab.science.unitn.it/projects/VIPLib
 *
 *  maintained by MultiMedia Laboratory - DIT - University of Trento
 *
 ****************************************************************************/


//---------------------------------------------------------------------------

#pragma hdrstop

//---------------------------------------------------------------------------

#include "../source/vipFrameRGB24.h"
#include "../source/vipUtility.h"

#include "../source/outputs/vipWindowQT.h"
#include "../source/outputs/vipDoctor.h"

#include "../source/codecs/vipCodec_XVID.h"

#include <stdio.h>

#pragma argsused


int main(int argc, char* argv[])
 {
	printf("Testing vipCodec_XVID and vipWindowQT Development...\n");

	printf("\nCreating Instances...\n");
	vipDoctor doc;

	int i = 0;
	long time = 0;
	float fps = 0 ;
	vipCodec_XVID xvidSource;

	printf("\nLoading Movie...\n");
	int ret = xvidSource.load("football.avi");

	if ( ret == VETRET_OK)
		printf("XVID Stream loaded.\n");
	else
	 {
		printf("XVID Stream HAS NOT BEEN loaded. (file football.avi not found?)\n");
		return 1;
	 }

//	xvidSource >> img;
	vipFrameRGB24 img24 ( xvidSource.getWidth(), xvidSource.getHeight() );

	printf("\nMPEG Stream INFO:\n");
  	printf(" VIDEO STREAM [0] WIDTH: %d\n", xvidSource.getWidth() );
	printf(" VIDEO STREAM [0] HEIGHT: %d\n", xvidSource.getHeight() );


	printf("\nCreating QApplication...\n");
	QApplication app(argc, argv);

	printf("\nCreating QWindow...\n");
	vipWindowQT *myapp = new vipWindowQT(xvidSource.getWidth(), xvidSource.getHeight() );

	printf("\nShowing vipWindowQT...\n");
	myapp->show();
	app.setMainWidget(myapp);

	printf("\nDecoding and Displaying (with vipFrameRGB24)...\n");
//	double offset = 0;
//	long sleeptime = (long) (1000 / xvidSource.getVideoFrameRate()) - 10; //-10 to speed up a bit :P
	doc.reset(true);
	while (i++ < 100)
	 {
//		offset = vipUtility::getTime_usec();

		xvidSource >> img24;
		*myapp << img24;

//		vipUtility::vipSleep( sleeptime - (long)(vipUtility::getTime_usec()-offset)/1000 );
	 }

	time = doc.getElapsedTime();
	fps = (float)100000/(float)doc.getElapsedTime();

	printf("Elapsed milliseconds : %ld\n", time );
	printf("Average Frame Rate : %f fps\n", fps );

	app.exec();

	printf("Test Completed. Type something to continue...\n");
	getchar();

	return 0;
 }
//---------------------------------------------------------------------------
